async function convertCode() {
    const hlasmCode = document.getElementById('hlasmInput').value;
    const strictValidation = document.getElementById('strictValidation').checked;
    const javaOutput = document.getElementById('javaOutput');
    const errorOutput = document.getElementById('errorOutput');

    if (!hlasmCode.trim()) {
        errorOutput.textContent = 'Please enter HLASM code to convert.';
        return;
    }

    try {
        const response = await fetch('/convert', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                code: hlasmCode,
                strictValidation: strictValidation
            })
        });

        const result = await response.json();

        if (result.error) {
            errorOutput.textContent = result.error;
            javaOutput.textContent = '';
        } else {
            javaOutput.textContent = result.javaCode;
            errorOutput.textContent = result.warnings ? result.warnings.join('\n') : '';
        }
    } catch (error) {
        errorOutput.textContent = 'Error: ' + error.message;
        javaOutput.textContent = '';
    }
}

function clearAll() {
    document.getElementById('hlasmInput').value = '';
    document.getElementById('javaOutput').textContent = '';
    document.getElementById('errorOutput').textContent = '';
    document.getElementById('strictValidation').checked = false;
} 