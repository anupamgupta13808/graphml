import os
import sys
import re
from typing import Dict, List, Set, Tuple, Optional
import json
from datetime import datetime, timedelta
import math
import threading
import queue
import socket
import sqlite3
try:
    import tkinter as tk
except ImportError:
    print("Warning: tkinter not available. GUI features will be disabled.")
try:
    import pygame
except ImportError:
    print("Warning: pygame not available. Graphics features will be disabled.")
try:
    import requests
except ImportError:
    print("Warning: requests not available. Network features will be disabled.")
try:
    import regex
except ImportError:
    print("Warning: regex not available. Advanced pattern matching will be disabled.")
try:
    import numpy as np
except ImportError:
    print("Warning: numpy not available. Advanced math operations will be disabled.")
try:
    from PIL import Image
except ImportError:
    print("Warning: PIL not available. Image processing features will be disabled.")
try:
    import pyaudio
except ImportError:
    print("Warning: pyaudio not available. Audio features will be disabled.")
try:
    import sqlalchemy
except ImportError:
    print("Warning: sqlalchemy not available. Database features will be disabled.")

class ALCConverter:
    def __init__(self):
        # Variable tracking
        self.variables: Dict[str, str] = {}  # name -> type
        self.arrays: Dict[str, Tuple[str, int]] = {}  # name -> (type, size)
        self.matrices: Dict[str, Tuple[str, int, int]] = {}  # name -> (type, rows, cols)
        self.strings: Set[str] = set()
        self.floats: Set[str] = set()
        self.stack_vars: Set[str] = set()
        self.file_handles: Set[str] = set()
        self.labels: Set[str] = set()
        
        # Class and interface tracking
        self.classes: Dict[str, Dict] = {}  # name -> {fields, methods, interfaces}
        self.interfaces: Dict[str, List[str]] = {}  # name -> [methods]
        self.generic_types: Dict[str, str] = {}  # class_name -> type_param
        
        # Collection tracking
        self.lists: Dict[str, str] = {}  # name -> element_type
        self.maps: Dict[str, Tuple[str, str]] = {}  # name -> (key_type, value_type)
        self.sets: Dict[str, str] = {}  # name -> element_type
        self.queues: Dict[str, str] = {}  # name -> element_type
        self.stacks: Dict[str, str] = {}  # name -> element_type
        
        # Resource tracking
        self.windows: Set[str] = set()
        self.sounds: Set[str] = set()
        self.db_connections: Set[str] = set()
        self.threads: Set[str] = set()

        # Enhanced tracking for complex features
        self.macros: Dict[str, List[str]] = {}  # name -> [instructions]
        self.structs: Dict[str, Dict[str, str]] = {}  # name -> {field -> type}
        self.unions: Dict[str, Dict[str, str]] = {}  # name -> {field -> type}
        self.enums: Dict[str, List[str]] = {}  # name -> [values]
        self.segments: Dict[str, List[str]] = {}  # name -> [instructions]
        self.sections: Dict[str, List[str]] = {}  # name -> [instructions]
        self.aliases: Dict[str, str] = {}  # alias -> original
        self.constants: Dict[str, str] = {}  # name -> value
        self.registers: Dict[str, str] = {}  # register -> type
        self.flags: Set[str] = set()  # CPU flags
        self.interrupts: Dict[str, List[str]] = {}  # number -> [handlers]
        self.ports: Dict[str, str] = {}  # port -> type
        self.memory: Dict[str, Tuple[str, int]] = {}  # address -> (type, size)
        
        # Advanced data structures
        self.trees: Dict[str, str] = {}  # name -> element_type
        self.graphs: Dict[str, Tuple[str, str]] = {}  # name -> (node_type, edge_type)
        self.heaps: Dict[str, str] = {}  # name -> element_type
        self.tries: Dict[str, str] = {}  # name -> element_type
        self.caches: Dict[str, Tuple[str, str, int]] = {}  # name -> (key_type, value_type, size)
        
        # Advanced control flow
        self.loops: Dict[str, List[str]] = {}  # label -> [instructions]
        self.switches: Dict[str, Dict[str, List[str]]] = {}  # var -> {value -> [instructions]}
        self.handlers: Dict[str, List[str]] = {}  # exception -> [instructions]
        self.coroutines: Dict[str, List[str]] = {}  # name -> [instructions]
        
        # Advanced memory management
        self.allocations: Dict[str, Tuple[str, int]] = {}  # ptr -> (type, size)
        self.deallocations: Set[str] = set()  # ptrs to free
        self.memory_pools: Dict[str, Tuple[str, int]] = {}  # pool -> (type, size)
        
        # Advanced I/O
        self.streams: Dict[str, str] = {}  # name -> type
        self.sockets: Dict[str, Tuple[str, int]] = {}  # name -> (type, port)
        self.pipes: Dict[str, Tuple[str, str]] = {}  # name -> (read_type, write_type)
        
        # Advanced synchronization
        self.locks: Dict[str, str] = {}  # name -> type
        self.semaphores: Dict[str, int] = {}  # name -> permits
        self.barriers: Dict[str, int] = {}  # name -> parties
        self.conditions: Dict[str, str] = {}  # name -> type
        
        # Advanced graphics
        self.canvases: Dict[str, Tuple[int, int]] = {}  # name -> (width, height)
        self.sprites: Dict[str, str] = {}  # name -> image_path
        self.animations: Dict[str, List[str]] = {}  # name -> [frames]
        self.effects: Dict[str, List[str]] = {}  # name -> [operations]
        
        # Advanced audio
        self.tracks: Dict[str, str] = {}  # name -> file_path
        self.effects: Dict[str, List[str]] = {}  # name -> [operations]
        self.mixers: Dict[str, List[str]] = {}  # name -> [tracks]
        
        # Advanced networking
        self.protocols: Dict[str, List[str]] = {}  # name -> [handlers]
        self.endpoints: Dict[str, Tuple[str, int]] = {}  # name -> (host, port)
        self.routes: Dict[str, List[str]] = {}  # name -> [handlers]
        
        # Advanced database
        self.connections: Dict[str, str] = {}  # name -> url
        self.transactions: Dict[str, List[str]] = {}  # name -> [operations]
        self.queries: Dict[str, str] = {}  # name -> sql
        self.schemas: Dict[str, Dict[str, str]] = {}  # name -> {field -> type}

    def _add_variable_declarations(self) -> List[str]:
        """Generate Java code for variable declarations."""
        java_code = []
        
        # Add regular variables
        for var_name, var_type in self.variables.items():
            java_code.append(f"            {var_type} {var_name};")
        
        # Add arrays
        for arr_name, (arr_type, size) in self.arrays.items():
            java_code.append(f"            {arr_type}[] {arr_name} = new {arr_type}[{size}];")
        
        # Add matrices
        for matrix_name, (matrix_type, rows, cols) in self.matrices.items():
            java_code.append(f"            {matrix_type}[][] {matrix_name} = new {matrix_type}[{rows}][{cols}];")
        
        # Add strings
        for str_name in self.strings:
            java_code.append(f"            String {str_name};")
        
        # Add floats
        for float_name in self.floats:
            java_code.append(f"            double {float_name};")
        
        # Add file handles
        for handle in self.file_handles:
            java_code.append(f"            FileWriter {handle};")
        
        # Add collections
        for list_name, element_type in self.lists.items():
            java_code.append(f"            List<{element_type}> {list_name} = new ArrayList<>();")
        
        for map_name, (key_type, value_type) in self.maps.items():
            java_code.append(f"            Map<{key_type}, {value_type}> {map_name} = new HashMap<>();")
        
        for set_name, element_type in self.sets.items():
            java_code.append(f"            Set<{element_type}> {set_name} = new HashSet<>();")
        
        for queue_name, element_type in self.queues.items():
            java_code.append(f"            Queue<{element_type}> {queue_name} = new LinkedList<>();")
        
        for stack_name, element_type in self.stacks.items():
            java_code.append(f"            Stack<{element_type}> {stack_name} = new Stack<>();")
        
        java_code.append("")  # Add empty line for readability
        return java_code

    def _add_helper_methods(self) -> List[str]:
        """Generate Java code for helper methods."""
        java_code = []
        
        # Matrix operations helper
        if self.matrices:
            java_code.extend([
                "            private static void printMatrix(int[][] matrix, int rows, int cols) {",
                "                for (int i = 0; i < rows; i++) {",
                "                    for (int j = 0; j < cols; j++) {",
                "                        System.out.print(matrix[i][j] + \" \");",
                "                    }",
                "                    System.out.println();",
                "                }",
                "            }",
                ""
            ])
        
        # Array operations helper
        if self.arrays:
            java_code.extend([
                "            private static void printArray(int[] array, int size) {",
                "                for (int i = 0; i < size; i++) {",
                "                    System.out.print(array[i] + \" \");",
                "                }",
                "                System.out.println();",
                "            }",
                ""
            ])
        
        # File operations helper
        if self.file_handles:
            java_code.extend([
                "            private static void writeToFile(String filename, String content) throws IOException {",
                "                try (FileWriter writer = new FileWriter(filename)) {",
                "                    writer.write(content);",
                "                }",
                "            }",
                "",
                "            private static String readFromFile(String filename) throws IOException {",
                "                StringBuilder content = new StringBuilder();",
                "                try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {",
                "                    String line;",
                "                    while ((line = reader.readLine()) != null) {",
                "                        content.append(line).append(\"\\n\");",
                "                    }",
                "                }",
                "                return content.toString();",
                "            }",
                ""
            ])
        
        return java_code

    def translate_alc_to_java(self, alc_code: str) -> str:
        """Translate ALC code to Java code."""
        # First pass: analyze code to identify variables, types, and structures
        self._analyze_code(alc_code)
        
        java_code = []
        
        # Add necessary imports
        java_code.append("import java.io.*;")
        java_code.append("import java.util.*;")
        java_code.append("import java.time.*;")
        java_code.append("import java.text.*;")
        java_code.append("")
        
        # Generate Java code
        java_code.extend([
            "package com.alc.generated;",
            "",
            "import java.util.*;",
            "import java.io.*;",
            "import java.net.*;",
            "import java.time.*;",
            "import java.time.format.*;",
            "import java.sql.*;",
            "import java.util.regex.*;",
            "import javax.swing.*;",
            "import java.awt.*;",
            "import java.awt.event.*;",
            "import org.json.*;",
            "import java.util.concurrent.*;",
            "",
        ])
        
        # Generate interfaces
        for interface_name, methods in self.interfaces.items():
            java_code.extend(self._generate_interface(interface_name, methods))
        
        # Generate classes
        for class_name, class_info in self.classes.items():
            java_code.extend(self._generate_class(class_name, class_info))
        
        # Generate main class
        java_code.extend(self._generate_main_class(alc_code))
        
        return "\n".join(java_code)

    def _analyze_code(self, alc_code: str):
        lines = alc_code.split("\n")
        current_class = None
        current_interface = None
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith(";"):
                continue
                
            # Class definition
            if line.startswith("CLASS "):
                class_name = line[6:].split(":")[0].strip()
                if "<" in class_name:
                    class_name, type_param = class_name.split("<")
                    type_param = type_param.rstrip(">")
                    self.generic_types[class_name] = type_param
                self.classes[class_name] = {
                    "fields": {},
                    "methods": {},
                    "interfaces": []
                }
                current_class = class_name
                current_interface = None
                
            # Interface definition
            elif line.startswith("INTERFACE "):
                interface_name = line[10:].split(":")[0].strip()
                self.interfaces[interface_name] = []
                current_interface = interface_name
                current_class = None
                
            # Method definition
            elif line.startswith("METHOD "):
                method_name = line[7:].split(":")[0].strip()
                if current_class:
                    self.classes[current_class]["methods"][method_name] = []
                elif current_interface:
                    self.interfaces[current_interface].append(method_name)
                    
            # Variable declarations
            elif line.startswith("MOV "):
                parts = line[4:].split(",")
                var_name = parts[0].strip()
                if current_class:
                    self.classes[current_class]["fields"][var_name] = self._infer_type(parts[1].strip())
                else:
                    self.variables[var_name] = self._infer_type(parts[1].strip())
                    
            # Collection declarations
            elif line.startswith(("LIST ", "MAP ", "SET ", "QUEUE ", "STACK ")):
                collection_type = line.split()[0].lower()
                name = line.split()[1].strip()
                if collection_type == "list":
                    self.lists[name] = "Object"
                elif collection_type == "map":
                    self.maps[name] = ("Object", "Object")
                elif collection_type == "set":
                    self.sets[name] = "Object"
                elif collection_type == "queue":
                    self.queues[name] = "Object"
                elif collection_type == "stack":
                    self.stacks[name] = "Object"

    def _generate_interface(self, name: str, methods: List[str]) -> List[str]:
        java_code = [
            f"interface {name} {{",
        ]
        
        for method in methods:
            java_code.append(f"    void {method}();")
            
        java_code.extend([
            "}",
            ""
        ])
        
        return java_code

    def _generate_class(self, name: str, class_info: Dict) -> List[str]:
        java_code = []
        
        # Class declaration
        if name in self.generic_types:
            java_code.append(f"class {name}<{self.generic_types[name]}> {{")
        else:
            java_code.append(f"class {name} {{")
            
        # Fields
        for field_name, field_type in class_info["fields"].items():
            java_code.append(f"    private {field_type} {field_name};")
            
        # Constructor
        java_code.extend([
            f"    public {name}() {{",
            "    }",
            ""
        ])
        
        # Methods
        for method_name, method_body in class_info["methods"].items():
            java_code.extend(self._generate_method(method_name, method_body))
            
        java_code.extend([
            "}",
            ""
        ])
        
        return java_code

    def _generate_main_class(self, alc_code: str) -> List[str]:
        java_code = [
            "public class Main {",
            "    public static void main(String[] args) {",
            "        try {",
        ]
        
        # Add variable declarations
        java_code.extend(self._add_variable_declarations())
        
        # Add helper methods
        java_code.extend(self._add_helper_methods())
        
        # Translate main body
        java_code.extend(self._translate_main_body(alc_code))
        
        java_code.extend([
            "        } catch (Exception e) {",
            "            System.err.println(\"Error: \" + e.getMessage());",
            "            e.printStackTrace();",
            "        }",
            "    }",
            "}"
        ])
        
        return java_code

    def _translate_main_body(self, alc_code: str) -> List[str]:
        java_code = []
        lines = alc_code.split("\n")
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith(";"):
                continue
            # Skip label lines (e.g., start:, loop1:, etc.)
            if line.endswith(":"):
                continue
            try:
                # Handle different instruction types
                if line.startswith("MOV "):
                    java_code.extend(self._translate_mov(line))
                elif line.startswith("ADD "):
                    java_code.extend(self._translate_add(line))
                elif line.startswith("SUB "):
                    java_code.extend(self._translate_sub(line))
                elif line.startswith("MUL "):
                    java_code.extend(self._translate_mul(line))
                elif line.startswith("DIV "):
                    java_code.extend(self._translate_div(line))
                elif line.startswith("JMP "):
                    java_code.extend(self._translate_jmp(line))
                elif line.startswith("JZ "):
                    java_code.extend(self._translate_jz(line))
                elif line.startswith("JG "):
                    java_code.extend(self._translate_jg(line))
                elif line.startswith("JL "):
                    java_code.extend(self._translate_jl(line))
                elif line.startswith("CALL "):
                    java_code.extend(self._translate_call(line))
                elif line.startswith("RET"):
                    java_code.extend(self._translate_ret())
                elif line.startswith("PRINT "):
                    java_code.extend(self._translate_print(line))
                elif line.startswith("HALT"):
                    java_code.extend(self._translate_halt())
                elif line.startswith("TRY:"):
                    java_code.extend(self._translate_try())
                elif line.startswith("CATCH:"):
                    java_code.extend(self._translate_catch())
                elif line.startswith("END_TRY:"):
                    java_code.extend(self._translate_end_try())
                elif line.startswith(("AND ", "OR ", "XOR ", "NOT ", "SHL ", "SHR ")):
                    java_code.extend(self._translate_bitwise(line))
                elif line.startswith(("CONCAT ", "SUBSTRING ", "FIND ", "REPLACE ")):
                    java_code.extend(self._translate_string_op(line))
                elif line.startswith(("SIN ", "COS ", "TAN ", "SQRT ", "POW ", "LOG ")):
                    java_code.extend(self._translate_math_op(line))
                elif line.startswith(("LIST ", "MAP ", "SET ", "QUEUE ", "STACK ")):
                    java_code.extend(self._translate_collection_decl(line))
                elif line.startswith(("ADD ", "REMOVE ", "SORT ", "REVERSE ")):
                    java_code.extend(self._translate_collection_op(line))
                elif line.startswith(("PUT ", "GET ")):
                    java_code.extend(self._translate_map_op(line))
                elif line.startswith(("ENQUEUE ", "DEQUEUE ", "PEEK ")):
                    java_code.extend(self._translate_queue_op(line))
                elif line.startswith(("PUSH ", "POP ")):
                    java_code.extend(self._translate_stack_op(line))
                elif line.startswith(("WRITE ", "READ ")):
                    java_code.extend(self._translate_file_op(line))
                elif line.startswith(("GET ", "POST ")):
                    java_code.extend(self._translate_network_op(line))
                elif line.startswith("THREAD "):
                    java_code.extend(self._translate_thread_decl(line))
                elif line.startswith(("START ", "JOIN ")):
                    java_code.extend(self._translate_thread_op(line))
                elif line.startswith(("MATCH ", "REPLACE_ALL ")):
                    java_code.extend(self._translate_regex_op(line))
                elif line.startswith(("NOW ", "FORMAT ", "PARSE ", "ADD_DAYS ", "DIFF_DAYS ")):
                    java_code.extend(self._translate_datetime_op(line))
                elif line.startswith(("PARSE_JSON ", "GET_JSON ", "SET_JSON ", "STRINGIFY ")):
                    java_code.extend(self._translate_json_op(line))
                elif line.startswith(("CONNECT ", "QUERY ", "INSERT ", "UPDATE ", "DELETE ", "CLOSE ")):
                    java_code.extend(self._translate_db_op(line))
                elif line.startswith(("WINDOW ", "DRAW_LINE ", "DRAW_RECT ", "DRAW_CIRCLE ", "SET_COLOR ", "FILL ", "SHOW ")):
                    java_code.extend(self._translate_graphics_op(line))
                elif line.startswith(("LOAD_SOUND ", "PLAY ", "PAUSE ", "RESUME ", "STOP ", "SET_VOLUME ")):
                    java_code.extend(self._translate_sound_op(line))
                elif line.startswith(("MACRO ", "ENDMACRO ", "STRUCT ", "ENDSTRUCT ", "UNION ", "ENDUNION ", "ENUM ", "ENDENUM ", "SEGMENT ", "ENDSEGMENT ", "SECTION ", "ENDSECTION ", "ALIAS ", "CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_macro(line))
                elif line.startswith(("STRUCT ", "ENDSTRUCT ", "UNION ", "ENDUNION ", "ENUM ", "ENDENUM ", "SEGMENT ", "ENDSEGMENT ", "SECTION ", "ENDSECTION ", "ALIAS ", "CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_struct(line))
                elif line.startswith(("UNION ", "ENDUNION ", "ENUM ", "ENDENUM ", "SEGMENT ", "ENDSEGMENT ", "SECTION ", "ENDSECTION ", "ALIAS ", "CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_union(line))
                elif line.startswith(("ENUM ", "ENDENUM ", "SEGMENT ", "ENDSEGMENT ", "SECTION ", "ENDSECTION ", "ALIAS ", "CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_enum(line))
                elif line.startswith(("SEGMENT ", "ENDSEGMENT ", "SECTION ", "ENDSECTION ", "ALIAS ", "CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_segment(line))
                elif line.startswith(("SECTION ", "ENDSECTION ", "ALIAS ", "CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_section(line))
                elif line.startswith(("ALIAS ", "CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_alias(line))
                elif line.startswith(("CONST ", "REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_constant(line))
                elif line.startswith(("REG ", "FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_register(line))
                elif line.startswith(("FLAG ", "INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_flag(line))
                elif line.startswith(("INTERRUPT ", "ENDINTERRUPT ", "PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_interrupt(line))
                elif line.startswith(("PORT ", "MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_port(line))
                elif line.startswith(("MEMORY ", "TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_memory(line))
                elif line.startswith(("TREE ", "GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_tree(line))
                elif line.startswith(("GRAPH ", "HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_graph(line))
                elif line.startswith(("HEAP ", "TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_heap(line))
                elif line.startswith(("TRIE ", "CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_trie(line))
                elif line.startswith(("CACHE ", "LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_cache(line))
                elif line.startswith(("LOOP ", "ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_loop(line))
                elif line.startswith(("ENDLOOP ", "SWITCH ", "CASE ", "ENDSWITCH ", "HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_switch(line))
                elif line.startswith(("HANDLER ", "ENDHANDLER ", "COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_handler(line))
                elif line.startswith(("COROUTINE ", "ENDCOROUTINE ", "ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_coroutine(line))
                elif line.startswith(("ALLOC ", "FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_allocation(line))
                elif line.startswith(("FREE ", "POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_deallocation(line))
                elif line.startswith(("POOL ", "STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_memory_pool(line))
                elif line.startswith(("STREAM ", "SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_stream(line))
                elif line.startswith(("SOCKET ", "PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_socket(line))
                elif line.startswith(("PIPE ", "LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_pipe(line))
                elif line.startswith(("LOCK ", "SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_lock(line))
                elif line.startswith(("SEMAPHORE ", "BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_semaphore(line))
                elif line.startswith(("BARRIER ", "CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_barrier(line))
                elif line.startswith(("CONDITION ", "CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_condition(line))
                elif line.startswith(("CANVAS ", "SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_canvas(line))
                elif line.startswith(("SPRITE ", "ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_sprite(line))
                elif line.startswith(("ANIMATION ", "TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_animation(line))
                elif line.startswith(("TRACK ", "MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_track(line))
                elif line.startswith(("MIXER ", "PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_mixer(line))
                elif line.startswith(("PROTOCOL ", "ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_protocol(line))
                elif line.startswith(("ENDPROTOCOL ", "ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_endpoint(line))
                elif line.startswith(("ENDPOINT ", "ROUTE ", "CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_route(line))
                elif line.startswith(("CONNECTION ", "TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_connection(line))
                elif line.startswith(("TRANSACTION ", "QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_transaction(line))
                elif line.startswith(("QUERY ", "SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_query(line))
                elif line.startswith(("SCHEMA ", "ENDSCHEMA ")):
                    java_code.extend(self._translate_schema(line))
            except Exception as e:
                print(f"Warning: Skipping line due to error: {line} ({e})")
                continue
        return java_code

    def _translate_mov(self, line: str) -> List[str]:
        """Translate MOV instruction to Java."""
        parts = line[4:].split(",")
        dest = parts[0].strip()
        src = parts[1].strip()
        return [f"            {dest} = {src};"]

    def _translate_add(self, line: str) -> List[str]:
        """Translate ADD instruction to Java."""
        parts = line[4:].split(",")
        dest = parts[0].strip()
        src1 = parts[1].strip()
        src2 = parts[2].strip()
        return [f"            {dest} = {src1} + {src2};"]

    def _translate_sub(self, line: str) -> List[str]:
        """Translate SUB instruction to Java."""
        parts = line[4:].split(",")
        dest = parts[0].strip()
        src1 = parts[1].strip()
        src2 = parts[2].strip()
        return [f"            {dest} = {src1} - {src2};"]

    def _translate_mul(self, line: str) -> List[str]:
        """Translate MUL instruction to Java."""
        parts = line[4:].split(",")
        dest = parts[0].strip()
        src1 = parts[1].strip()
        src2 = parts[2].strip()
        return [f"            {dest} = {src1} * {src2};"]

    def _translate_div(self, line: str) -> List[str]:
        """Translate DIV instruction to Java."""
        parts = line[4:].split(",")
        dest = parts[0].strip()
        src1 = parts[1].strip()
        src2 = parts[2].strip()
        return [f"            {dest} = {src1} / {src2};"]

    def _translate_jmp(self, line: str) -> List[str]:
        """Translate JMP instruction to Java."""
        label = line[4:].strip()
        return [f"            continue {label};"]

    def _translate_jz(self, line: str) -> List[str]:
        """Translate JZ instruction to Java."""
        parts = line[3:].split(",")
        condition = parts[0].strip()
        label = parts[1].strip()
        return [f"            if ({condition} == 0) continue {label};"]

    def _translate_jg(self, line: str) -> List[str]:
        """Translate JG instruction to Java."""
        parts = line[3:].split(",")
        condition = parts[0].strip()
        label = parts[1].strip()
        return [f"            if ({condition} > 0) continue {label};"]

    def _translate_jl(self, line: str) -> List[str]:
        """Translate JL instruction to Java."""
        parts = line[3:].split(",")
        condition = parts[0].strip()
        label = parts[1].strip()
        return [f"            if ({condition} < 0) continue {label};"]

    def _translate_call(self, line: str) -> List[str]:
        """Translate CALL instruction to Java."""
        method = line[5:].strip()
        return [f"            {method}();"]

    def _translate_ret(self) -> List[str]:
        """Translate RET instruction to Java."""
        return ["            return;"]

    def _translate_print(self, line: str) -> List[str]:
        """Translate PRINT instruction to Java."""
        value = line[6:].strip()
        return [f"            System.out.println({value});"]

    def _translate_halt(self) -> List[str]:
        """Translate HALT instruction to Java."""
        return ["            System.exit(0);"]

    def _translate_try(self) -> List[str]:
        """Translate TRY block to Java."""
        return ["            try {"]

    def _translate_catch(self) -> List[str]:
        """Translate CATCH block to Java."""
        return ["            } catch (Exception e) {"]

    def _translate_end_try(self) -> List[str]:
        """Translate END_TRY block to Java."""
        return ["            }"]

    def _translate_bitwise(self, line: str) -> List[str]:
        """Translate bitwise operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        dest = parts[1].strip()
        src1 = parts[2].strip()
        src2 = parts[3].strip() if len(parts) > 3 else None

        if op == "and":
            return [f"            {dest} = {src1} & {src2};"]
        elif op == "or":
            return [f"            {dest} = {src1} | {src2};"]
        elif op == "xor":
            return [f"            {dest} = {src1} ^ {src2};"]
        elif op == "not":
            return [f"            {dest} = ~{src1};"]
        elif op == "shl":
            return [f"            {dest} = {src1} << {src2};"]
        elif op == "shr":
            return [f"            {dest} = {src1} >> {src2};"]
        return []

    def _translate_string_op(self, line: str) -> List[str]:
        """Translate string operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        dest = parts[1].strip()
        src1 = parts[2].strip()
        src2 = parts[3].strip() if len(parts) > 3 else None

        if op == "concat":
            return [f"            {dest} = {src1} + {src2};"]
        elif op == "substring":
            return [f"            {dest} = {src1}.substring({src2});"]
        elif op == "find":
            return [f"            {dest} = {src1}.indexOf({src2});"]
        elif op == "replace":
            src3 = parts[4].strip()
            return [f"            {dest} = {src1}.replace({src2}, {src3});"]
        return []

    def _translate_math_op(self, line: str) -> List[str]:
        """Translate mathematical operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        dest = parts[1].strip()
        src1 = parts[2].strip()
        src2 = parts[3].strip() if len(parts) > 3 else None

        if op == "sin":
            return [f"            {dest} = Math.sin({src1});"]
        elif op == "cos":
            return [f"            {dest} = Math.cos({src1});"]
        elif op == "tan":
            return [f"            {dest} = Math.tan({src1});"]
        elif op == "sqrt":
            return [f"            {dest} = Math.sqrt({src1});"]
        elif op == "pow":
            return [f"            {dest} = Math.pow({src1}, {src2});"]
        elif op == "log":
            return [f"            {dest} = Math.log({src1});"]
        return []

    def _translate_collection_decl(self, line: str) -> List[str]:
        """Translate collection declarations to Java."""
        parts = line.split()
        collection_type = parts[0].lower()
        name = parts[1].strip()
        element_type = parts[2].strip() if len(parts) > 2 else "Object"

        if collection_type == "list":
            return [f"            List<{element_type}> {name} = new ArrayList<>();"]
        elif collection_type == "map":
            key_type = parts[2].strip()
            value_type = parts[3].strip()
            return [f"            Map<{key_type}, {value_type}> {name} = new HashMap<>();"]
        elif collection_type == "set":
            return [f"            Set<{element_type}> {name} = new HashSet<>();"]
        elif collection_type == "queue":
            return [f"            Queue<{element_type}> {name} = new LinkedList<>();"]
        elif collection_type == "stack":
            return [f"            Stack<{element_type}> {name} = new Stack<>();"]
        return []

    def _translate_collection_op(self, line: str) -> List[str]:
        """Translate collection operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        collection = parts[1].strip()
        element = parts[2].strip()

        if op == "add":
            return [f"            {collection}.add({element});"]
        elif op == "remove":
            return [f"            {collection}.remove({element});"]
        elif op == "sort":
            return [f"            Collections.sort({collection});"]
        elif op == "reverse":
            return [f"            Collections.reverse({collection});"]
        return []

    def _translate_map_op(self, line: str) -> List[str]:
        """Translate map operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        map_name = parts[1].strip()
        key = parts[2].strip()
        value = parts[3].strip() if len(parts) > 3 else None

        if op == "put":
            return [f"            {map_name}.put({key}, {value});"]
        elif op == "get":
            return [f"            {value} = {map_name}.get({key});"]
        return []

    def _translate_queue_op(self, line: str) -> List[str]:
        """Translate queue operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        queue = parts[1].strip()
        element = parts[2].strip() if len(parts) > 2 else None

        if op == "enqueue":
            return [f"            {queue}.offer({element});"]
        elif op == "dequeue":
            return [f"            {element} = {queue}.poll();"]
        elif op == "peek":
            return [f"            {element} = {queue}.peek();"]
        return []

    def _translate_stack_op(self, line: str) -> List[str]:
        """Translate stack operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        stack = parts[1].strip()
        element = parts[2].strip() if len(parts) > 2 else None

        if op == "push":
            return [f"            {stack}.push({element});"]
        elif op == "pop":
            return [f"            {element} = {stack}.pop();"]
        return []

    def _translate_file_op(self, line: str) -> List[str]:
        """Translate file operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        filename = parts[1].strip()
        content = parts[2].strip() if len(parts) > 2 else None

        if op == "write":
            return [f"            writeToFile({filename}, {content});"]
        elif op == "read":
            return [f"            {content} = readFromFile({filename});"]
        return []

    def _translate_network_op(self, line: str) -> List[str]:
        """Translate network operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        url = parts[1].strip()
        data = parts[2].strip() if len(parts) > 2 else None

        if op == "get":
            return [f"            {data} = new String(URL({url}).openStream().readAllBytes());"]
        elif op == "post":
            return [f"            HttpURLConnection conn = (HttpURLConnection) new URL({url}).openConnection();",
                   "            conn.setRequestMethod(\"POST\");",
                   "            conn.setDoOutput(true);",
                   f"            conn.getOutputStream().write({data}.getBytes());",
                   f"            {data} = new String(conn.getInputStream().readAllBytes());"]
        return []

    def _translate_thread_decl(self, line: str) -> List[str]:
        """Translate thread declarations to Java."""
        thread_name = line[7:].strip()
        return [f"            Thread {thread_name} = new Thread(() -> {{"]

    def _translate_thread_op(self, line: str) -> List[str]:
        """Translate thread operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        thread = parts[1].strip()

        if op == "start":
            return [f"            {thread}.start();"]
        elif op == "join":
            return [f"            {thread}.join();"]
        return []

    def _translate_regex_op(self, line: str) -> List[str]:
        """Translate regex operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        pattern = parts[1].strip()
        text = parts[2].strip()
        replacement = parts[3].strip() if len(parts) > 3 else None

        if op == "match":
            return [f"            Pattern.compile({pattern}).matcher({text}).matches();"]
        elif op == "replace_all":
            return [f"            {text} = {text}.replaceAll({pattern}, {replacement});"]
        return []

    def _translate_datetime_op(self, line: str) -> List[str]:
        """Translate datetime operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        dest = parts[1].strip()
        src1 = parts[2].strip()
        src2 = parts[3].strip() if len(parts) > 3 else None

        if op == "now":
            return [f"            {dest} = LocalDateTime.now();"]
        elif op == "format":
            return [f"            {dest} = {src1}.format(DateTimeFormatter.ofPattern({src2}));"]
        elif op == "parse":
            return [f"            {dest} = LocalDateTime.parse({src1}, DateTimeFormatter.ofPattern({src2}));"]
        elif op == "add_days":
            return [f"            {dest} = {src1}.plusDays({src2});"]
        elif op == "diff_days":
            return [f"            {dest} = ChronoUnit.DAYS.between({src1}, {src2});"]
        return []

    def _translate_json_op(self, line: str) -> List[str]:
        """Translate JSON operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        dest = parts[1].strip()
        src = parts[2].strip()

        if op == "parse_json":
            return [f"            {dest} = new JSONObject({src});"]
        elif op == "get_json":
            key = parts[3].strip()
            return [f"            {dest} = {src}.get{key}();"]
        elif op == "set_json":
            key = parts[3].strip()
            value = parts[4].strip()
            return [f"            {src}.put({key}, {value});"]
        elif op == "stringify":
            return [f"            {dest} = {src}.toString();"]
        return []

    def _translate_db_op(self, line: str) -> List[str]:
        """Translate database operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        conn = parts[1].strip()
        query = parts[2].strip()

        if op == "connect":
            return [f"            {conn} = DriverManager.getConnection({query});"]
        elif op == "query":
            return [f"            ResultSet rs = {conn}.createStatement().executeQuery({query});"]
        elif op == "insert":
            return [f"            {conn}.createStatement().executeUpdate({query});"]
        elif op == "update":
            return [f"            {conn}.createStatement().executeUpdate({query});"]
        elif op == "delete":
            return [f"            {conn}.createStatement().executeUpdate({query});"]
        elif op == "close":
            return [f"            {conn}.close();"]
        return []

    def _translate_graphics_op(self, line: str) -> List[str]:
        """Translate graphics operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        window = parts[1].strip()

        if op == "window":
            return [f"            JFrame {window} = new JFrame();",
                   f"            {window}.setSize(800, 600);",
                   f"            {window}.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);"]
        elif op == "draw_line":
            x1, y1, x2, y2 = parts[2:6]
            return [f"            Graphics g = {window}.getGraphics();",
                   f"            g.drawLine({x1}, {y1}, {x2}, {y2});"]
        elif op == "draw_rect":
            x, y, w, h = parts[2:6]
            return [f"            Graphics g = {window}.getGraphics();",
                   f"            g.drawRect({x}, {y}, {w}, {h});"]
        elif op == "draw_circle":
            x, y, r = parts[2:5]
            return [f"            Graphics g = {window}.getGraphics();",
                   f"            g.drawOval({x}-{r}, {y}-{r}, {r}*2, {r}*2);"]
        elif op == "set_color":
            color = parts[2]
            return [f"            Graphics g = {window}.getGraphics();",
                   f"            g.setColor(new Color({color}));"]
        elif op == "fill":
            return [f"            {window}.repaint();"]
        elif op == "show":
            return [f"            {window}.setVisible(true);"]
        return []

    def _translate_sound_op(self, line: str) -> List[str]:
        """Translate sound operations to Java."""
        parts = line.split()
        op = parts[0].lower()
        sound = parts[1].strip()

        if op == "load_sound":
            file = parts[2].strip()
            return [f"            {sound} = new AudioInputStream(new File({file}));"]
        elif op == "play":
            return [f"            {sound}.start();"]
        elif op == "pause":
            return [f"            {sound}.stop();"]
        elif op == "resume":
            return [f"            {sound}.start();"]
        elif op == "stop":
            return [f"            {sound}.stop();",
                   f"            {sound}.setFramePosition(0);"]
        elif op == "set_volume":
            volume = parts[2].strip()
            return [f"            {sound}.setVolume({volume});"]
        return []

    def _translate_macro(self, line: str) -> List[str]:
        """Translate macro definitions and calls to Java."""
        parts = line.split()
        if parts[0] == "MACRO":
            name = parts[1]
            params = parts[2:]
            self.macros[name] = []
            return [f"    private static void {name}({', '.join(params)}) {{"]
        elif parts[0] == "ENDMACRO":
            return ["    }"]
        elif parts[0] in self.macros:
            macro_name = parts[0]
            args = parts[1:]
            return [f"            {macro_name}({', '.join(args)});"]
        return []

    def _translate_struct(self, line: str) -> List[str]:
        """Translate structure definitions to Java classes."""
        parts = line.split()
        if parts[0] == "STRUCT":
            name = parts[1]
            self.structs[name] = {}
            return [f"    public static class {name} {{"]
        elif parts[0] == "ENDSTRUCT":
            return ["    }"]
        elif len(parts) >= 3:  # Field definition
            struct_name = parts[0]
            field_name = parts[1]
            field_type = parts[2]
            self.structs[struct_name][field_name] = field_type
            return [f"        private {field_type} {field_name};"]
        return []

    def _translate_union(self, line: str) -> List[str]:
        """Translate union definitions to Java classes."""
        parts = line.split()
        if parts[0] == "UNION":
            name = parts[1]
            self.unions[name] = {}
            return [f"    public static class {name} {{"]
        elif parts[0] == "ENDUNION":
            return ["    }"]
        elif len(parts) >= 3:  # Field definition
            union_name = parts[0]
            field_name = parts[1]
            field_type = parts[2]
            self.unions[union_name][field_name] = field_type
            return [f"        private {field_type} {field_name};"]
        return []

    def _translate_enum(self, line: str) -> List[str]:
        """Translate enum definitions to Java enums."""
        parts = line.split()
        if parts[0] == "ENUM":
            name = parts[1]
            self.enums[name] = []
            return [f"    public enum {name} {{"]
        elif parts[0] == "ENDENUM":
            return ["    }"]
        elif len(parts) >= 2:  # Enum value
            enum_name = parts[0]
            value = parts[1]
            self.enums[enum_name].append(value)
            return [f"        {value},"]
        return []

    def _translate_segment(self, line: str) -> List[str]:
        """Translate memory segments to Java code."""
        parts = line.split()
        if parts[0] == "SEGMENT":
            name = parts[1]
            self.segments[name] = []
            return [f"    // Segment: {name}"]
        elif parts[0] == "ENDSEGMENT":
            return []
        return []

    def _translate_section(self, line: str) -> List[str]:
        """Translate code sections to Java methods."""
        parts = line.split()
        if parts[0] == "SECTION":
            name = parts[1]
            self.sections[name] = []
            return [f"    private static void {name}() {{"]
        elif parts[0] == "ENDSECTION":
            return ["    }"]
        return []

    def _translate_alias(self, line: str) -> List[str]:
        """Translate aliases to Java constants."""
        parts = line.split()
        if parts[0] == "ALIAS":
            alias = parts[1]
            original = parts[2]
            self.aliases[alias] = original
            return [f"    private static final {self._infer_type(original)} {alias} = {original};"]
        return []

    def _translate_constant(self, line: str) -> List[str]:
        """Translate constants to Java constants."""
        parts = line.split()
        if parts[0] == "CONST":
            name = parts[1]
            value = parts[2]
            self.constants[name] = value
            return [f"    private static final {self._infer_type(value)} {name} = {value};"]
        return []

    def _translate_register(self, line: str) -> List[str]:
        """Translate CPU registers to Java variables."""
        parts = line.split()
        if parts[0] == "REG":
            name = parts[1]
            reg_type = parts[2]
            self.registers[name] = reg_type
            return [f"    private static {reg_type} {name};"]
        return []

    def _translate_flag(self, line: str) -> List[str]:
        """Translate CPU flags to Java boolean variables."""
        parts = line.split()
        if parts[0] == "FLAG":
            name = parts[1]
            self.flags.add(name)
            return [f"    private static boolean {name};"]
        return []

    def _translate_interrupt(self, line: str) -> List[str]:
        """Translate interrupt handlers to Java methods."""
        parts = line.split()
        if parts[0] == "INTERRUPT":
            number = parts[1]
            self.interrupts[number] = []
            return [f"    private static void interrupt{number}() {{"]
        elif parts[0] == "ENDINTERRUPT":
            return ["    }"]
        return []

    def _translate_port(self, line: str) -> List[str]:
        """Translate I/O ports to Java variables."""
        parts = line.split()
        if parts[0] == "PORT":
            name = parts[1]
            port_type = parts[2]
            self.ports[name] = port_type
            return [f"    private static {port_type} {name};"]
        return []

    def _translate_memory(self, line: str) -> List[str]:
        """Translate memory operations to Java code."""
        parts = line.split()
        if parts[0] == "MEMORY":
            address = parts[1]
            mem_type = parts[2]
            size = parts[3]
            self.memory[address] = (mem_type, int(size))
            return [f"    private static {mem_type}[] memory_{address} = new {mem_type}[{size}];"]
        return []

    def _translate_tree(self, line: str) -> List[str]:
        """Translate tree data structures to Java code."""
        parts = line.split()
        if parts[0] == "TREE":
            name = parts[1]
            element_type = parts[2]
            self.trees[name] = element_type
            return [f"    private static class TreeNode<{element_type}> {{",
                   f"        {element_type} value;",
                   "        TreeNode<" + element_type + "> left;",
                   "        TreeNode<" + element_type + "> right;",
                   "    }",
                   f"    private static TreeNode<{element_type}> {name};"]
        return []

    def _translate_graph(self, line: str) -> List[str]:
        """Translate graph data structures to Java code."""
        parts = line.split()
        if parts[0] == "GRAPH":
            name = parts[1]
            node_type = parts[2]
            edge_type = parts[3]
            self.graphs[name] = (node_type, edge_type)
            return [f"    private static class GraphNode<{node_type}> {{",
                   f"        {node_type} value;",
                   "        List<GraphNode<" + node_type + ">> neighbors;",
                   "    }",
                   f"    private static GraphNode<{node_type}> {name};"]
        return []

    def _translate_heap(self, line: str) -> List[str]:
        """Translate heap data structures to Java code."""
        parts = line.split()
        if parts[0] == "HEAP":
            name = parts[1]
            element_type = parts[2]
            self.heaps[name] = element_type
            return [f"    private static PriorityQueue<{element_type}> {name} = new PriorityQueue<>();"]
        return []

    def _translate_trie(self, line: str) -> List[str]:
        """Translate trie data structures to Java code."""
        parts = line.split()
        if parts[0] == "TRIE":
            name = parts[1]
            element_type = parts[2]
            self.tries[name] = element_type
            return [f"    private static class TrieNode {{",
                   "        Map<Character, TrieNode> children;",
                   "        boolean isEndOfWord;",
                   "    }",
                   f"    private static TrieNode {name};"]
        return []

    def _translate_cache(self, line: str) -> List[str]:
        """Translate cache data structures to Java code."""
        parts = line.split()
        if parts[0] == "CACHE":
            name = parts[1]
            key_type = parts[2]
            value_type = parts[3]
            size = parts[4]
            self.caches[name] = (key_type, value_type, int(size))
            return [f"    private static LinkedHashMap<{key_type}, {value_type}> {name} = new LinkedHashMap<{key_type}, {value_type}>({size}, 0.75f, true) {{",
                   "        @Override",
                   "        protected boolean removeEldestEntry(Map.Entry<" + key_type + ", " + value_type + "> eldest) {",
                   "            return size() > " + size + ";",
                   "        }",
                   "    };"]
        return []

    def _translate_loop(self, line: str) -> List[str]:
        """Translate loop structures to Java code."""
        parts = line.split()
        if parts[0] == "LOOP":
            label = parts[1]
            self.loops[label] = []
            return [f"            {label}: while (true) {{"]
        elif parts[0] == "ENDLOOP":
            return ["            }"]
        return []

    def _translate_switch(self, line: str) -> List[str]:
        """Translate switch structures to Java code."""
        parts = line.split()
        if parts[0] == "SWITCH":
            var = parts[1]
            self.switches[var] = {}
            return [f"            switch ({var}) {{"]
        elif parts[0] == "CASE":
            var = parts[1]
            value = parts[2]
            self.switches[var][value] = []
            return [f"                case {value}:"]
        elif parts[0] == "ENDSWITCH":
            return ["            }"]
        return []

    def _translate_handler(self, line: str) -> List[str]:
        """Translate exception handlers to Java code."""
        parts = line.split()
        if parts[0] == "HANDLER":
            exception = parts[1]
            self.handlers[exception] = []
            return [f"            }} catch ({exception} e) {{"]
        elif parts[0] == "ENDHANDLER":
            return []
        return []

    def _translate_coroutine(self, line: str) -> List[str]:
        """Translate coroutines to Java code."""
        parts = line.split()
        if parts[0] == "COROUTINE":
            name = parts[1]
            self.coroutines[name] = []
            return [f"    private static CompletableFuture<Void> {name}() {{",
                   "        return CompletableFuture.runAsync(() -> {"]
        elif parts[0] == "ENDCOROUTINE":
            return ["        });",
                   "    }"]
        return []

    def _translate_allocation(self, line: str) -> List[str]:
        """Translate memory allocations to Java code."""
        parts = line.split()
        if parts[0] == "ALLOC":
            ptr = parts[1]
            alloc_type = parts[2]
            size = parts[3]
            self.allocations[ptr] = (alloc_type, int(size))
            return [f"            {alloc_type}[] {ptr} = new {alloc_type}[{size}];"]
        return []

    def _translate_deallocation(self, line: str) -> List[str]:
        """Translate memory deallocations to Java code."""
        parts = line.split()
        if parts[0] == "FREE":
            ptr = parts[1]
            self.deallocations.add(ptr)
            return [f"            {ptr} = null;"]
        return []

    def _translate_memory_pool(self, line: str) -> List[str]:
        """Translate memory pools to Java code."""
        parts = line.split()
        if parts[0] == "POOL":
            name = parts[1]
            pool_type = parts[2]
            size = parts[3]
            self.memory_pools[name] = (pool_type, int(size))
            return [f"    private static {pool_type}[] {name} = new {pool_type}[{size}];",
                   f"    private static int {name}_index = 0;"]
        return []

    def _translate_stream(self, line: str) -> List[str]:
        """Translate stream operations to Java code."""
        parts = line.split()
        if parts[0] == "STREAM":
            name = parts[1]
            stream_type = parts[2]
            self.streams[name] = stream_type
            return [f"    private static {stream_type} {name};"]
        return []

    def _translate_socket(self, line: str) -> List[str]:
        """Translate socket operations to Java code."""
        parts = line.split()
        if parts[0] == "SOCKET":
            name = parts[1]
            socket_type = parts[2]
            port = parts[3]
            self.sockets[name] = (socket_type, int(port))
            return [f"    private static {socket_type} {name};"]
        return []

    def _translate_pipe(self, line: str) -> List[str]:
        """Translate pipe operations to Java code."""
        parts = line.split()
        if parts[0] == "PIPE":
            name = parts[1]
            read_type = parts[2]
            write_type = parts[3]
            self.pipes[name] = (read_type, write_type)
            return [f"    private static PipedInputStream {name}_in;",
                   f"    private static PipedOutputStream {name}_out;"]
        return []

    def _translate_lock(self, line: str) -> List[str]:
        """Translate lock operations to Java code."""
        parts = line.split()
        if parts[0] == "LOCK":
            name = parts[1]
            lock_type = parts[2]
            self.locks[name] = lock_type
            return [f"    private static {lock_type} {name} = new {lock_type}();"]
        return []

    def _translate_semaphore(self, line: str) -> List[str]:
        """Translate semaphore operations to Java code."""
        parts = line.split()
        if parts[0] == "SEMAPHORE":
            name = parts[1]
            permits = parts[2]
            self.semaphores[name] = int(permits)
            return [f"    private static Semaphore {name} = new Semaphore({permits});"]
        return []

    def _translate_barrier(self, line: str) -> List[str]:
        """Translate barrier operations to Java code."""
        parts = line.split()
        if parts[0] == "BARRIER":
            name = parts[1]
            parties = parts[2]
            self.barriers[name] = int(parties)
            return [f"    private static CyclicBarrier {name} = new CyclicBarrier({parties});"]
        return []

    def _translate_condition(self, line: str) -> List[str]:
        """Translate condition operations to Java code."""
        parts = line.split()
        if parts[0] == "CONDITION":
            name = parts[1]
            condition_type = parts[2]
            self.conditions[name] = condition_type
            return [f"    private static {condition_type} {name};"]
        return []

    def _translate_canvas(self, line: str) -> List[str]:
        """Translate canvas operations to Java code."""
        parts = line.split()
        if parts[0] == "CANVAS":
            name = parts[1]
            width = parts[2]
            height = parts[3]
            self.canvases[name] = (int(width), int(height))
            return [f"    private static BufferedImage {name} = new BufferedImage({width}, {height}, BufferedImage.TYPE_INT_ARGB);"]
        return []

    def _translate_sprite(self, line: str) -> List[str]:
        """Translate sprite operations to Java code."""
        parts = line.split()
        if parts[0] == "SPRITE":
            name = parts[1]
            image_path = parts[2]
            self.sprites[name] = image_path
            return [f"    private static BufferedImage {name} = ImageIO.read(new File({image_path}));"]
        return []

    def _translate_animation(self, line: str) -> List[str]:
        """Translate animation operations to Java code."""
        parts = line.split()
        if parts[0] == "ANIMATION":
            name = parts[1]
            self.animations[name] = []
            return [f"    private static List<BufferedImage> {name}_frames = new ArrayList<>();",
                   f"    private static int {name}_current_frame = 0;"]
        return []

    def _translate_track(self, line: str) -> List[str]:
        """Translate audio track operations to Java code."""
        parts = line.split()
        if parts[0] == "TRACK":
            name = parts[1]
            file_path = parts[2]
            self.tracks[name] = file_path
            return [f"    private static Clip {name} = AudioSystem.getClip();",
                   f"    private static AudioInputStream {name}_stream = AudioSystem.getAudioInputStream(new File({file_path}));"]
        return []

    def _translate_mixer(self, line: str) -> List[str]:
        """Translate audio mixer operations to Java code."""
        parts = line.split()
        if parts[0] == "MIXER":
            name = parts[1]
            self.mixers[name] = []
            return [f"    private static Mixer {name} = AudioSystem.getMixer(null);"]
        return []

    def _translate_protocol(self, line: str) -> List[str]:
        """Translate network protocol operations to Java code."""
        parts = line.split()
        if parts[0] == "PROTOCOL":
            name = parts[1]
            self.protocols[name] = []
            return [f"    private static class {name}Protocol {{"]
        return []

    def _translate_endpoint(self, line: str) -> List[str]:
        """Translate network endpoint operations to Java code."""
        parts = line.split()
        if parts[0] == "ENDPOINT":
            name = parts[1]
            host = parts[2]
            port = parts[3]
            self.endpoints[name] = (host, int(port))
            return [f"    private static InetAddress {name}_host = InetAddress.getByName({host});",
                   f"    private static int {name}_port = {port};"]
        return []

    def _translate_route(self, line: str) -> List[str]:
        """Translate network route operations to Java code."""
        parts = line.split()
        if parts[0] == "ROUTE":
            name = parts[1]
            self.routes[name] = []
            return [f"    private static void {name}_handler(HttpExchange exchange) throws IOException {{"]
        return []

    def _translate_connection(self, line: str) -> List[str]:
        """Translate database connection operations to Java code."""
        parts = line.split()
        if parts[0] == "CONNECTION":
            name = parts[1]
            url = parts[2]
            self.connections[name] = url
            return [f"    private static Connection {name} = DriverManager.getConnection({url});"]
        return []

    def _translate_transaction(self, line: str) -> List[str]:
        """Translate database transaction operations to Java code."""
        parts = line.split()
        if parts[0] == "TRANSACTION":
            name = parts[1]
            self.transactions[name] = []
            return [f"    private static void {name}_transaction() throws SQLException {{",
                   "        try {",
                   f"            {name}.setAutoCommit(false);"]
        elif parts[0] == "ENDTRANSACTION":
            return ["            connection.commit();",
                   "        } catch (SQLException e) {",
                   "            connection.rollback();",
                   "            throw e;",
                   "        } finally {",
                   "            connection.setAutoCommit(true);",
                   "        }",
                   "    }"]
        return []

    def _translate_query(self, line: str) -> List[str]:
        """Translate database query operations to Java code."""
        parts = line.split()
        if parts[0] == "QUERY":
            name = parts[1]
            sql = parts[2]
            self.queries[name] = sql
            return [f"    private static PreparedStatement {name}_stmt = connection.prepareStatement({sql});"]
        return []

    def _translate_schema(self, line: str) -> List[str]:
        """Translate database schema operations to Java code."""
        parts = line.split()
        if parts[0] == "SCHEMA":
            name = parts[1]
            self.schemas[name] = {}
            return [f"    private static class {name}Schema {{"]
        elif parts[0] == "ENDSCHEMA":
            return ["    }"]
        elif len(parts) >= 3:  # Field definition
            schema_name = parts[0]
            field_name = parts[1]
            field_type = parts[2]
            self.schemas[schema_name][field_name] = field_type
            return [f"        private {field_type} {field_name};"]
        return []

    def _infer_type(self, value: str) -> str:
        if value.startswith('"') and value.endswith('"'):
            return "String"
        elif "." in value:
            return "double"
        elif value.isdigit():
            return "int"
        elif value == "true" or value == "false":
            return "boolean"
        elif value.startswith("[") and value.endswith("]"):
            return "int[]"
        elif value.startswith("{") and value.endswith("}"):
            return "Map<String, Object>"
        else:
            return "Object"

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 enhanced_converter.py <input_file> <output_java_file>")
        print("Supported input file extensions: .alc, .asm")
        sys.exit(1)
        
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    # Check if input file has supported extension
    if not (input_file.endswith('.alc') or input_file.endswith('.asm')):
        print("Error: Input file must have .alc or .asm extension")
        sys.exit(1)
    
    try:
        with open(input_file, 'r') as f:
            code = f.read()
            
        converter = ALCConverter()
        java_code = converter.translate_alc_to_java(code)
        
        with open(output_file, 'w') as f:
            f.write(java_code)
            
        print(f"Conversion completed. Check {output_file} for the result.")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main() 