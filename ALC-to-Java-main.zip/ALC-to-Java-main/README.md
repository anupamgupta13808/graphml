# HLASM to Java Converter

A tool to convert High Level Assembler (HLASM) code to Java, supporting a wide range of HLASM features and instructions.

## Features

### Instruction Support
- Basic machine instructions (L, ST, LA, A, S, M, D, etc.)
- Floating-point instructions (LDR, ADR, SDR, MDR, DDR, etc.)
- Decimal arithmetic instructions (AP, SP, MP, DP, CP, etc.)
- Extended instructions (LARL, LGRL, STGRL, etc.)
- Compare operations (C, CR, CLC)
- Branch operations (B, BC, BCT, BCTR, BALR)
- Logical operations (N, O, X, NR, OR, XR)
- Shift operations (SLL, SRL, SLA, SRA)
- Move operations (MVC, MVCL, MVI)
- Load/Store multiple (LM, STM)
- System operations (SVC, SSK, ISK)

### Data Definition
- DC (Define Constant)
- DS (Define Storage)
- DCB (Define Control Block)
- DXD (Define External)

### Control Section Directives
- START
- CSECT
- DSECT
- RSECT

### Symbol Definition
- EQU
- ORG
- DROP
- USING

### Macro Support
- MACRO/MEND definitions
- Macro calls (CALLM)
- Macro parameters
- Conditional assembly (AIF, AGO, ANOP)
- MNOTE directives

### Literal Pool
- LTORG
- LIT

### Copy/Include
- COPY
- INCLUDE

### Listing Control
- TITLE
- EJECT
- SPACE
- PRINT

### Mode Directives
- AMODE
- RMODE

### External Reference
- ALIAS
- ENTRY
- EXTRN
- WXTRN

### System Macros
- SAVE
- RETURN
- GETMAIN
- FREEMAIN

### I/O Macros
- OPEN
- CLOSE
- GET
- PUT

### System Service
- WTO
- WTOR
- MGCR

### Time/Date
- TIME
- DATE
- STCK
- STCKCONV

### Timer
- STIMER
- TTIMER
- STIMERM
- TTIMERM

## Web Interface

The converter includes a web interface with the following features:
- Input area for HLASM code
- Output area for generated Java code
- Error/warning display
- Strict validation option (disabled by default)
- Clear all functionality

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/hlasm-to-java.git
cd hlasm-to-java
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Web Interface
1. Start the web server:
```bash
python web_interface.py
```
2. Open a web browser and navigate to `http://localhost:5000`
3. Paste your HLASM code
4. Choose whether to enable strict validation
5. Click "Convert to Java"

### Command Line
```bash
python HLASM_r6_to_java.py input.hlasm output.java
```

## Strict Validation

The converter includes a strict validation mode that can be enabled to ensure:
- Correct number of operands for each instruction
- Valid operand types
- Proper instruction format

By default, strict validation is disabled to allow for more flexible parsing of HLASM code.

## Error Handling

The converter provides:
- Detailed error messages
- Warning messages for non-critical issues
- Line number references
- Context information

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Advanced Features

### Macro Processing and Conditional Logic
- Full support for HLASM macros, including parameterized macros, nested macros, and macro expansion.
- Conditional macro logic: supports `AIF`, `AGO`, `ANOP` for conditional and unconditional branching within macros.
- Macro parameter substitution and label handling.

### Literal Pool Handling
- Multiple `LTORG` support: literal pools can be placed at any point in the code.
- Correct address assignment for literals at each pool.
- Literal reuse: identical literals are only allocated once per pool.

### Floating-Point, Decimal, and Extended Instructions
- Floating-point operations (e.g., `LDR`, `ADR`, `SDR`, etc.)
- Decimal arithmetic (e.g., `AP`, `SP`, `MP`, `DP`, etc.)
- Extended instruction set (e.g., `LARL`, `LGFI`, etc.)

## Usage: Converting Complex HLASM Files

1. **Start the Application**
   - Run `./run.sh` or follow the instructions above to start the web interface.

2. **Upload Your HLASM File**
   - Use the file upload section to select your `.hlasm` file (e.g., `complex_sample.hlasm`).
   - Uncheck "Strict Validation" if your file uses advanced macros or non-standard formatting.

3. **Convert and Analyze**
   - Click **Convert** to generate Java code from your HLASM.
   - Click **Analyze** to view code analysis, including macro expansion and literal pool handling.

4. **Download and Review**
   - Use the **Download** button to save the generated Java code.
   - Review the macro expansion and literal pool assignments in the output.

## Example: Complex Macro and Literal Pool

A sample file `complex_sample.hlasm` is included, demonstrating:
- Macros with parameters and conditional logic
- Multiple literal pools (`LTORG`)
- Floating-point, decimal, and extended instructions

You can use this file to test the advanced features of the converter. 