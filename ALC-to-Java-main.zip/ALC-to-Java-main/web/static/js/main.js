// Initialize CodeMirror editors with improved settings
const hlasmEditor = CodeMirror.fromTextArea(document.getElementById('hlasm-editor'), {
    mode: 'text/x-asm',
    theme: 'monokai',
    lineNumbers: true,
    autoCloseBrackets: true,
    matchBrackets: true,
    indentUnit: 4,
    tabSize: 4,
    lineWrapping: true,
    extraKeys: {
        'Tab': 'indentMore',
        'Shift-Tab': 'indentLess'
    },
    viewportMargin: Infinity,
    autoFocus: true
});

const javaEditor = CodeMirror.fromTextArea(document.getElementById('java-editor'), {
    mode: 'text/x-java',
    theme: 'monokai',
    lineNumbers: true,
    autoCloseBrackets: true,
    matchBrackets: true,
    indentUnit: 4,
    tabSize: 4,
    lineWrapping: true,
    extraKeys: {
        'Tab': 'indentMore',
        'Shift-Tab': 'indentLess'
    },
    viewportMargin: Infinity,
    readOnly: true
});

// Initialize tabs
function initializeTabs() {
    const tabLinks = document.querySelectorAll('.nav-link');
    tabLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            showTab(targetId);
        });
    });
}

// Show selected tab
function showTab(tabId) {
    const tabPanes = document.querySelectorAll('.tab-pane');
    const tabLinks = document.querySelectorAll('.nav-link');

    tabPanes.forEach(pane => {
        pane.classList.remove('show', 'active');
    });

    tabLinks.forEach(link => {
        link.classList.remove('active');
    });

    document.getElementById(tabId).classList.add('show', 'active');
    document.querySelector(`[href="#${tabId}"]`).classList.add('active');
}

// Constants
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const VALID_EXTENSIONS = ['.asm', '.hlasm', '.txt', '.jcl'];
const SUPPORTED_ENCODINGS = ['utf-8', 'ascii', 'ebcdic'];
const MAX_LINES = 10000; // Maximum number of lines in a file

// HLASM Instruction Categories
const INSTRUCTION_CATEGORIES = {
    MACHINE: 'machine',
    ASSEMBLER: 'assembler',
    MACRO: 'macro'
};

// JCL Statement Types
const JCL_STATEMENT_TYPES = {
    JOB: 'JOB',
    EXEC: 'EXEC',
    DD: 'DD',
    PROC: 'PROC',
    PEND: 'PEND',
    OUTPUT: 'OUTPUT',
    COMMAND: 'COMMAND'
};

// Process JCL content
function processJCLContent(content) {
    const lines = content.split('\n');
    const statements = [];
    let currentStatement = null;
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        
        // Skip empty lines and comments
        if (!line || line.startsWith('*')) {
            continue;
        }
        
        // Check for JCL statement
        if (line.startsWith('//')) {
            const parts = line.substring(2).split(/\s+/);
            const statementType = getJCLStatementType(parts[0]);
            
            if (statementType) {
                if (currentStatement) {
                    statements.push(currentStatement);
                }
                
                currentStatement = {
                    type: statementType,
                    name: parts[0],
                    operation: parts[1] || '',
                    operands: parts.slice(2),
                    lineNumber: i + 1
                };
            } else if (currentStatement) {
                // Continuation line
                currentStatement.operands.push(line.substring(2));
            }
        }
    }
    
    if (currentStatement) {
        statements.push(currentStatement);
    }
    
    return statements;
}

// Get JCL statement type
function getJCLStatementType(name) {
    const upperName = name.toUpperCase();
    
    if (upperName === 'JOB') return JCL_STATEMENT_TYPES.JOB;
    if (upperName === 'EXEC') return JCL_STATEMENT_TYPES.EXEC;
    if (upperName === 'DD') return JCL_STATEMENT_TYPES.DD;
    if (upperName === 'PROC') return JCL_STATEMENT_TYPES.PROC;
    if (upperName === 'PEND') return JCL_STATEMENT_TYPES.PEND;
    if (upperName === 'OUTPUT') return JCL_STATEMENT_TYPES.OUTPUT;
    if (upperName === '/*') return JCL_STATEMENT_TYPES.COMMAND;
    
    return null;
}

// Initialize drag and drop
function initializeDragAndDrop() {
    const dropZone = document.getElementById('drop-zone');
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });
    
    dropZone.addEventListener('drop', handleDrop, false);
    
    function highlight(e) {
        dropZone.classList.add('dragover');
    }
    
    function unhighlight(e) {
        dropZone.classList.remove('dragover');
    }
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length > 0) {
            handleFiles(files);
        }
    }
}

// Handle dropped files
function handleFiles(files) {
    if (files.length > 1) {
        showError('Please upload only one file at a time');
        return;
    }
    
    const file = files[0];
    validateAndProcessFile(file);
}

// Read file with multiple encoding attempts
async function readFileWithEncoding(file) {
    let lastError = null;
    
    for (const encoding of SUPPORTED_ENCODINGS) {
        try {
            const content = await readFile(file, encoding);
            // Basic validation to check if the content is readable
            if (content && content.length > 0 && !content.includes('\uFFFD')) {
                return content;
            }
        } catch (error) {
            lastError = error;
            console.warn(`Failed to read file with ${encoding} encoding:`, error);
        }
    }
    
    // If we get here, none of the encodings worked
    throw new Error(`Unable to read file. Please ensure the file is in one of these formats: ${SUPPORTED_ENCODINGS.join(', ')}`);
}

// Read file with specific encoding
function readFile(file, encoding) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            try {
                const content = e.target.result;
                if (!content) {
                    reject(new Error('File is empty'));
                    return;
                }
                resolve(content);
            } catch (error) {
                reject(new Error(`Error processing file content: ${error.message}`));
            }
        };
        
        reader.onerror = (e) => {
            reject(new Error(`Error reading file: ${e.target.error?.message || 'Unknown error'}`));
        };
        
        try {
            reader.readAsText(file, encoding);
        } catch (error) {
            reject(new Error(`Error starting file read: ${error.message}`));
        }
    });
}

// Validate and process file
async function validateAndProcessFile(file) {
    try {
        // Validate file selection
        if (!file) {
            throw new Error('Please select a file to upload');
        }

        // Validate file size
        if (file.size > MAX_FILE_SIZE) {
            throw new Error(`File size exceeds the maximum limit of ${formatBytes(MAX_FILE_SIZE)}`);
        }

        // Validate file extension
        const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
        if (!VALID_EXTENSIONS.includes(fileExtension)) {
            throw new Error(`Invalid file format. Supported formats: ${VALID_EXTENSIONS.join(', ')}`);
        }

        showLoading();
        
        // Try different encodings
        const content = await readFileWithEncoding(file);
        
        // Validate content if strict validation is enabled
        const strictValidation = document.getElementById('strict-validation').checked;
        if (strictValidation) {
            const validationResult = validateHLASMContent(content);
            if (!validationResult.isValid) {
                throw new Error(validationResult.errors.join('\n'));
            }
        }

        // Update editor
        hlasmEditor.setValue(content);
        
        // Save file info
        saveFileInfo(file);
        
        // Update file info display
        updateFileInfoDisplay(file);
        
        showSuccess('File uploaded successfully');
    } catch (error) {
        showError(error.message);
        console.error('File upload error:', error);
    } finally {
        hideLoading();
    }
}

// Validate HLASM content
function validateHLASMContent(content) {
    const lines = content.split('\n');
    const errors = [];
    const warnings = [];
    
    // Check line count
    if (lines.length > MAX_LINES) {
        errors.push(`File exceeds maximum line count of ${MAX_LINES}`);
    }
    
    // Check for valid HLASM instructions
    let hasValidInstruction = false;
    lines.forEach((line, index) => {
        const trimmedLine = line.trim();
        
        // Skip empty lines and comments
        if (!trimmedLine || trimmedLine.startsWith('*')) {
            return;
        }
        
        // Check line length
        if (line.length > 80) {
            warnings.push(`Line ${index + 1}: Exceeds maximum length of 80 characters`);
        }
        
        // Parse line according to HLASM format
        // Column 1-8: Label
        // Column 10-15: Operation
        // Column 16-71: Operands
        // Column 72-80: Comments
        const label = line.substring(0, 8).trim();
        const operation = line.substring(9, 15).trim();
        const operands = line.substring(15, 71).trim();
        
        // Validate label format if present
        if (label && !label.match(/^[A-Z@#$][A-Z@#$0-9]*$/)) {
            errors.push(`Line ${index + 1}: Invalid label format: ${label}`);
        }
        
        // Validate operation
        if (operation && !isValidMnemonic(operation)) {
            errors.push(`Line ${index + 1}: Invalid mnemonic: ${operation}`);
        } else if (operation) {
            hasValidInstruction = true;
        }
        
        // Validate operands if present
        if (operands) {
            const operandList = operands.split(',').map(op => op.trim());
            const validationResult = validateOperands(operation, operandList);
            errors.push(...validationResult.errors.map(err => `Line ${index + 1}: ${err}`));
            warnings.push(...validationResult.warnings.map(warn => `Line ${index + 1}: ${warn}`));
        }
    });
    
    if (!hasValidInstruction) {
        errors.push('No valid HLASM instructions found');
    }
    
    return {
        isValid: errors.length === 0,
        errors: errors,
        warnings: warnings
    };
}

// Helper function to validate mnemonics
function isValidMnemonic(mnemonic) {
    const upperMnemonic = mnemonic.toUpperCase();
    return isMachineInstruction(upperMnemonic) || 
           isAssemblerInstruction(upperMnemonic) || 
           isMacroInstruction(upperMnemonic);
}

// Helper functions for instruction validation
function isMachineInstruction(mnemonic) {
    const machineInstructions = [
        'L', 'LA', 'LR', 'LTR', 'LCR', 'LPR', 'LNR',
        'ST', 'STH', 'STC', 'STCH',
        'A', 'AH', 'AL', 'ALR', 'AR',
        'S', 'SH', 'SL', 'SLR', 'SR',
        'M', 'MH', 'ML', 'MLR', 'MR',
        'D', 'DR', 'DL', 'DLR',
        'C', 'CH', 'CL', 'CLR', 'CR',
        'B', 'BC', 'BCR', 'BCT', 'BCTR',
        'N', 'NR', 'NI', 'NIL',
        'O', 'OR', 'OI', 'OIL',
        'X', 'XR', 'XI', 'XIL',
        'SLL', 'SRL', 'SLA', 'SRA',
        'MVC', 'MVCL', 'MVI', 'MVN', 'MVZ',
        'CLC', 'CLCL', 'CLI', 'CLM',
        'IC', 'ICM',
        'EX', 'EXRL',
        'SSK', 'ISK',
        'SVC', 'SVC 0',
        'TS', 'TCH', 'TDC', 'TDCE', 'TDCET', 'TDCEX',
        'TDCXT', 'TDCT', 'TDCTE', 'TDCTET', 'TDCTEX', 'TDCTEXT',
        'TDCXTE', 'TDCXTET', 'TDCXTEX', 'TDCXTEXT', 'TDCXTE', 'TDCXTET',
        'TDCXTEX', 'TDCXTEXT', 'TDCXTE', 'TDCXTET', 'TDCXTEX', 'TDCXTEXT',
        'BALR', 'BR', 'STM', 'LM'  // Added missing instructions
    ];
    
    return machineInstructions.includes(mnemonic);
}

function isAssemblerInstruction(mnemonic) {
    const assemblerInstructions = [
        'START', 'END', 'CSECT', 'DSECT', 'RSECT',
        'EQU', 'DC', 'DS', 'DCB', 'DXD',
        'ORG', 'DROP', 'USING', 'LTORG',
        'MACRO', 'MEND', 'MEXIT',
        'COPY', 'INCLUDE', 'PUNCH',
        'TITLE', 'EJECT', 'SPACE',
        'PRINT', 'PUNCH', 'REPRO',
        'AMODE', 'RMODE',
        'ALIAS', 'ENTRY', 'EXTRN',
        'WXTRN', 'WXTRN', 'WXTRN',
        'COM', 'DXD', 'DXD',
        'ICTL', 'ISEQ', 'ISEQ',
        'LIT', 'LIT', 'LIT',
        'OPSYN', 'OPSYN', 'OPSYN',
        'POP', 'POP', 'POP',
        'PUSH', 'PUSH', 'PUSH',
        'REPRO', 'REPRO', 'REPRO',
        'SETA', 'SETA', 'SETA',
        'SETB', 'SETB', 'SETB',
        'SETC', 'SETC', 'SETC',
        'WXTRN', 'WXTRN', 'WXTRN'
    ];
    
    return assemblerInstructions.includes(mnemonic);
}

function isMacroInstruction(mnemonic) {
    // This would typically be determined by the macro library
    // For now, we'll check against common macro names
    const commonMacros = [
        'SAVE', 'RETURN', 'GETMAIN', 'FREEMAIN',
        'OPEN', 'CLOSE', 'GET', 'PUT',
        'WTO', 'WTOR', 'MGCR', 'SVC',
        'TIME', 'DATE', 'STCK', 'STCKCONV',
        'STIMER', 'TTIMER', 'STIMERM', 'TTIMERM',
        'STIMERL', 'TTIMERL', 'STIMERM', 'TTIMERM',
        'STIMERL', 'TTIMERL', 'STIMERM', 'TTIMERM'
    ];
    
    return commonMacros.includes(mnemonic);
}

function requiresRegister(mnemonic) {
    const registerInstructions = [
        'LR', 'LTR', 'LCR', 'LPR', 'LNR',
        'AR', 'SR', 'MR', 'DR',
        'NR', 'OR', 'XR',
        'SLL', 'SRL', 'SLA', 'SRA',
        'BCTR', 'BCR'
    ];
    
    return registerInstructions.includes(mnemonic);
}

function requiresAddress(mnemonic) {
    const addressInstructions = [
        'L', 'LA', 'ST', 'STH', 'STC',
        'A', 'AH', 'AL', 'S', 'SH', 'SL',
        'M', 'MH', 'ML', 'D',
        'C', 'CH', 'CL',
        'B', 'BC',
        'MVC', 'MVCL', 'MVI', 'MVN', 'MVZ',
        'CLC', 'CLCL', 'CLI', 'CLM',
        'IC', 'ICM'
    ];
    
    return addressInstructions.includes(mnemonic);
}

function requiresOperands(mnemonic) {
    const operandRequiredInstructions = [
        'START', 'CSECT', 'DSECT', 'RSECT',
        'EQU', 'DC', 'DS', 'DCB', 'DXD',
        'ORG', 'DROP', 'USING',
        'MACRO', 'MEND',
        'COPY', 'INCLUDE',
        'TITLE', 'EJECT', 'SPACE',
        'PRINT', 'PUNCH', 'REPRO',
        'AMODE', 'RMODE',
        'ALIAS', 'ENTRY', 'EXTRN'
    ];
    
    return operandRequiredInstructions.includes(mnemonic);
}

function requiresPositionalParameters(mnemonic) {
    const positionalParameterMacros = [
        'SAVE', 'RETURN', 'GETMAIN', 'FREEMAIN',
        'OPEN', 'CLOSE', 'GET', 'PUT',
        'WTO', 'WTOR', 'MGCR', 'SVC'
    ];
    
    return positionalParameterMacros.includes(mnemonic);
}

function isValidSymbol(symbol) {
    return symbol.match(/^[A-Z@#$][A-Z@#$0-9]*$/) !== null;
}

function isValidKeywordParameter(param) {
    const parts = param.split('=');
    return parts.length === 2 && isValidSymbol(parts[0]);
}

// Helper function to validate operands
function validateOperands(mnemonic, operands) {
    const errors = [];
    const warnings = [];
    const upperMnemonic = mnemonic.toUpperCase();
    
    // Check for required operands
    if (requiresOperands(upperMnemonic) && operands.length === 0) {
        errors.push(`${upperMnemonic} requires operands`);
    }
    
    // Validate register format
    if (requiresRegister(upperMnemonic)) {
        const hasValidRegister = operands.some(op => op.match(/^R?[0-9]+$/));
        if (!hasValidRegister) {
            errors.push(`${upperMnemonic} requires at least one register operand`);
        }
    }
    
    // Validate address format
    if (requiresAddress(upperMnemonic)) {
        const hasValidAddress = operands.some(op =>
            op.match(/^[A-Z@#$][A-Z@#$0-9]*$|^\d+$|^[A-Z@#$][A-Z@#$0-9]*\(\d+\)$|^=\w+'[^']+'$/)
        );
        if (!hasValidAddress) {
            errors.push(`${upperMnemonic} requires a valid address operand`);
        }
    }
    
    // Validate operands based on type
    operands.forEach(op => {
        // Skip validation for literals (e.g., =F'1')
        if (op.startsWith('=')) {
            return;
        }
        
        // Skip validation for register numbers
        if (op.match(/^R?[0-9]+$/)) {
            return;
        }
        
        // Skip validation for displacement(base,index) format
        if (op.match(/^\d+\([0-9]+(?:,[0-9]+)?\)$/)) {
            return;
        }
        
        // Skip validation for DC/DS operands
        if (op.match(/^[A-Z]'[^']+'$|^\d+[A-Z]$/)) {
            return;
        }
        
        // Skip validation for TITLE operand
        if (upperMnemonic === 'TITLE') {
            return;
        }
        
        // Skip validation for USING operand
        if (upperMnemonic === 'USING' && op === '*') {
            return;
        }
        
        // Validate symbol names only for actual symbols
        if (!isValidSymbol(op)) {
            errors.push(`Invalid symbol name: ${op}`);
        }
    });
    
    return { errors, warnings };
}

// Save file information
function saveFileInfo(file) {
    const fileInfo = {
        name: file.name,
        size: file.size,
        type: file.type,
        lastModified: file.lastModified,
        encoding: 'utf-8' // Default encoding
    };
    
    // Store in session storage
    sessionStorage.setItem('currentFile', JSON.stringify(fileInfo));
}

// Convert HLASM code to Java
async function convertCode() {
    const hlasmCode = hlasmEditor.getValue();
    if (!hlasmCode.trim()) {
        showError('Please enter HLASM code to convert');
        return;
    }

    showLoading();
    try {
        const response = await fetch('/convert', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                code: hlasmCode,
                fileInfo: JSON.parse(sessionStorage.getItem('currentFile') || '{}')
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to convert code');
        }

        const data = await response.json();
        javaEditor.setValue(data.java_code);
        
        // Store conversion metadata
        sessionStorage.setItem('lastConversion', JSON.stringify({
            timestamp: new Date().toISOString(),
            sections: data.sections
        }));
        
        showSuccess('Code converted successfully');
    } catch (error) {
        showError(error.message);
        console.error('Conversion error:', error);
    } finally {
        hideLoading();
    }
}

// Analyze Java code
async function analyzeCode() {
    const hlasmCode = hlasmEditor.getValue();
    if (!hlasmCode.trim()) {
        showError('Please enter HLASM code to analyze');
        return;
    }

    showLoading();
    try {
        const response = await fetch('/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                code: hlasmCode,
                fileInfo: JSON.parse(sessionStorage.getItem('currentFile') || '{}'),
                strictValidation: document.getElementById('strict-validation').checked
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to analyze code');
        }

        const data = await response.json();
        console.log('Analysis Response:', data); // Debug log
        
        // Display analysis results
        if (data.thread_safety) {
            console.log('Thread Safety Data:', data.thread_safety); // Debug log
            displayThreadSafetyAnalysis(data.thread_safety);
        }
        if (data.memory_usage) {
            console.log('Memory Usage Data:', data.memory_usage); // Debug log
            displayMemoryUsageAnalysis(data.memory_usage);
        }
        if (data.performance) {
            console.log('Performance Data:', data.performance); // Debug log
            displayPerformanceAnalysis(data.performance);
        }
        if (data.code_quality) {
            console.log('Code Quality Data:', data.code_quality); // Debug log
            displayCodeQualityAnalysis(data.code_quality);
        }
        
        showSuccess('Analysis completed successfully');
    } catch (error) {
        showError(error.message);
        console.error('Analysis error:', error);
    } finally {
        hideLoading();
    }
}

// Display Thread Safety Analysis
function displayThreadSafetyAnalysis(data) {
    const levelDiv = document.getElementById('thread-safety-level');
    const mechanismsList = document.getElementById('thread-safety-mechanisms');
    const issuesList = document.getElementById('thread-safety-issues');
    const recommendationsList = document.getElementById('thread-safety-recommendations');

    // Display safety level
    levelDiv.innerHTML = `
        <div class="analysis-card">
            <h6>Overall Score: ${data.level || 'N/A'}</h6>
            <p>${data.description || 'No description available'}</p>
        </div>
    `;

    // Display mechanisms
    mechanismsList.innerHTML = (data.mechanisms || []).map(mechanism => 
        `<li class="list-group-item">${mechanism}</li>`
    ).join('') || '<li class="list-group-item text-muted">No mechanisms found</li>';

    // Display issues
    issuesList.innerHTML = (data.issues || []).map(issue => 
        `<li class="list-group-item">${issue}</li>`
    ).join('') || '<li class="list-group-item text-muted">No issues found</li>';

    // Display recommendations
    recommendationsList.innerHTML = (data.recommendations || []).map(rec => 
        `<li class="list-group-item">${rec}</li>`
    ).join('') || '<li class="list-group-item text-muted">No recommendations found</li>';

    // Show the thread safety tab
    document.querySelector('[href="#thread-safety"]').click();
}

// Display Memory Usage Analysis
function displayMemoryUsageAnalysis(data) {
    const estimateDiv = document.getElementById('memory-usage-estimate');
    const allocationsList = document.getElementById('memory-allocations');
    const leaksList = document.getElementById('memory-leaks');
    const optimizationsList = document.getElementById('memory-optimizations');

    // Display estimate
    estimateDiv.innerHTML = `
        <div class="analysis-card">
            <h6>Estimated Memory Usage: ${formatBytes(data.estimated_usage || 0)}</h6>
            <p>${data.description || 'No description available'}</p>
        </div>
    `;

    // Display allocations
    allocationsList.innerHTML = (data.object_allocations || []).map(alloc => 
        `<li class="list-group-item">${alloc}</li>`
    ).join('') || '<li class="list-group-item text-muted">No allocations found</li>';

    // Display leaks
    leaksList.innerHTML = (data.potential_leaks || []).map(leak => 
        `<li class="list-group-item">${leak}</li>`
    ).join('') || '<li class="list-group-item text-muted">No potential leaks found</li>';

    // Display optimizations
    optimizationsList.innerHTML = (data.optimization_suggestions || []).map(opt => 
        `<li class="list-group-item">${opt}</li>`
    ).join('') || '<li class="list-group-item text-muted">No optimizations found</li>';

    // Show the memory usage tab
    document.querySelector('[href="#memory-usage"]').click();
}

// Display Performance Analysis
function displayPerformanceAnalysis(data) {
    console.log('Performance Analysis Data:', data); // Debug log
    
    const complexityDiv = document.getElementById('performance-complexity');
    const bottlenecksList = document.getElementById('performance-bottlenecks');
    const ioList = document.getElementById('performance-io');
    const recommendationsList = document.getElementById('performance-recommendations');

    // Display complexity
    complexityDiv.innerHTML = `
        <div class="analysis-card">
            <h6>Complexity Score: ${data.complexity_score || 'N/A'}</h6>
            <p>${data.description || 'No description available'}</p>
        </div>
    `;

    // Display bottlenecks
    bottlenecksList.innerHTML = (data.bottlenecks || []).map(bottleneck => 
        `<li class="list-group-item">${bottleneck}</li>`
    ).join('') || '<li class="list-group-item text-muted">No bottlenecks found</li>';

    // Display I/O operations
    ioList.innerHTML = (data.io_operations || []).map(io => 
        `<li class="list-group-item">${io}</li>`
    ).join('') || '<li class="list-group-item text-muted">No I/O operations found</li>';

    // Display recommendations
    recommendationsList.innerHTML = (data.recommendations || []).map(rec => 
        `<li class="list-group-item">${rec}</li>`
    ).join('') || '<li class="list-group-item text-muted">No recommendations found</li>';

    // Show the performance tab
    document.querySelector('[href="#performance"]').click();
}

// Display Code Quality Analysis
function displayCodeQualityAnalysis(data) {
    const maintainabilityDiv = document.getElementById('code-quality-maintainability');
    const smellsList = document.getElementById('code-quality-smells');
    const practicesList = document.getElementById('code-quality-practices');
    const documentationList = document.getElementById('code-quality-documentation');
    const namingList = document.getElementById('code-quality-naming');
    const complexityList = document.getElementById('code-quality-complexity');
    const recommendationsList = document.getElementById('code-quality-recommendations');

    // Display maintainability with proper score
    const score = Math.min(data.maintainability_score || 0, 10);
    maintainabilityDiv.innerHTML = `
        <div class="analysis-card">
            <h6>Maintainability Score: ${score}/10</h6>
            <p>${data.description || 'No description available'}</p>
        </div>
    `;

    // Display code smells
    smellsList.innerHTML = (data.code_smells || []).map(smell => 
        `<li class="list-group-item">${smell}</li>`
    ).join('') || '<li class="list-group-item text-muted">No code smells found</li>';

    // Display best practices
    practicesList.innerHTML = (data.best_practices || []).map(practice => 
        `<li class="list-group-item">${practice}</li>`
    ).join('') || '<li class="list-group-item text-muted">No best practices found</li>';

    // Display documentation
    documentationList.innerHTML = (data.documentation || []).map(doc => 
        `<li class="list-group-item">${doc}</li>`
    ).join('') || '<li class="list-group-item text-muted">No documentation found</li>';

    // Display naming conventions
    namingList.innerHTML = (data.naming_conventions || []).map(naming => 
        `<li class="list-group-item">${naming}</li>`
    ).join('') || '<li class="list-group-item text-muted">No naming conventions found</li>';

    // Display complexity issues
    complexityList.innerHTML = (data.complexity_issues || []).map(issue => 
        `<li class="list-group-item">${issue}</li>`
    ).join('') || '<li class="list-group-item text-muted">No complexity issues found</li>';

    // Display recommendations
    recommendationsList.innerHTML = (data.recommendations || []).map(rec => 
        `<li class="list-group-item">${rec}</li>`
    ).join('') || '<li class="list-group-item text-muted">No recommendations found</li>';

    // Show the code quality tab
    document.querySelector('[href="#code-quality"]').click();
}

// Utility functions
function showLoading() {
    document.getElementById('loading').classList.remove('d-none');
}

function hideLoading() {
    document.getElementById('loading').classList.add('d-none');
}

// Update file info display
function updateFileInfoDisplay(file) {
    const fileInfo = document.getElementById('file-info');
    const fileName = fileInfo.querySelector('.file-name');
    const fileSize = fileInfo.querySelector('.file-size');
    
    fileName.textContent = file.name;
    fileSize.textContent = ` (${formatBytes(file.size)})`;
    fileInfo.classList.remove('d-none');
}

// Enhanced error display with details
function showError(message, details = null) {
    const toast = document.createElement('div');
    toast.className = 'toast toast-error';
    
    let bodyContent = message;
    if (details) {
        bodyContent += `<br><small class="text-muted">${details}</small>`;
    }
    
    toast.innerHTML = `
        <div class="toast-header">
            <strong class="me-auto">Error</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body">
            ${bodyContent}
        </div>
    `;
    
    document.getElementById('toast-container').appendChild(toast);
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 5000
    });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

// Enhanced success display with details
function showSuccess(message, details = null) {
    const toast = document.createElement('div');
    toast.className = 'toast toast-success';
    
    let bodyContent = message;
    if (details) {
        bodyContent += `<br><small class="text-muted">${details}</small>`;
    }
    
    toast.innerHTML = `
        <div class="toast-header">
            <strong class="me-auto">Success</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body">
            ${bodyContent}
        </div>
    `;
    
    document.getElementById('toast-container').appendChild(toast);
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 3000
    });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Download Java code
function downloadJavaCode() {
    const javaCode = javaEditor.getValue();
    if (!javaCode) {
        showError('No Java code to download');
        return;
    }

    // Get the current file name or use a default
    const fileInfo = JSON.parse(sessionStorage.getItem('currentFile') || '{}');
    const baseName = fileInfo.name ? fileInfo.name.split('.')[0] : 'converted';
    const fileName = `${baseName}.java`;

    // Create a blob with the Java code
    const blob = new Blob([javaCode], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    
    // Create a temporary link and trigger the download
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    
    // Clean up
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    
    showSuccess('Java code downloaded successfully');
}

// Update download button state
function updateDownloadButton() {
    const downloadBtn = document.getElementById('download-btn');
    const javaCode = javaEditor.getValue();
    downloadBtn.disabled = !javaCode;
}

// Initialize the interface
document.addEventListener('DOMContentLoaded', () => {
    initializeTabs();
    initializeDragAndDrop();
    
    // Event listeners
    document.getElementById('convert-btn').addEventListener('click', convertCode);
    document.getElementById('analyze-btn').addEventListener('click', analyzeCode);
    document.getElementById('download-btn').addEventListener('click', downloadJavaCode);
    document.getElementById('upload-btn').addEventListener('click', () => {
        const fileInput = document.getElementById('file-upload');
        if (fileInput.files.length > 0) {
            validateAndProcessFile(fileInput.files[0]);
        } else {
            showError('Please select a file to upload');
        }
    });

    // Add change listener to Java editor
    javaEditor.on('change', updateDownloadButton);
});

function displayJCLAnalysis(jclData) {
    // Display JCL Statements
    const jclStatementsDiv = document.getElementById('jcl-statements');
    jclStatementsDiv.innerHTML = (jclData.statements || []).map(stmt => `
        <div class="jcl-statement">
            <div class="jcl-statement-type">${stmt.type}</div>
            <div class="jcl-statement-content">${stmt.content}</div>
            <div class="mt-2">
                <small class="text-muted">Line: ${stmt.lineNumber}</small>
            </div>
        </div>
    `).join('') || '<div class="text-muted">No JCL statements found</div>';

    // Display Job Parameters
    const jobParamsDiv = document.getElementById('job-parameters');
    jobParamsDiv.innerHTML = `
        <div class="analysis-metric">
            <span class="value">${jclData.jobParameters?.jobName || 'N/A'}</span>
            <span class="label">Job Name</span>
        </div>
        <div class="analysis-metric">
            <span class="value">${jclData.jobParameters?.account || 'N/A'}</span>
            <span class="label">Account</span>
        </div>
        <div class="analysis-metric">
            <span class="value">${jclData.jobParameters?.programmer || 'N/A'}</span>
            <span class="label">Programmer</span>
        </div>
        <div class="analysis-metric">
            <span class="value">${jclData.jobParameters?.class || 'N/A'}</span>
            <span class="label">Job Class</span>
        </div>
        <div class="analysis-metric">
            <span class="value">${jclData.jobParameters?.msgClass || 'N/A'}</span>
            <span class="label">Message Class</span>
        </div>
        <div class="analysis-metric">
            <span class="value">${jclData.jobParameters?.msgLevel || 'N/A'}</span>
            <span class="label">Message Level</span>
        </div>
    `;

    // Display DD Statements
    const ddStatementsDiv = document.getElementById('dd-statements');
    ddStatementsDiv.innerHTML = (jclData.ddStatements || []).map(dd => `
        <div class="jcl-statement">
            <div class="jcl-statement-type">DD Statement</div>
            <div class="jcl-statement-content">${dd.content}</div>
            <div class="mt-2">
                <small class="text-muted">DSN: ${dd.dsn || 'N/A'}</small>
                <br>
                <small class="text-muted">DISP: ${dd.disp || 'N/A'}</small>
                <br>
                <small class="text-muted">UNIT: ${dd.unit || 'N/A'}</small>
                <br>
                <small class="text-muted">VOL: ${dd.vol || 'N/A'}</small>
                <br>
                <small class="text-muted">SPACE: ${dd.space || 'N/A'}</small>
            </div>
        </div>
    `).join('') || '<div class="text-muted">No DD statements found</div>';

    // Display EXEC Statements
    const execStatementsDiv = document.getElementById('exec-statements');
    execStatementsDiv.innerHTML = (jclData.execStatements || []).map(exec => `
        <div class="jcl-statement">
            <div class="jcl-statement-type">EXEC Statement</div>
            <div class="jcl-statement-content">${exec.content}</div>
            <div class="mt-2">
                <small class="text-muted">PGM: ${exec.pgm || 'N/A'}</small>
                <br>
                <small class="text-muted">PROC: ${exec.proc || 'N/A'}</small>
                <br>
                <small class="text-muted">PARM: ${exec.parm || 'N/A'}</small>
                <br>
                <small class="text-muted">TIME: ${exec.time || 'N/A'}</small>
                <br>
                <small class="text-muted">REGION: ${exec.region || 'N/A'}</small>
            </div>
        </div>
    `).join('') || '<div class="text-muted">No EXEC statements found</div>';

    // Display Procedure Calls
    const procCallsDiv = document.getElementById('proc-calls');
    procCallsDiv.innerHTML = (jclData.procCalls || []).map(proc => `
        <div class="jcl-statement">
            <div class="jcl-statement-type">Procedure Call</div>
            <div class="jcl-statement-content">${proc.content}</div>
            <div class="mt-2">
                <small class="text-muted">Name: ${proc.name}</small>
                <br>
                <small class="text-muted">Parameters: ${proc.parameters?.join(', ') || 'None'}</small>
                <br>
                <small class="text-muted">Symbolic Parameters: ${proc.symbolicParameters?.join(', ') || 'None'}</small>
            </div>
        </div>
    `).join('') || '<div class="text-muted">No procedure calls found</div>';

    // Display Output Specifications
    const outputSpecsDiv = document.getElementById('output-specs');
    outputSpecsDiv.innerHTML = (jclData.outputSpecs || []).map(spec => `
        <div class="jcl-statement">
            <div class="jcl-statement-type">Output Specification</div>
            <div class="jcl-statement-content">${spec.content}</div>
            <div class="mt-2">
                <small class="text-muted">Type: ${spec.type}</small>
                <br>
                <small class="text-muted">Destination: ${spec.destination || 'N/A'}</small>
                <br>
                <small class="text-muted">Copies: ${spec.copies || 'N/A'}</small>
                <br>
                <small class="text-muted">Forms: ${spec.forms || 'N/A'}</small>
            </div>
        </div>
    `).join('') || '<div class="text-muted">No output specifications found</div>';

    // Display Recommendations
    const recommendationsList = document.getElementById('jcl-recommendations');
    recommendationsList.innerHTML = (jclData.recommendations || []).map(rec => `
        <li class="list-group-item ${rec.severity || 'info'}">
            <div class="d-flex w-100 justify-content-between">
                <h6 class="mb-1">${rec.title || 'Recommendation'}</h6>
                <small>${rec.severity || 'info'}</small>
            </div>
            <p class="mb-1">${rec.description || 'No description available'}</p>
            ${rec.suggestion ? `<small class="text-muted">Suggestion: ${rec.suggestion}</small>` : ''}
        </li>
    `).join('') || '<li class="list-group-item text-muted">No recommendations found</li>';
} 