from flask import Flask, render_template, request, jsonify
from src.converter.hlasm_parser import HLASMParser
from src.converter.java_generator import JavaGenerator
from src.analysis.thread_safety import ThreadSafetyAnalyzer, ThreadSafetyInfo
from src.analysis.memory_usage import MemoryUsageAnalyzer, MemoryUsageInfo
from src.analysis.performance import PerformanceAnalyzer, PerformanceInfo
from src.analysis.code_quality import CodeQualityAnalyzer, CodeQualityInfo
import json

app = Flask(__name__)

@app.route('/')
def index():
    """Render the main page."""
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    """Convert HLASM code to Java."""
    try:
        hlasm_code = request.json.get('code')
        if not hlasm_code:
            return jsonify({'error': 'No code provided'}), 400
        
        # Parse HLASM code
        parser = HLASMParser()
        sections = parser.parse(hlasm_code)
        
        # Generate Java code
        generator = JavaGenerator()
        java_code = generator.generate_java_code(sections)
        
        return jsonify({
            'java_code': java_code,
            'sections': [section.name for section in sections.values()]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/analyze', methods=['POST'])
def analyze():
    """Analyze Java code."""
    try:
        java_code = request.json.get('code')
        if not java_code:
            return jsonify({'error': 'No code provided'}), 400
        
        # Perform analysis
        thread_safety = analyze_thread_safety(java_code)
        memory_usage = analyze_memory_usage(java_code)
        performance = analyze_performance(java_code)
        code_quality = analyze_code_quality(java_code)
        
        return jsonify({
            'thread_safety': thread_safety,
            'memory_usage': memory_usage,
            'performance': performance,
            'code_quality': code_quality
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def analyze_thread_safety(java_code: str) -> dict:
    """Analyze thread safety of Java code."""
    analyzer = ThreadSafetyAnalyzer()
    info = analyzer.analyze(java_code)
    return {
        'level': info.level.value,
        'mechanisms': info.mechanisms,
        'issues': info.warnings,
        'recommendations': info.recommendations
    }

def analyze_memory_usage(java_code: str) -> dict:
    """Analyze memory usage of Java code."""
    analyzer = MemoryUsageAnalyzer()
    info = analyzer.analyze(java_code)
    return {
        'estimated_usage': info.estimated_memory,
        'object_allocations': info.object_allocations,
        'potential_leaks': info.potential_leaks,
        'optimization_suggestions': info.recommendations
    }

def analyze_performance(java_code: str) -> dict:
    """Analyze performance of Java code."""
    analyzer = PerformanceAnalyzer()
    info = analyzer.analyze(java_code)
    return {
        'complexity_score': info.complexity_score,
        'bottlenecks': info.bottlenecks,
        'io_operations': info.io_operations,
        'recommendations': info.recommendations
    }

def analyze_code_quality(java_code: str) -> dict:
    """Analyze code quality of Java code."""
    analyzer = CodeQualityAnalyzer()
    info = analyzer.analyze(java_code)
    return {
        'maintainability_score': info.maintainability_score,
        'code_smells': info.code_smells,
        'best_practices': info.best_practices,
        'documentation': info.documentation,
        'naming_conventions': info.naming_conventions,
        'complexity_issues': info.complexity_issues,
        'recommendations': info.recommendations
    }

if __name__ == '__main__':
    app.run(debug=True) 