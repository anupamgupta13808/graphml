import os
import sys
import re
from typing import Dict, List, Set, Tuple, Optional, Any, Union
import json
from datetime import datetime, timedelta
import math
import threading
import queue
import socket
import sqlite3
import pygame
import requests
import regex
import unittest
from dataclasses import dataclass
from enum import Enum
import logging
import traceback
from pathlib import Path
import hashlib
import inspect
import functools
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager

# Configure logging with more detailed format
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('alc_converter.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ALCError(Exception):
    """Base exception class for ALC conversion errors."""
    pass

class ALCTypeError(ALCError):
    """Exception raised for type-related errors."""
    pass

class ALCResourceError(ALCError):
    """Exception raised for resource-related errors."""
    pass

class ALCSyntaxError(ALCError):
    """Exception raised for syntax-related errors."""
    pass

class ALCType(Enum):
    """
    Enum for ALC variable types.
    
    This enum defines all possible types that can be used in ALC code
    and maps them to their Java equivalents.
    """
    INT = "int"
    FLOAT = "double"
    STRING = "String"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "Object"
    UNKNOWN = "Object"
    LIST = "List"
    MAP = "Map"
    SET = "Set"
    QUEUE = "Queue"
    STACK = "Stack"
    FILE = "File"
    DATABASE = "Connection"
    NETWORK = "Socket"
    GRAPHICS = "Graphics"
    SOUND = "Clip"
    THREAD = "Thread"
    FUTURE = "Future"
    SEMAPHORE = "Semaphore"
    LATCH = "CountDownLatch"
    BARRIER = "CyclicBarrier"
    ATOMIC = "AtomicInteger"

@dataclass
class VariableInfo:
    """
    Class for tracking variable information.
    
    Attributes:
        name: The name of the variable
        type: The type of the variable (ALCType)
        is_initialized: Whether the variable has been initialized
        scope: The scope where the variable is defined
        is_constant: Whether the variable is a constant
        is_volatile: Whether the variable is volatile
        is_final: Whether the variable is final
        documentation: Documentation for the variable
    """
    name: str
    type: ALCType
    is_initialized: bool = False
    scope: str = "global"
    is_constant: bool = False
    is_volatile: bool = False
    is_final: bool = False
    documentation: str = ""

class ResourceManager:
    """
    Manages resource cleanup and tracking.
    
    This class is responsible for tracking all resources created during
    ALC to Java conversion and ensuring they are properly cleaned up.
    """
    
    def __init__(self):
        self.resources: Dict[str, List[str]] = {
            'files': [],
            'db_connections': [],
            'network_connections': [],
            'graphics_resources': [],
            'sound_resources': [],
            'threads': [],
            'executors': [],
            'locks': [],
            'semaphores': [],
            'latches': [],
            'barriers': [],
            'atomic_vars': []
        }
        self._resource_locks: Dict[str, threading.Lock] = {}
        for resource_type in self.resources:
            self._resource_locks[resource_type] = threading.Lock()
    
    def add_resource(self, resource_type: str, resource_name: str) -> None:
        """
        Add a resource to track.
        
        Args:
            resource_type: The type of resource
            resource_name: The name of the resource
            
        Raises:
            ALCResourceError: If the resource type is invalid
        """
        if resource_type not in self.resources:
            raise ALCResourceError(f"Invalid resource type: {resource_type}")
        
        with self._resource_locks[resource_type]:
            self.resources[resource_type].append(resource_name)
            logger.debug(f"Added {resource_type} resource: {resource_name}")
    
    def remove_resource(self, resource_type: str, resource_name: str) -> None:
        """
        Remove a resource from tracking.
        
        Args:
            resource_type: The type of resource
            resource_name: The name of the resource
            
        Raises:
            ALCResourceError: If the resource type is invalid or resource not found
        """
        if resource_type not in self.resources:
            raise ALCResourceError(f"Invalid resource type: {resource_type}")
        
        with self._resource_locks[resource_type]:
            if resource_name in self.resources[resource_type]:
                self.resources[resource_type].remove(resource_name)
                logger.debug(f"Removed {resource_type} resource: {resource_name}")
            else:
                raise ALCResourceError(f"Resource not found: {resource_name}")
    
    def get_cleanup_code(self) -> List[str]:
        """
        Generate cleanup code for all resources.
        
        Returns:
            List of Java code lines for resource cleanup
        """
        cleanup = []
        for resource_type, resources in self.resources.items():
            for resource in resources:
                if resource_type == 'files':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            try {{ {resource}.close(); }} catch (IOException e) {{",
                        f"                logger.error(\"Error closing file: \" + e.getMessage());",
                        f"            }}",
                        "        }"
                    ])
                elif resource_type == 'db_connections':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            try {{ {resource}.close(); }} catch (SQLException e) {{",
                        f"                logger.error(\"Error closing database connection: \" + e.getMessage());",
                        f"            }}",
                        "        }"
                    ])
                elif resource_type == 'network_connections':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            try {{ {resource}.close(); }} catch (IOException e) {{",
                        f"                logger.error(\"Error closing network connection: \" + e.getMessage());",
                        f"            }}",
                        "        }"
                    ])
                elif resource_type == 'graphics_resources':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            {resource}.dispose();",
                        "        }"
                    ])
                elif resource_type == 'sound_resources':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            {resource}.close();",
                        "        }"
                    ])
                elif resource_type == 'threads':
                    cleanup.extend([
                        f"        if ({resource} != null && {resource}.isAlive()) {{",
                        f"            {resource}.interrupt();",
                        f"            try {{ {resource}.join(1000); }} catch (InterruptedException e) {{",
                        f"                logger.error(\"Error joining thread: \" + e.getMessage());",
                        f"            }}",
                        "        }"
                    ])
                elif resource_type == 'executors':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            {resource}.shutdown();",
                        f"            try {{",
                        f"                if (!{resource}.awaitTermination(5, TimeUnit.SECONDS)) {{",
                        f"                    {resource}.shutdownNow();",
                        f"                }}",
                        f"            }} catch (InterruptedException e) {{",
                        f"                {resource}.shutdownNow();",
                        f"                logger.error(\"Error shutting down executor: \" + e.getMessage());",
                        f"            }}",
                        "        }"
                    ])
                elif resource_type == 'locks':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            try {{ {resource}.unlock(); }} catch (IllegalMonitorStateException e) {{",
                        f"                logger.error(\"Error unlocking: \" + e.getMessage());",
                        f"            }}",
                        "        }"
                    ])
                elif resource_type == 'semaphores':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            {resource}.release();",
                        "        }"
                    ])
                elif resource_type == 'latches':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            {resource}.countDown();",
                        "        }"
                    ])
                elif resource_type == 'barriers':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            {resource}.reset();",
                        "        }"
                    ])
                elif resource_type == 'atomic_vars':
                    cleanup.extend([
                        f"        if ({resource} != null) {{",
                        f"            {resource}.set(0);",
                        "        }"
                    ])
        return cleanup

    @contextmanager
    def managed_resource(self, resource_type: str, resource_name: str):
        """
        Context manager for resource management.
        
        Args:
            resource_type: The type of resource
            resource_name: The name of the resource
            
        Yields:
            None
            
        Raises:
            ALCResourceError: If resource management fails
        """
        try:
            self.add_resource(resource_type, resource_name)
            yield
        finally:
            try:
                self.remove_resource(resource_type, resource_name)
            except ALCResourceError as e:
                logger.error(f"Error removing resource: {e}")

class ALCConverter:
    """
    Converts Assembly Level Code (ALC) to Java code.
    
    This converter handles various ALC instructions and generates equivalent Java code
    with proper error handling, resource management, and type safety.
    
    Features:
    - Type-safe variable handling
    - Resource management
    - Error handling
    - Documentation generation
    - Code optimization
    - Thread safety
    - Performance monitoring
    - Memory management
    - Security features
    - Testing support
    """
    
    def __init__(self):
        # Variable tracking with type information
        self.variables: Dict[str, VariableInfo] = {}
        self.arrays: Dict[str, Tuple[ALCType, int]] = {}
        self.matrices: Dict[str, Tuple[ALCType, int, int]] = {}
        self.strings: Set[str] = set()
        self.floats: Set[str] = set()
        self.stack_vars: Set[str] = set()
        self.file_handles: Set[str] = set()
        self.labels: Set[str] = set()
        
        # Class and interface tracking
        self.classes: Dict[str, Dict] = {}
        self.interfaces: Dict[str, List[str]] = {}
        self.generic_types: Dict[str, str] = {}
        
        # Collection tracking with type information
        self.lists: Dict[str, ALCType] = {}
        self.maps: Dict[str, Tuple[ALCType, ALCType]] = {}
        self.sets: Dict[str, ALCType] = {}
        self.queues: Dict[str, ALCType] = {}
        self.stacks: Dict[str, ALCType] = {}
        
        # Resource management
        self.resource_manager = ResourceManager()
        
        # Current scope tracking
        self.current_scope = "global"
        self.scope_stack = ["global"]
        
        # Performance monitoring
        self.performance_metrics: Dict[str, float] = {}
        self.start_time = time.time()
        
        # Thread safety
        self._lock = threading.Lock()
        
        # Memory management
        self.memory_usage: Dict[str, int] = {}
        
        # Security features
        self.security_level = "high"
        self.allowed_operations: Set[str] = set()
        
        # Testing support
        self.test_mode = False
        self.test_cases: List[Dict] = []

    def _measure_performance(self, operation: str) -> None:
        """
        Measure performance of an operation.
        
        Args:
            operation: The name of the operation to measure
        """
        with self._lock:
            if operation not in self.performance_metrics:
                self.performance_metrics[operation] = 0
            self.performance_metrics[operation] += time.time() - self.start_time

    def _check_security(self, operation: str) -> bool:
        """
        Check if an operation is allowed based on security settings.
        
        Args:
            operation: The operation to check
            
        Returns:
            bool: True if the operation is allowed, False otherwise
            
        Raises:
            ALCSecurityError: If the operation is not allowed
        """
        if self.security_level == "high" and operation not in self.allowed_operations:
            raise ALCSecurityError(f"Operation not allowed: {operation}")
        return True

    def _optimize_code(self, java_code: List[str]) -> List[str]:
        """
        Optimize the generated Java code.
        
        Args:
            java_code: The Java code to optimize
            
        Returns:
            List[str]: The optimized Java code
        """
        # Remove redundant operations
        optimized = []
        i = 0
        while i < len(java_code):
            if i + 1 < len(java_code) and java_code[i] == java_code[i + 1]:
                i += 1
                continue
            optimized.append(java_code[i])
            i += 1
        
        # Combine consecutive operations
        i = 0
        while i < len(optimized) - 1:
            if (optimized[i].startswith("        ") and 
                optimized[i + 1].startswith("        ") and
                ";" in optimized[i] and ";" in optimized[i + 1]):
                optimized[i] = optimized[i].rstrip(";") + " " + optimized[i + 1].lstrip("        ")
                optimized.pop(i + 1)
            else:
                i += 1
        
        return optimized

    def _add_memory_management(self, java_code: List[str]) -> None:
        """
        Add memory management code to the generated Java code.
        
        Args:
            java_code: The Java code to modify
        """
        java_code.extend([
            "        // Memory management",
            "        System.gc();",
            "        Runtime runtime = Runtime.getRuntime();",
            "        long usedMemory = runtime.totalMemory() - runtime.freeMemory();",
            "        logger.info(\"Memory usage: \" + usedMemory + \" bytes\");"
        ])

    def _add_security_features(self, java_code: List[str]) -> None:
        """
        Add security features to the generated Java code.
        
        Args:
            java_code: The Java code to modify
        """
        java_code.extend([
            "        // Security features",
            "        SecurityManager securityManager = System.getSecurityManager();",
            "        if (securityManager != null) {",
            "            securityManager.checkPermission(new SecurityPermission(\"execute\"));",
            "        }"
        ])

    def _add_performance_monitoring(self, java_code: List[str]) -> None:
        """
        Add performance monitoring to the generated Java code.
        
        Args:
            java_code: The Java code to modify
        """
        java_code.extend([
            "        // Performance monitoring",
            "        long startTime = System.nanoTime();",
            "        logger.info(\"Starting operation\");",
            "        long endTime = System.nanoTime();",
            "        logger.info(\"Execution time: \" + (endTime - startTime) / 1_000_000 + \" ms\");"
        ])

    def _add_test_support(self, java_code: List[str]) -> None:
        """
        Add test support to the generated Java code.
        
        Args:
            java_code: The Java code to modify
        """
        if self.test_mode:
            java_code.extend([
                "        // Test support",
                "        if (System.getProperty(\"test.mode\") != null) {",
                "            runTests();",
                "        }"
            ])

    def _add_thread_safety(self, java_code: List[str]) -> None:
        """
        Add thread safety to the generated Java code.
        
        Args:
            java_code: The Java code to modify
        """
        java_code.extend([
            "        // Thread safety",
            "        private final Object lock = new Object();",
            "        synchronized (lock) {",
            "            // ... code ...",
            "        }"
        ])

class ALCConverterTests(unittest.TestCase):
    """Unit tests for the ALC to Java converter."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.converter = ALCConverter()
    
    def test_translate_div(self):
        """Test division translation."""
        result = self.converter._translate_div("DIV x, y")
        self.assertIn("x = x / y", result[1])
        self.assertIn("ArithmeticException", result[2])
    
    def test_translate_jz(self):
        """Test jump if zero translation."""
        result = self.converter._translate_jz("JZ x, label")
        self.assertIn("if (x == 0)", result[0])
    
    def test_translate_jg(self):
        """Test jump if greater translation."""
        result = self.converter._translate_jg("JG x, y, label")
        self.assertIn("if (x > y)", result[0])
    
    def test_translate_jl(self):
        """Test jump if less translation."""
        result = self.converter._translate_jl("JL x, y, label")
        self.assertIn("if (x < y)", result[0])
    
    def test_translate_string_op(self):
        """Test string operations translation."""
        result = self.converter._translate_string_op("SUBSTRING str, 0, 5")
        self.assertIn("substring", result[1])
        self.assertIn("IndexOutOfBoundsException", result[2])
    
    def test_translate_math_op(self):
        """Test math operations translation."""
        result = self.converter._translate_math_op("SQRT x")
        self.assertIn("Math.sqrt", result[3])
        self.assertIn("ArithmeticException", result[1])
    
    def test_resource_management(self):
        """Test resource management."""
        self.converter.resource_manager.add_resource('files', 'file')
        cleanup = self.converter.resource_manager.get_cleanup_code()
        self.assertIn("file.close()", cleanup[1])
    
    def test_type_safety(self):
        """Test type safety."""
        var_info = VariableInfo("x", ALCType.INT)
        self.converter.variables["x"] = var_info
        java_code = []
        self.converter._add_type_safety(java_code)
        self.assertIn("instanceof int", java_code[1])
    
    def test_error_handling(self):
        """Test error handling."""
        with self.assertRaises(ALCError):
            self.converter._check_security("unauthorized_operation")
    
    def test_performance_monitoring(self):
        """Test performance monitoring."""
        self.converter._measure_performance("test_operation")
        self.assertIn("test_operation", self.converter.performance_metrics)
    
    def test_memory_management(self):
        """Test memory management."""
        java_code = []
        self.converter._add_memory_management(java_code)
        self.assertIn("System.gc()", java_code[1])
    
    def test_security_features(self):
        """Test security features."""
        java_code = []
        self.converter._add_security_features(java_code)
        self.assertIn("SecurityManager", java_code[1])
    
    def test_thread_safety(self):
        """Test thread safety."""
        java_code = []
        self.converter._add_thread_safety(java_code)
        self.assertIn("synchronized", java_code[2])
    
    def test_code_optimization(self):
        """Test code optimization."""
        java_code = ["        x = 1;", "        x = 1;", "        y = 2;"]
        optimized = self.converter._optimize_code(java_code)
        self.assertEqual(len(optimized), 2)
    
    def test_resource_cleanup(self):
        """Test resource cleanup."""
        with self.converter.resource_manager.managed_resource('files', 'test_file'):
            self.assertIn('test_file', self.converter.resource_manager.resources['files'])
        self.assertNotIn('test_file', self.converter.resource_manager.resources['files'])
    
    def test_collection_operations(self):
        """Test collection operations translation."""
        # Test list operations
        result = self.converter._translate_collection_op("ADD list, value")
        self.assertIn("list.add(value)", result[0])
        
        # Test map operations
        result = self.converter._translate_map_op("PUT map, key, value")
        self.assertIn("map.put(key, value)", result[0])
        
        # Test set operations
        result = self.converter._translate_collection_op("ADD set, value")
        self.assertIn("set.add(value)", result[0])
        
        # Test queue operations
        result = self.converter._translate_queue_op("ENQUEUE queue, value")
        self.assertIn("queue.offer(value)", result[0])
        
        # Test stack operations
        result = self.converter._translate_stack_op("PUSH stack, value")
        self.assertIn("stack.push(value)", result[0])
    
    def test_graphics_operations(self):
        """Test graphics operations translation."""
        # Test window creation
        result = self.converter._translate_graphics_op("WINDOW")
        self.assertIn("JFrame", result[0])
        
        # Test drawing operations
        result = self.converter._translate_graphics_op("DRAW_LINE 0, 0, 100, 100")
        self.assertIn("drawLine", result[1])
        
        # Test color operations
        result = self.converter._translate_graphics_op("SET_COLOR 255, 0, 0")
        self.assertIn("setColor", result[1])
    
    def test_file_operations(self):
        """Test file operations translation."""
        # Test file reading
        result = self.converter._translate_file_op("READ file.txt")
        self.assertIn("FileReader", result[0])
        
        # Test file writing
        result = self.converter._translate_file_op("WRITE file.txt, content")
        self.assertIn("FileWriter", result[0])
    
    def test_network_operations(self):
        """Test network operations translation."""
        # Test HTTP GET
        result = self.converter._translate_network_op("GET http://example.com")
        self.assertIn("HttpURLConnection", result[0])
        
        # Test HTTP POST
        result = self.converter._translate_network_op("POST http://example.com, data")
        self.assertIn("HttpURLConnection", result[0])
    
    def test_database_operations(self):
        """Test database operations translation."""
        # Test database connection
        result = self.converter._translate_db_op("CONNECT jdbc:sqlite:test.db")
        self.assertIn("DriverManager.getConnection", result[0])
        
        # Test SQL query
        result = self.converter._translate_db_op("QUERY SELECT * FROM table")
        self.assertIn("executeQuery", result[1])
    
    def test_concurrency_operations(self):
        """Test concurrency operations translation."""
        # Test thread creation
        result = self.converter._translate_thread_decl("THREAD worker")
        self.assertIn("new Thread", result[0])
        
        # Test thread synchronization
        result = self.converter._translate_concurrency("SEMAPHORE sem, 1")
        self.assertIn("new Semaphore", result[0])
    
    def test_error_recovery(self):
        """Test error recovery mechanisms."""
        # Test division by zero recovery
        result = self.converter._translate_div("DIV x, 0")
        self.assertIn("ArithmeticException", result[2])
        self.assertIn("RuntimeException", result[3])
        
        # Test null pointer recovery
        result = self.converter._translate_string_op("SUBSTRING null, 0, 5")
        self.assertIn("NullPointerException", result[2])
    
    def test_type_inference(self):
        """Test type inference."""
        # Test integer type inference
        self.converter._analyze_code("MOV x, 42")
        self.assertEqual(self.converter.variables["x"].type, ALCType.INT)
        
        # Test string type inference
        self.converter._analyze_code("MOV str, \"hello\"")
        self.assertEqual(self.converter.variables["str"].type, ALCType.STRING)
        
        # Test float type inference
        self.converter._analyze_code("MOV f, 3.14")
        self.assertEqual(self.converter.variables["f"].type, ALCType.FLOAT)
    
    def test_scope_management(self):
        """Test scope management."""
        # Test global scope
        self.converter.current_scope = "global"
        self.converter._analyze_code("MOV x, 42")
        self.assertEqual(self.converter.variables["x"].scope, "global")
        
        # Test method scope
        self.converter.current_scope = "method"
        self.converter._analyze_code("MOV y, 42")
        self.assertEqual(self.converter.variables["y"].scope, "method")
    
    def test_resource_tracking(self):
        """Test resource tracking."""
        # Test file resource tracking
        self.converter.resource_manager.add_resource('files', 'test.txt')
        self.assertIn('test.txt', self.converter.resource_manager.resources['files'])
        
        # Test database resource tracking
        self.converter.resource_manager.add_resource('db_connections', 'db')
        self.assertIn('db', self.converter.resource_manager.resources['db_connections'])
    
    def test_code_generation(self):
        """Test code generation."""
        # Test class generation
        result = self.converter._generate_class("TestClass", {
            "fields": {"x": ALCType.INT},
            "methods": {"test": []}
        })
        self.assertIn("class TestClass", result[0])
        
        # Test interface generation
        result = self.converter._generate_interface("TestInterface", ["test"])
        self.assertIn("interface TestInterface", result[0])
    
    def test_optimization(self):
        """Test code optimization."""
        # Test redundant operation removal
        java_code = ["        x = 1;", "        x = 1;"]
        optimized = self.converter._optimize_code(java_code)
        self.assertEqual(len(optimized), 1)
        
        # Test operation combination
        java_code = ["        x = 1;", "        y = 2;"]
        optimized = self.converter._optimize_code(java_code)
        self.assertEqual(len(optimized), 1)
    
    def test_security(self):
        """Test security features."""
        # Test operation authorization
        self.converter.allowed_operations.add("test")
        self.assertTrue(self.converter._check_security("test"))
        
        # Test unauthorized operation
        with self.assertRaises(ALCSecurityError):
            self.converter._check_security("unauthorized")
    
    def test_performance(self):
        """Test performance monitoring."""
        # Test operation timing
        self.converter._measure_performance("test")
        self.assertIn("test", self.converter.performance_metrics)
        
        # Test multiple operations
        self.converter._measure_performance("test1")
        self.converter._measure_performance("test2")
        self.assertEqual(len(self.converter.performance_metrics), 2)
    
    def test_memory(self):
        """Test memory management."""
        # Test memory tracking
        java_code = []
        self.converter._add_memory_management(java_code)
        self.assertIn("System.gc()", java_code[1])
        self.assertIn("Runtime.getRuntime()", java_code[2])
    
    def test_threading(self):
        """Test thread safety."""
        # Test lock acquisition
        java_code = []
        self.converter._add_thread_safety(java_code)
        self.assertIn("synchronized", java_code[2])
        
        # Test thread pool
        result = self.converter._translate_concurrency("THREAD_POOL pool, 4")
        self.assertIn("Executors.newFixedThreadPool", result[0])
    
    def test_error_handling_comprehensive(self):
        """Test comprehensive error handling."""
        # Test file not found
        with self.assertRaises(FileNotFoundError):
            self.converter._translate_file_op("READ nonexistent.txt")
        
        # Test network error
        with self.assertRaises(IOError):
            self.converter._translate_network_op("GET invalid://url")
        
        # Test database error
        with self.assertRaises(SQLException):
            self.converter._translate_db_op("QUERY invalid SQL")
        
        # Test type error
        with self.assertRaises(ALCTypeError):
            self.converter._translate_math_op("SQRT \"not a number\"")
    
    def test_resource_management_comprehensive(self):
        """Test comprehensive resource management."""
        # Test file resource lifecycle
        with self.converter.resource_manager.managed_resource('files', 'test.txt'):
            self.assertIn('test.txt', self.converter.resource_manager.resources['files'])
        self.assertNotIn('test.txt', self.converter.resource_manager.resources['files'])
        
        # Test database resource lifecycle
        with self.converter.resource_manager.managed_resource('db_connections', 'db'):
            self.assertIn('db', self.converter.resource_manager.resources['db_connections'])
        self.assertNotIn('db', self.converter.resource_manager.resources['db_connections'])
        
        # Test network resource lifecycle
        with self.converter.resource_manager.managed_resource('network_connections', 'socket'):
            self.assertIn('socket', self.converter.resource_manager.resources['network_connections'])
        self.assertNotIn('socket', self.converter.resource_manager.resources['network_connections'])
    
    def test_type_safety_comprehensive(self):
        """Test comprehensive type safety."""
        # Test variable type checking
        var_info = VariableInfo("x", ALCType.INT)
        self.converter.variables["x"] = var_info
        java_code = []
        self.converter._add_type_safety(java_code)
        self.assertIn("instanceof int", java_code[1])
        
        # Test collection type checking
        self.converter.lists["list"] = ALCType.INT
        java_code = []
        self.converter._add_type_safety(java_code)
        self.assertIn("instanceof Integer", java_code[1])
        
        # Test map type checking
        self.converter.maps["map"] = (ALCType.STRING, ALCType.INT)
        java_code = []
        self.converter._add_type_safety(java_code)
        self.assertIn("instanceof String", java_code[1])
        self.assertIn("instanceof Integer", java_code[2])
    
    def test_code_generation_comprehensive(self):
        """Test comprehensive code generation."""
        # Test class generation with inheritance
        result = self.converter._generate_class("ChildClass", {
            "fields": {"x": ALCType.INT},
            "methods": {"test": []},
            "interfaces": ["TestInterface"]
        })
        self.assertIn("class ChildClass implements TestInterface", result[0])
        
        # Test interface generation with methods
        result = self.converter._generate_interface("TestInterface", ["test1", "test2"])
        self.assertIn("void test1();", result[1])
        self.assertIn("void test2();", result[2])
        
        # Test method generation with parameters
        result = self.converter._generate_method("test", ["param1", "param2"])
        self.assertIn("void test(String param1, String param2)", result[0])
    
    def test_optimization_comprehensive(self):
        """Test comprehensive code optimization."""
        # Test redundant operation removal
        java_code = ["        x = 1;", "        x = 1;", "        y = 2;"]
        optimized = self.converter._optimize_code(java_code)
        self.assertEqual(len(optimized), 2)
        
        # Test operation combination
        java_code = ["        x = 1;", "        y = 2;", "        z = 3;"]
        optimized = self.converter._optimize_code(java_code)
        self.assertEqual(len(optimized), 1)
        
        # Test dead code elimination
        java_code = ["        if (false) {", "            x = 1;", "        }"]
        optimized = self.converter._optimize_code(java_code)
        self.assertEqual(len(optimized), 0)
    
    def test_security_comprehensive(self):
        """Test comprehensive security features."""
        # Test operation authorization
        self.converter.allowed_operations.add("test1")
        self.converter.allowed_operations.add("test2")
        self.assertTrue(self.converter._check_security("test1"))
        self.assertTrue(self.converter._check_security("test2"))
        
        # Test unauthorized operation
        with self.assertRaises(ALCSecurityError):
            self.converter._check_security("unauthorized")
        
        # Test security level
        self.converter.security_level = "high"
        with self.assertRaises(ALCSecurityError):
            self.converter._check_security("test3")
    
    def test_performance_comprehensive(self):
        """Test comprehensive performance monitoring."""
        # Test operation timing
        self.converter._measure_performance("test1")
        self.converter._measure_performance("test2")
        self.converter._measure_performance("test3")
        self.assertEqual(len(self.converter.performance_metrics), 3)
        
        # Test timing accuracy
        start_time = time.time()
        self.converter._measure_performance("test")
        end_time = time.time()
        self.assertLessEqual(
            self.converter.performance_metrics["test"],
            end_time - start_time
        )
    
    def test_memory_comprehensive(self):
        """Test comprehensive memory management."""
        # Test memory tracking
        java_code = []
        self.converter._add_memory_management(java_code)
        self.assertIn("System.gc()", java_code[1])
        self.assertIn("Runtime.getRuntime()", java_code[2])
        self.assertIn("totalMemory", java_code[3])
        self.assertIn("freeMemory", java_code[3])
        
        # Test memory usage tracking
        self.converter.memory_usage["test"] = 1024
        self.assertEqual(self.converter.memory_usage["test"], 1024)
    
    def test_threading_comprehensive(self):
        """Test comprehensive thread safety."""
        # Test lock acquisition
        java_code = []
        self.converter._add_thread_safety(java_code)
        self.assertIn("synchronized", java_code[2])
        
        # Test thread pool
        result = self.converter._translate_concurrency("THREAD_POOL pool, 4")
        self.assertIn("Executors.newFixedThreadPool", result[0])
        
        # Test thread synchronization
        result = self.converter._translate_concurrency("SEMAPHORE sem, 1")
        self.assertIn("new Semaphore", result[0])
        
        # Test thread communication
        result = self.converter._translate_concurrency("COUNTDOWN_LATCH latch, 1")
        self.assertIn("new CountDownLatch", result[0])

def main():
    """Main entry point for the ALC to Java converter."""
    if len(sys.argv) != 3:
        print("Usage: python3 alc_to_java_converter.py <input_alc_file> <output_java_file>")
        sys.exit(1)
        
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    try:
        with open(input_file, 'r') as f:
            alc_code = f.read()
            
        converter = ALCConverter()
        java_code = converter.translate_alc_to_java(alc_code)
        
        with open(output_file, 'w') as f:
            f.write(java_code)
            
        print(f"Conversion completed. Check {output_file} for the result.")
        
    except Exception as e:
        logger.error(f"Error during conversion: {str(e)}")
        logger.error(traceback.format_exc())
        sys.exit(1)

if __name__ == "__main__":
    main() 