from typing import List, Dict, Any, Optional, Set
from dataclasses import dataclass
from .instruction_mapper import InstructionMapper
from .hlasm_parser import Instruction, Operand, ControlSection, OperandType

@dataclass
class JavaVariable:
    name: str
    type: str
    value: Optional[str] = None
    is_array: bool = False
    array_size: Optional[int] = None
    is_constant: bool = False
    is_static: bool = False
    is_final: bool = False
    access_modifier: str = "private"

@dataclass
class JavaMethod:
    name: str
    return_type: str
    parameters: List[JavaVariable]
    body: List[str]
    access_modifier: str = "public"
    is_static: bool = False
    is_final: bool = False
    throws: List[str] = None

@dataclass
class JavaClass:
    name: str
    fields: List[JavaVariable]
    methods: List[JavaMethod]
    imports: Set[str]
    package: str = ""
    access_modifier: str = "public"
    is_final: bool = False
    extends: Optional[str] = None
    implements: List[str] = None

class JavaGenerator:
    def __init__(self):
        self.instruction_mapper = InstructionMapper()
        self.java_lines: List[str] = []
        self.indent_level = 0
        self.current_class: Optional[JavaClass] = None
        self.methods: Dict[str, JavaMethod] = {}
        self.fields: Dict[str, str] = {}
        self.imports: Set[str] = set()
        self.package = "hlasm"
        
        # Initialize standard imports
        self.imports.update({
            "java.util.*",
            "java.io.*",
            "java.nio.*",
            "java.util.concurrent.*",
            "java.util.concurrent.atomic.*",
            "java.lang.*",
            "java.math.*"
        })

    def generate_java_code(self, sections: Dict[str, ControlSection]) -> str:
        """Generate Java code from HLASM control sections."""
        java_code = []
        
        # Add package declaration
        java_code.append("package hlasm;")
        java_code.append("")
        
        # Add imports
        for imp in sorted(self.imports):
            java_code.append(f"import {imp};")
        java_code.append("")
        
        # Generate code for each section
        for section_name, section in sections.items():
            java_code.extend(self._generate_section(section))
        
        return "\n".join(java_code)

    def _generate_section(self, section: ControlSection) -> List[str]:
        """Generate Java code for a control section."""
        java_code = []
        
        # Create class for the section
        class_name = self._to_java_identifier(section.name)
        self.current_class = JavaClass(
            name=class_name,
            fields=[],
            methods=[],
            imports=self.imports,
            package="hlasm"
        )
        
        # Add class declaration
        java_code.append(f"public class {class_name} {{")
        self.indent_level += 1
        
        # Generate fields for symbols
        java_code.extend(self._generate_symbol_fields(section))
        
        # Generate register array
        java_code.extend(self._generate_register_array())
        
        # Generate memory array
        java_code.extend(self._generate_memory_array())
        
        # Generate condition code
        java_code.extend(self._generate_condition_code())
        
        # Generate main method
        java_code.extend(self._generate_main_method(section))
        
        # Generate helper methods
        java_code.extend(self._generate_helper_methods())
        
        self.indent_level -= 1
        java_code.append("}")
        
        return java_code

    def _generate_symbol_fields(self, section: ControlSection) -> List[str]:
        """Generate Java fields for HLASM symbols."""
        java_code = []
        
        for symbol, value in section.symbols.items():
            field_name = self._to_java_identifier(symbol)
            java_code.append(f"{self.indent * self.indent_level}private static final int {field_name} = {value};")
        
        if section.symbols:
            java_code.append("")
        
        return java_code

    def _generate_register_array(self) -> List[str]:
        """Generate register array and access methods."""
        java_code = []
        
        java_code.append(f"{self.indent * self.indent_level}private static int[] registers = new int[16];")
        java_code.append("")
        
        java_code.append(f"{self.indent * self.indent_level}private static int getRegister(int reg) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return registers[reg];")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        java_code.append(f"{self.indent * self.indent_level}private static void setRegister(int reg, int value) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}registers[reg] = value;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        return java_code

    def _generate_memory_array(self) -> List[str]:
        """Generate memory array and access methods."""
        java_code = []
        
        java_code.append(f"{self.indent * self.indent_level}private static byte[] memory = new byte[1024 * 1024];")  # 1MB memory
        java_code.append("")
        
        java_code.append(f"{self.indent * self.indent_level}private static int getMemory(int address) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return memory[address] & 0xFF;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        java_code.append(f"{self.indent * self.indent_level}private static void setMemory(int address, int value) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}memory[address] = (byte) (value & 0xFF);")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        return java_code

    def _generate_condition_code(self) -> List[str]:
        """Generate condition code variable and access methods."""
        java_code = []
        
        java_code.append(f"{self.indent * self.indent_level}private static int conditionCode = 0;")
        java_code.append("")
        
        java_code.append(f"{self.indent * self.indent_level}private static void setConditionCode(int value) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}conditionCode = value;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        java_code.append(f"{self.indent * self.indent_level}private static int getConditionCode() {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return conditionCode;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        return java_code

    def _generate_main_method(self, section: ControlSection) -> List[str]:
        """Generate the main method for a control section."""
        java_code = []
        
        # Add main method declaration
        java_code.append(f"{self.indent * self.indent_level}public static void main(String[] args) {{")
        self.indent_level += 1
        
        # Generate code for each instruction
        for instruction in section.instructions:
            java_code.extend(self._generate_instruction(instruction))
        
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        return java_code

    def _generate_instruction(self, instruction: Instruction) -> List[str]:
        """Generate Java code for a single HLASM instruction."""
        java_code = []
        
        # Handle assembler directives
        if instruction.operation in ['START', 'CSECT', 'DSECT', 'RSECT', 'END']:
            return java_code
        
        # Handle data definition directives
        if instruction.operation in ['DC', 'DS']:
            return self._generate_data_definition(instruction)
        
        # Handle macro definitions
        if instruction.operation in ['MACRO', 'MEND']:
            return java_code
        
        # Handle literal pool
        if instruction.operation == 'LTORG':
            return self._generate_literal_pool(instruction)
        
        # Get the Java method name and operands
        method_name = instruction.instruction_mapping.java_method if instruction.instruction_mapping else None
        operands = instruction.operands
        
        if not method_name:
            # Handle unknown instructions
            java_code.append(f"{self.indent * self.indent_level}// Unknown instruction: {instruction.operation}")
            return java_code
        
        # Generate method call based on instruction type
        if method_name == "loadRegister":
            java_code.append(f"{self.indent * self.indent_level}setRegister({self._operand_to_java(operands[0])}, getMemory({self._operand_to_java(operands[1])}));")
        elif method_name == "storeRegister":
            java_code.append(f"{self.indent * self.indent_level}setMemory({self._operand_to_java(operands[1])}, getRegister({self._operand_to_java(operands[0])}));")
        elif method_name == "add":
            java_code.append(f"{self.indent * self.indent_level}setRegister({self._operand_to_java(operands[0])}, getRegister({self._operand_to_java(operands[0])}) + getMemory({self._operand_to_java(operands[1])}));")
        elif method_name == "subtract":
            java_code.append(f"{self.indent * self.indent_level}setRegister({self._operand_to_java(operands[0])}, getRegister({self._operand_to_java(operands[0])}) - getMemory({self._operand_to_java(operands[1])}));")
        elif method_name == "multiply":
            java_code.append(f"{self.indent * self.indent_level}setRegister({self._operand_to_java(operands[0])}, getRegister({self._operand_to_java(operands[0])}) * getMemory({self._operand_to_java(operands[1])}));")
        elif method_name == "divide":
            java_code.append(f"{self.indent * self.indent_level}setRegister({self._operand_to_java(operands[0])}, getRegister({self._operand_to_java(operands[0])}) / getMemory({self._operand_to_java(operands[1])}));")
        elif method_name == "compare":
            java_code.append(f"{self.indent * self.indent_level}setConditionCode(Integer.compare(getRegister({self._operand_to_java(operands[0])}), getMemory({self._operand_to_java(operands[1])})));")
        elif method_name == "branch":
            java_code.append(f"{self.indent * self.indent_level}if (getConditionCode() == 0) {{")
            self.indent_level += 1
            java_code.append(f"{self.indent * self.indent_level}return;")
            self.indent_level -= 1
            java_code.append(f"{self.indent * self.indent_level}}}")
        else:
            # Handle other instructions
            java_code.append(f"{self.indent * self.indent_level}// TODO: Implement {instruction.operation} instruction")
        
        return java_code

    def _generate_data_definition(self, instruction: Instruction) -> List[str]:
        """Generate Java code for data definition directives."""
        java_code = []
        
        if instruction.operation == 'DC':
            # Handle constant definition
            for operand in instruction.operands:
                if operand.type == OperandType.STRING:
                    # Handle character constants
                    value = operand.value.strip("'")
                    java_code.append(f"{self.indent * self.indent_level}private static final String {instruction.label} = \"{value}\";")
                elif operand.type == OperandType.IMMEDIATE:
                    # Handle numeric constants
                    java_code.append(f"{self.indent * self.indent_level}private static final int {instruction.label} = {operand.value};")
        elif instruction.operation == 'DS':
            # Handle storage definition
            for operand in instruction.operands:
                if operand.type == OperandType.IMMEDIATE:
                    # Handle storage allocation
                    size = int(operand.value)
                    java_code.append(f"{self.indent * self.indent_level}private static final byte[] {instruction.label} = new byte[{size}];")
        
        return java_code

    def _generate_literal_pool(self, instruction: Instruction) -> List[str]:
        """Generate Java code for literal pool."""
        java_code = []
        
        if self.current_section and self.current_section.literals:
            java_code.append(f"{self.indent * self.indent_level}// Literal pool")
            for literal, address in self.current_section.literals.items():
                java_code.append(f"{self.indent * self.indent_level}private static final int {literal[1:]} = {address};")
        
        return java_code

    def _generate_helper_methods(self) -> List[str]:
        """Generate helper methods for the class."""
        java_code = []
        
        # Add arithmetic methods
        java_code.extend(self._generate_arithmetic_methods())
        
        # Add logical methods
        java_code.extend(self._generate_logical_methods())
        
        # Add branch methods
        java_code.extend(self._generate_branch_methods())
        
        return java_code

    def _generate_arithmetic_methods(self) -> List[str]:
        """Generate arithmetic operation methods."""
        java_code = []
        
        # Add method
        java_code.append(f"{self.indent * self.indent_level}private static int add(int a, int b) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return a + b;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        # Subtract method
        java_code.append(f"{self.indent * self.indent_level}private static int subtract(int a, int b) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return a - b;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        # Multiply method
        java_code.append(f"{self.indent * self.indent_level}private static int multiply(int a, int b) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return a * b;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        # Divide method
        java_code.append(f"{self.indent * self.indent_level}private static int divide(int a, int b) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return a / b;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        return java_code

    def _generate_logical_methods(self) -> List[str]:
        """Generate logical operation methods."""
        java_code = []
        
        # AND method
        java_code.append(f"{self.indent * self.indent_level}private static int and(int a, int b) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return a & b;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        # OR method
        java_code.append(f"{self.indent * self.indent_level}private static int or(int a, int b) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return a | b;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        # XOR method
        java_code.append(f"{self.indent * self.indent_level}private static int xor(int a, int b) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return a ^ b;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        return java_code

    def _generate_branch_methods(self) -> List[str]:
        """Generate branch operation methods."""
        java_code = []
        
        # Branch method
        java_code.append(f"{self.indent * self.indent_level}private static void branch(int address) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}if (getConditionCode() == 0) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        # Branch and link method
        java_code.append(f"{self.indent * self.indent_level}private static void branchAndLink(int reg, int address) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}setRegister(reg, getRegister(15));")  # Save return address
        java_code.append(f"{self.indent * self.indent_level}if (getConditionCode() == 0) {{")
        self.indent_level += 1
        java_code.append(f"{self.indent * self.indent_level}return;")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        self.indent_level -= 1
        java_code.append(f"{self.indent * self.indent_level}}}")
        java_code.append("")
        
        return java_code

    def _operand_to_java(self, operand: Operand) -> str:
        """Convert an HLASM operand to Java code."""
        if operand.type == 'REGISTER':
            return str(operand.base_register)
        elif operand.type == 'ADDRESS':
            displacement = operand.displacement or 0
            base_reg = operand.base_register or 0
            index_reg = operand.index_register or 0
            return f"{displacement} + getRegister({base_reg}) + getRegister({index_reg})"
        elif operand.type == 'LITERAL':
            return operand.value[1:]  # Remove the '=' prefix
        else:
            return operand.value

    def _to_java_identifier(self, name: str) -> str:
        """Convert an HLASM identifier to a valid Java identifier."""
        # Replace special characters with underscores
        name = name.replace('@', '_').replace('#', '_').replace('$', '_')
        
        # Ensure the name starts with a letter
        if not name[0].isalpha():
            name = 'L' + name
        
        return name

    @property
    def indent(self) -> str:
        """Get the current indentation string."""
        return "    "  # 4 spaces