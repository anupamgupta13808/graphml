from typing import Dict, Set, Any, Optional, List, Tuple
from dataclasses import dataclass

@dataclass
class InstructionMapping:
    java_method: str
    category: str
    description: str
    is_macro: bool = False
    macro_parameters: Optional[List[str]] = None
    floating_point: bool = False
    decimal: bool = False
    extended: bool = False
    operands: Optional[List[str]] = None

    def __post_init__(self):
        if self.operands is None:
            self.operands = []

class InstructionMapper:
    def __init__(self):
        self.instructions = {
            # Basic instructions
            'LA': InstructionMapping('loadAddress', 'Basic', 'Load Address', operands=['register', 'address']),
            'L': InstructionMapping('load', 'Basic', 'Load Register', operands=['register', 'address']),
            'ST': InstructionMapping('store', 'Basic', 'Store Register', operands=['register', 'address']),
            'A': InstructionMapping('add', 'Arithmetic', 'Add', operands=['register', 'address']),
            'S': InstructionMapping('subtract', 'Arithmetic', 'Subtract', operands=['register', 'address']),
            'M': InstructionMapping('multiply', 'Arithmetic', 'Multiply', operands=['register', 'address']),
            'D': InstructionMapping('divide', 'Arithmetic', 'Divide', operands=['register', 'address']),
            'LR': InstructionMapping('loadRegister', 'Basic', 'Load Register', operands=['register', 'register']),
            'AR': InstructionMapping('addRegister', 'Arithmetic', 'Add Register', operands=['register', 'register']),
            'SR': InstructionMapping('subtractRegister', 'Arithmetic', 'Subtract Register', operands=['register', 'register']),
            'MR': InstructionMapping('multiplyRegister', 'Arithmetic', 'Multiply Register', operands=['register', 'register']),
            'DR': InstructionMapping('divideRegister', 'Arithmetic', 'Divide Register', operands=['register', 'register']),
            'BR': InstructionMapping('branchRegister', 'Branch', 'Branch Register', operands=['register']),
            
            # Floating-point instructions
            'LDR': InstructionMapping('loadFloat', 'FloatingPoint', 'Load Floating-Point Register', floating_point=True, operands=['register', 'floating_point']),
            'ADR': InstructionMapping('addFloat', 'FloatingPoint', 'Add Floating-Point Register', floating_point=True, operands=['register', 'floating_point']),
            'SDR': InstructionMapping('subtractFloat', 'FloatingPoint', 'Subtract Floating-Point Register', floating_point=True, operands=['register', 'floating_point']),
            'MDR': InstructionMapping('multiplyFloat', 'FloatingPoint', 'Multiply Floating-Point Register', floating_point=True, operands=['register', 'floating_point']),
            'DDR': InstructionMapping('divideFloat', 'FloatingPoint', 'Divide Floating-Point Register', floating_point=True, operands=['register', 'floating_point']),
            'CDR': InstructionMapping('compareFloat', 'FloatingPoint', 'Compare Floating-Point Register', floating_point=True, operands=['register', 'floating_point']),
            'STD': InstructionMapping('storeFloat', 'FloatingPoint', 'Store Floating-Point Register', floating_point=True, operands=['register', 'floating_point']),
            
            # Decimal instructions
            'AP': InstructionMapping('addPacked', 'Decimal', 'Add Packed Decimal', decimal=True, operands=['decimal', 'decimal']),
            'SP': InstructionMapping('subtractPacked', 'Decimal', 'Subtract Packed Decimal', decimal=True, operands=['decimal', 'decimal']),
            'MP': InstructionMapping('multiplyPacked', 'Decimal', 'Multiply Packed Decimal', decimal=True, operands=['decimal', 'decimal']),
            'DP': InstructionMapping('dividePacked', 'Decimal', 'Divide Packed Decimal', decimal=True, operands=['decimal', 'decimal']),
            'CP': InstructionMapping('comparePacked', 'Decimal', 'Compare Packed Decimal', decimal=True, operands=['decimal', 'decimal']),
            'ZAP': InstructionMapping('zeroAndAddPacked', 'Decimal', 'Zero and Add Packed Decimal', decimal=True, operands=['decimal', 'decimal']),
            'CVB': InstructionMapping('convertToBinary', 'Decimal', 'Convert to Binary', decimal=True, operands=['register', 'decimal']),
            'CVD': InstructionMapping('convertToDecimal', 'Decimal', 'Convert to Decimal', decimal=True, operands=['decimal', 'register']),
            
            # Extended instructions
            'LARL': InstructionMapping('loadAddressRelativeLong', 'Extended', 'Load Address Relative Long', extended=True, operands=['register', 'address']),
            'LGRL': InstructionMapping('loadRegisterRelativeLong', 'Extended', 'Load Register Relative Long', extended=True, operands=['register', 'address']),
            'STGRL': InstructionMapping('storeRegisterRelativeLong', 'Extended', 'Store Register Relative Long', extended=True, operands=['register', 'address']),
            'LGFI': InstructionMapping('loadImmediate', 'Extended', 'Load Immediate', extended=True, operands=['register', 'immediate']),
            'LGHI': InstructionMapping('loadHalfwordImmediate', 'Extended', 'Load Halfword Immediate', extended=True, operands=['register', 'immediate']),
            'LLGF': InstructionMapping('loadLogical', 'Extended', 'Load Logical', extended=True, operands=['register', 'address']),
            'LLGFR': InstructionMapping('loadLogicalRegister', 'Extended', 'Load Logical Register', extended=True, operands=['register', 'register']),
            'LLGT': InstructionMapping('loadLogicalTest', 'Extended', 'Load Logical Test', extended=True, operands=['register', 'address']),
            'LLGTR': InstructionMapping('loadLogicalTestRegister', 'Extended', 'Load Logical Test Register', extended=True, operands=['register', 'register']),
            'BRASL': InstructionMapping('branchAndLinkShort', 'Extended', 'Branch and Link Short', extended=True, operands=['register', 'address']),
            'BRAS': InstructionMapping('branchAndLink', 'Extended', 'Branch and Link', extended=True, operands=['register', 'address']),
            
            # Compare Operations
            'C': InstructionMapping('compare', 'Compare', 'Compare', operands=['register', 'address']),
            'CR': InstructionMapping('compareRegister', 'Compare', 'Compare Register', operands=['register', 'register']),
            'CLC': InstructionMapping('compareLogical', 'Compare', 'Compare Logical', operands=['address', 'address']),
            
            # Branch Operations
            'B': InstructionMapping('branch', 'Branch', 'Branch', operands=['address']),
            'BC': InstructionMapping('branchCondition', 'Branch', 'Branch on Condition', operands=['mask', 'address']),
            'BCT': InstructionMapping('branchCount', 'Branch', 'Branch on Count', operands=['register', 'address']),
            'BCTR': InstructionMapping('branchCountRegister', 'Branch', 'Branch on Count Register', operands=['register', 'register']),
            'BALR': InstructionMapping('branchAndLink', 'Branch', 'Branch and Link', operands=['register', 'register']),
            
            # Logical Operations
            'N': InstructionMapping('and', 'Logical', 'And', operands=['register', 'address']),
            'O': InstructionMapping('or', 'Logical', 'Or', operands=['register', 'address']),
            'X': InstructionMapping('xor', 'Logical', 'Exclusive Or', operands=['register', 'address']),
            'NR': InstructionMapping('andRegister', 'Logical', 'And Register', operands=['register', 'register']),
            'OR': InstructionMapping('orRegister', 'Logical', 'Or Register', operands=['register', 'register']),
            'XR': InstructionMapping('xorRegister', 'Logical', 'Exclusive Or Register', operands=['register', 'register']),
            
            # Shift Operations
            'SLL': InstructionMapping('shiftLeftLogical', 'Shift', 'Shift Left Logical', operands=['register', 'immediate']),
            'SRL': InstructionMapping('shiftRightLogical', 'Shift', 'Shift Right Logical', operands=['register', 'immediate']),
            'SLA': InstructionMapping('shiftLeftArithmetic', 'Shift', 'Shift Left Arithmetic', operands=['register', 'immediate']),
            'SRA': InstructionMapping('shiftRightArithmetic', 'Shift', 'Shift Right Arithmetic', operands=['register', 'immediate']),
            
            # Move Operations
            'MVC': InstructionMapping('moveCharacter', 'Move', 'Move Character', operands=['address', 'address']),
            'MVCL': InstructionMapping('moveCharacterLong', 'Move', 'Move Character Long', operands=['register', 'register']),
            'MVI': InstructionMapping('moveImmediate', 'Move', 'Move Immediate', operands=['address', 'immediate']),
            
            # Load/Store Multiple
            'LM': InstructionMapping('loadMultiple', 'LoadStore', 'Load Multiple', operands=['register', 'register', 'address']),
            'STM': InstructionMapping('storeMultiple', 'LoadStore', 'Store Multiple', operands=['register', 'register', 'address']),
            
            # System Operations
            'SVC': InstructionMapping('supervisorCall', 'System', 'Supervisor Call', operands=['immediate']),
            'SSK': InstructionMapping('setStorageKey', 'System', 'Set Storage Key', operands=['register', 'register']),
            'ISK': InstructionMapping('insertStorageKey', 'System', 'Insert Storage Key', operands=['register', 'register']),
            
            # Data definition
            'DC': InstructionMapping('defineConstant', 'Data', 'Define Constant', operands=['type', 'value']),
            'DS': InstructionMapping('defineStorage', 'Data', 'Define Storage', operands=['type', 'length']),
            'DCB': InstructionMapping('defineControlBlock', 'Data', 'Define Control Block', operands=['parameters']),
            'DXD': InstructionMapping('defineExternal', 'Data', 'Define External', operands=['parameters']),
            
            # Control section directives
            'START': InstructionMapping('start', 'Control', 'Start Program', operands=['address']),
            'CSECT': InstructionMapping('controlSection', 'Control', 'Control Section', operands=[]),
            'DSECT': InstructionMapping('dummySection', 'Control', 'Dummy Section', operands=[]),
            'RSECT': InstructionMapping('relocatableSection', 'Control', 'Relocatable Section', operands=[]),
            
            # Symbol Definition
            'EQU': InstructionMapping('equate', 'Symbol', 'Equate', operands=['value']),
            'ORG': InstructionMapping('origin', 'Symbol', 'Origin', operands=['address']),
            'DROP': InstructionMapping('drop', 'Symbol', 'Drop', operands=['register']),
            'USING': InstructionMapping('using', 'Symbol', 'Using', operands=['base', 'register']),
            
            # Macro directives
            'MACRO': InstructionMapping('macro', 'Macro', 'Macro Definition', is_macro=True, operands=['parameters']),
            'MEND': InstructionMapping('macroEnd', 'Macro', 'Macro End', is_macro=True, operands=[]),
            'CALLM': InstructionMapping('callMacro', 'Macro', 'Call Macro', is_macro=True, operands=['name', 'parameters']),
            'MEXIT': InstructionMapping('macroExit', 'Macro', 'Macro Exit', is_macro=True, operands=[]),
            
            # Conditional assembly
            'AIF': InstructionMapping('if', 'Macro', 'If', is_macro=True, operands=['condition', 'label']),
            'AGO': InstructionMapping('goto', 'Macro', 'Go', is_macro=True, operands=['label']),
            'ANOP': InstructionMapping('noOperation', 'Macro', 'No Operation', is_macro=True, operands=[]),
            'MNOTE': InstructionMapping('note', 'Macro', 'Note', is_macro=True, operands=['level', 'message']),
            
            # Literal pool
            'LTORG': InstructionMapping('literalOrigin', 'Literal', 'Literal Origin', operands=[]),
            'LIT': InstructionMapping('literal', 'Literal', 'Literal', operands=['value']),
            
            # Copy/Include
            'COPY': InstructionMapping('copy', 'Include', 'Copy', operands=['member']),
            'INCLUDE': InstructionMapping('include', 'Include', 'Include', operands=['member']),
            
            # Listing Control
            'TITLE': InstructionMapping('title', 'Listing', 'Title', operands=['text']),
            'EJECT': InstructionMapping('eject', 'Listing', 'Eject', operands=[]),
            'SPACE': InstructionMapping('space', 'Listing', 'Space', operands=['lines']),
            'PRINT': InstructionMapping('print', 'Listing', 'Print', operands=['options']),
            
            # Mode
            'AMODE': InstructionMapping('addressingMode', 'Mode', 'Addressing Mode', operands=['mode']),
            'RMODE': InstructionMapping('residenceMode', 'Mode', 'Residence Mode', operands=['mode']),
            
            # External Reference
            'ALIAS': InstructionMapping('alias', 'External', 'Alias', operands=['name']),
            'ENTRY': InstructionMapping('entry', 'External', 'Entry', operands=['name']),
            'EXTRN': InstructionMapping('external', 'External', 'External', operands=['name']),
            'WXTRN': InstructionMapping('weakExternal', 'External', 'Weak External', operands=['name']),
            
            # System Macros
            'SAVE': InstructionMapping('save', 'System', 'Save Registers', is_macro=True, 
                                     macro_parameters=['regs', 'area', 'area_len'], operands=['regs', 'area', 'area_len']),
            'RETURN': InstructionMapping('return', 'System', 'Return from Subroutine', is_macro=True,
                                       macro_parameters=['regs', 'rc'], operands=['regs', 'rc']),
            'GETMAIN': InstructionMapping('getmain', 'System', 'Get Main Storage', is_macro=True,
                                        macro_parameters=['area', 'length'], operands=['area', 'length']),
            'FREEMAIN': InstructionMapping('freemain', 'System', 'Free Main Storage', is_macro=True,
                                         macro_parameters=['area', 'length'], operands=['area', 'length']),
            
            # I/O Macros
            'OPEN': InstructionMapping('open', 'IO', 'Open File', is_macro=True,
                                     macro_parameters=['dcb', 'input', 'output'], operands=['dcb', 'input', 'output']),
            'CLOSE': InstructionMapping('close', 'IO', 'Close File', is_macro=True,
                                      macro_parameters=['dcb'], operands=['dcb']),
            'GET': InstructionMapping('get', 'IO', 'Get Record', is_macro=True,
                                    macro_parameters=['dcb', 'area'], operands=['dcb', 'area']),
            'PUT': InstructionMapping('put', 'IO', 'Put Record', is_macro=True,
                                    macro_parameters=['dcb', 'area'], operands=['dcb', 'area']),
            
            # System Service
            'WTO': InstructionMapping('wto', 'Service', 'Write to Operator', is_macro=True,
                                    macro_parameters=['message'], operands=['message']),
            'WTOR': InstructionMapping('wtor', 'Service', 'Write to Operator with Reply', is_macro=True,
                                     macro_parameters=['message', 'reply'], operands=['message', 'reply']),
            'MGCR': InstructionMapping('mgcr', 'Service', 'Modify General Characteristic', is_macro=True,
                                     macro_parameters=['command'], operands=['command']),
            
            # Time/Date
            'TIME': InstructionMapping('time', 'Time', 'Get Time', is_macro=True,
                                     macro_parameters=['area'], operands=['area']),
            'DATE': InstructionMapping('date', 'Time', 'Get Date', is_macro=True,
                                     macro_parameters=['area'], operands=['area']),
            'STCK': InstructionMapping('stck', 'Time', 'Store Clock', is_macro=True,
                                     macro_parameters=['area'], operands=['area']),
            'STCKCONV': InstructionMapping('stckconv', 'Time', 'Store Clock Convert', is_macro=True,
                                         macro_parameters=['area'], operands=['area']),
            
            # Timer
            'STIMER': InstructionMapping('stimer', 'Timer', 'Set Timer', is_macro=True,
                                       macro_parameters=['wait', 'interval'], operands=['wait', 'interval']),
            'TTIMER': InstructionMapping('ttimer', 'Timer', 'Test Timer', is_macro=True,
                                       macro_parameters=['wait'], operands=['wait']),
            'STIMERM': InstructionMapping('stimerm', 'Timer', 'Set Timer Multiple', is_macro=True,
                                        macro_parameters=['wait', 'interval'], operands=['wait', 'interval']),
            'TTIMERM': InstructionMapping('ttimerm', 'Timer', 'Test Timer Multiple', is_macro=True,
                                        macro_parameters=['wait'], operands=['wait']),
            
            # End directive
            'END': InstructionMapping('end', 'Control', 'End Program', operands=[])
        }

    def get_instruction(self, operation: str) -> Optional[InstructionMapping]:
        """Get instruction mapping for an operation."""
        operation = operation.upper()
        return self.instructions.get(operation)

    def is_macro(self, operation: str) -> bool:
        """Check if an operation is a macro."""
        mapping = self.get_instruction(operation)
        return mapping is not None and mapping.is_macro

    def is_floating_point(self, operation: str) -> bool:
        """Check if an operation is a floating-point instruction."""
        mapping = self.get_instruction(operation)
        return mapping is not None and mapping.floating_point

    def is_decimal(self, operation: str) -> bool:
        """Check if an operation is a decimal arithmetic instruction."""
        mapping = self.get_instruction(operation)
        return mapping is not None and mapping.decimal

    def is_extended(self, operation: str) -> bool:
        """Check if an operation is an extended instruction."""
        mapping = self.get_instruction(operation)
        return mapping is not None and mapping.extended

    def get_java_method(self, mnemonic: str) -> Optional[str]:
        """Get the corresponding Java method name for a mnemonic."""
        instruction = self.get_instruction(mnemonic)
        return instruction.java_method if instruction else None

    def get_instruction_length(self, mnemonic: str) -> int:
        """Get the length of an instruction in bytes."""
        instruction = self.get_instruction(mnemonic)
        return instruction.length if instruction else 0

    def get_operand_types(self, mnemonic: str) -> List[str]:
        """Get the operand types for a given mnemonic."""
        instruction = self.get_instruction(mnemonic)
        return instruction.operands if instruction else []