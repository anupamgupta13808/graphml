from dataclasses import dataclass
from typing import List, Dict, Optional, Union, Tuple
from enum import Enum
import re
from .instruction_mapper import InstructionMapper, InstructionMapping

class OperandType(Enum):
    REGISTER = "REGISTER"
    ADDRESS = "ADDRESS"
    LITERAL = "LITERAL"
    IMMEDIATE = "IMMEDIATE"
    EXPRESSION = "EXPRESSION"
    MACRO_PARAM = "MACRO_PARAM"
    FLOATING_POINT = "FLOATING_POINT"
    DECIMAL = "DECIMAL"
    EXTENDED = "EXTENDED"
    STRING = "STRING"

@dataclass
class Operand:
    value: str
    type: OperandType
    base_register: Optional[str] = None
    index_register: Optional[str] = None
    displacement: Optional[int] = None
    length: Optional[int] = None
    scale: Optional[int] = None

@dataclass
class Instruction:
    label: Optional[str]
    operation: str
    operands: List[Operand]
    instruction_mapping: Optional['InstructionMapping'] = None
    is_macro: bool = False
    macro_parameters: Optional[List[str]] = None
    macro_body: Optional[List[str]] = None
    location_counter: int = 0

@dataclass
class ControlSection:
    name: str
    instructions: List[Instruction]
    symbols: Dict[str, int]
    literals: Dict[str, Tuple[str, int]]
    location_counter: int = 0
    is_dsect: bool = False
    is_rsect: bool = False

class HLASMParser:
    def __init__(self):
        self.instruction_mapper = InstructionMapper()
        self.current_section: Optional[ControlSection] = None
        self.sections: Dict[str, ControlSection] = {}
        self.macro_definitions: Dict[str, Tuple[List[str], List[str]]] = {}
        self.literal_pool: Dict[str, Tuple[str, int]] = {}
        self.location_counter = 0
        self.base_registers: Dict[str, int] = {}
        self.using_statements: List[Tuple[str, int]] = []
        self.current_macro = None
        self.macro_parameters = None
        self.conditional_stack = []
        self.title = None
        self.strict_validation = False  # Disable strict validation by default
        
        # Regular expressions for parsing
        self.label_pattern = re.compile(r'^([A-Z@#$][A-Z@#$0-9]*)?\s*')
        self.mnemonic_pattern = re.compile(r'([A-Z@#$][A-Z@#$0-9]*)\s*')
        self.operand_pattern = re.compile(r'([^,]+)(?:,|$)')
        self.comment_pattern = re.compile(r'\*.*$')
        self.register_pattern = re.compile(r'^R?([0-9]+)$')
        self.address_pattern = re.compile(r'^([0-9]+)\(([0-9]+),([0-9]+)\)$')
        self.literal_pattern = re.compile(r'^=([A-Z@#$][A-Z@#$0-9]*)$')
        self.expression_pattern = re.compile(r'^([A-Z@#$][A-Z@#$0-9]*)([+\-*/])([A-Z@#$][A-Z@#$0-9]*)$')
        self.macro_param_pattern = re.compile(r'&([A-Z@#$][A-Z@#$0-9]*)')
        self.conditional_pattern = re.compile(r'^AIF\s*\((.*)\)\.(.*)$')
        self.ago_pattern = re.compile(r'^AGO\s*\.(.*)$')
        self.title_pattern = re.compile(r"TITLE\s+'([^']*)'")
        self.using_pattern = re.compile(r'USING\s+([^,]+),(\d+)')

    def parse(self, code: str) -> Dict[str, ControlSection]:
        """Parse HLASM code into control sections."""
        lines = code.split('\n')
        self._reset_state()

        for line_number, line in enumerate(lines, 1):
            # Remove trailing whitespace and normalize line
            line = line.rstrip()
            
            # Skip empty lines
            if not line:
                continue

            # Handle comments
            if line.startswith('*'):
                # Store comment for context if needed
                continue

            # Parse fixed-format HLASM line
            # Column 1-8: Label
            # Column 10-15: Operation
            # Column 16-71: Operands
            # Column 72-80: Comments
            label = line[0:8].strip()
            operation = line[9:15].strip()
            operands_str = line[15:71].strip()
            
            # Remove inline comments
            if '*' in operands_str:
                operands_str = operands_str[:operands_str.index('*')].strip()

            # Handle TITLE directive
            title_match = self.title_pattern.search(line)
            if title_match:
                self.title = title_match.group(1)
                continue

            # Handle USING directive
            using_match = self.using_pattern.search(line)
            if using_match:
                base, register = using_match.groups()
                self.using_statements.append((base, int(register)))
                continue

            # Handle control section directives
            if operation in ['START', 'CSECT', 'DSECT', 'RSECT']:
                if self.current_section:
                    self.sections[self.current_section.name] = self.current_section
                self._start_new_section(operation, label, operands_str)
                continue

            # Handle macro definitions
            if operation == 'MACRO':
                self._start_macro_definition(label, operands_str)
                continue
            elif operation == 'MEND':
                self._end_macro_definition()
                continue
            elif self.current_macro:
                self._add_macro_instruction(label, operation, operands_str, line_number)
                continue

            # Handle macro calls
            if operation == 'CALLM':
                self._handle_macro_call(label, operands_str)
                continue

            # Handle literal pool
            if operation == 'LTORG':
                self._process_literal_pool()
                continue

            # Parse instruction
            instruction = self._parse_instruction(label, operation, operands_str, line_number)
            if instruction:
                self._add_instruction(instruction)

        # Add the last section
        if self.current_section:
            self.sections[self.current_section.name] = self.current_section

        return self.sections

    def _reset_state(self):
        """Reset parser state."""
        self.current_section = None
        self.sections = {}
        self.macro_definitions = {}
        self.literal_pool = {}
        self.location_counter = 0
        self.base_registers = {}
        self.using_statements = []
        self.current_macro = None
        self.macro_parameters = None
        self.conditional_stack = []

    def _start_new_section(self, operation: str, label: str, operands_str: str):
        """Start a new control section."""
        section_name = label or f"CSECT_{len(self.sections)}"
        self.current_section = ControlSection(
            name=section_name,
            instructions=[],
            symbols={},
            literals={},
            location_counter=0
        )
        if operation == 'START':
            self.location_counter = self._parse_address(operands_str)
        self.current_section.symbols[section_name] = self.location_counter

    def _start_macro_definition(self, name: str, parameters: str):
        """Start a macro definition."""
        self.current_macro = name
        self.macro_parameters = self._parse_macro_parameters(parameters)
        self.macro_definitions[name] = (self.macro_parameters, [])

    def _end_macro_definition(self):
        """End a macro definition."""
        self.current_macro = None
        self.macro_parameters = None

    def _parse_macro_parameters(self, parameters: str) -> List[str]:
        """Parse macro parameters."""
        param_list = []
        if not parameters:
            return param_list

        # Handle positional parameters
        pos_params = parameters.split(',')
        for i, param in enumerate(pos_params, 1):
            param_list.append(f"&{i}")

        # Handle keyword parameters
        keyword_params = re.findall(r'(\w+)=([^,]+)', parameters)
        for key, value in keyword_params:
            param_list.append(key)

        return param_list

    def _parse_instruction(self, label: str, operation: str, operands_str: str, 
                          line_number: int) -> Optional[Instruction]:
        """Parse a single instruction."""
        if not operation:
            return None

        # Handle labels
        if label:
            if label.startswith('&'):
                # Macro parameter label
                label = self._expand_macro_parameter(label)
            elif label.startswith('.'):
                # Local label
                label = f"{self.current_macro}_{label}" if self.current_macro else label
            if self.current_section:
                self.current_section.symbols[label] = self.location_counter

        # Handle conditional assembly directives
        if operation == 'AIF':
            # Parse condition (e.g., &PARM.EQ.1)
            condition_parts = operands_str.split('.')
            if len(condition_parts) >= 3:
                param, op, value = condition_parts[0], condition_parts[1], condition_parts[2]
                param = self._expand_macro_parameter(param)
                result = self._evaluate_condition(param, op, value)
                self.conditional_stack.append((result, value))
            return None
        elif operation == 'AGO':
            # Handle unconditional branch
            target = operands_str.strip()
            if target.startswith('.'):
                target = f"{self.current_macro}_{target}" if self.current_macro else target
            self.conditional_stack.append((True, target))
            return None
        elif operation == 'ANOP':
            return None

        # Parse operands
        operands = self._parse_operands(operation, operands_str)

        # Check for literals
        for operand in operands:
            if operand.type == OperandType.LITERAL:
                self.literal_pool[operand.value] = (operand.value, 4)

        # Update location counter
        self._update_location_counter(operands)

        # Get instruction mapping
        instruction_mapping = self.instruction_mapper.get_instruction(operation)

        # Handle macro expansion
        if instruction_mapping and instruction_mapping.is_macro:
            return self._handle_macro_expansion(label, operands, instruction_mapping)

        # Validate operands against instruction mapping only if strict validation is enabled
        if self.strict_validation and instruction_mapping and instruction_mapping.operands:
            if len(operands) != len(instruction_mapping.operands):
                print(f"Warning: Expected {len(instruction_mapping.operands)} operands for {operation}, got {len(operands)}")
                return None

        return Instruction(
            label=label,
            operation=operation,
            operands=operands,
            instruction_mapping=instruction_mapping,
            location_counter=self.location_counter
        )

    def _expand_macro_parameter(self, param: str) -> str:
        """Expand macro parameter references."""
        if not param.startswith('&'):
            return param
        param_name = param[1:]  # Remove &
        if self.macro_parameters and param_name in self.macro_parameters:
            return f"MACRO_PARAM_{param_name}"
        return param

    def _evaluate_condition(self, param: str, op: str, value: str) -> bool:
        """Evaluate a conditional assembly condition."""
        if op == 'EQ':
            return param == value
        elif op == 'NE':
            return param != value
        elif op == 'GT':
            return param > value
        elif op == 'LT':
            return param < value
        elif op == 'GE':
            return param >= value
        elif op == 'LE':
            return param <= value
        return False

    def _parse_operands(self, operation: str, operands_str: str) -> List[Operand]:
        """Parse operands from a string."""
        if not operands_str:
            return []

        operands = []
        # Split operands by comma, but not within parentheses
        current = ""
        paren_count = 0
        for char in operands_str:
            if char == '(':
                paren_count += 1
                current += char
            elif char == ')':
                paren_count -= 1
                current += char
            elif char == ',' and paren_count == 0:
                if current.strip():
                    operands.append(self._parse_single_operand(current.strip()))
                current = ""
            else:
                current += char

        if current.strip():
            operands.append(self._parse_single_operand(current.strip()))

        return operands

    def _parse_single_operand(self, op_str: str) -> Operand:
        """Parse a single operand."""
        # Handle keyword parameters (e.g., PARM=1)
        if '=' in op_str:
            key, value = op_str.split('=', 1)
            return Operand(f"{key}={value}", OperandType.MACRO_PARAM)

        # Handle macro parameters
        if op_str.startswith('&'):
            return Operand(self._expand_macro_parameter(op_str), OperandType.MACRO_PARAM)

        # Handle literals
        if op_str.startswith('='):
            return Operand(op_str, OperandType.LITERAL)

        # Handle registers
        if op_str.startswith('R') and op_str[1:].isdigit():
            return Operand(op_str, OperandType.REGISTER)

        # Handle complex addresses (displacement(base,index))
        match = re.match(r'(\d+)\((\d+)(?:,(\d+))?\)', op_str)
        if match:
            displacement, base, index = match.groups()
            return Operand(
                op_str,
                OperandType.ADDRESS,
                displacement=int(displacement),
                base_register=base,
                index_register=index if index else None
            )

        # Handle simple addresses
        if op_str[0].isalpha():
            return Operand(op_str, OperandType.ADDRESS)

        # Handle immediate values
        if op_str.isdigit():
            return Operand(op_str, OperandType.IMMEDIATE)

        # Handle expressions
        if any(op in op_str for op in ['+', '-', '*', '/']):
            return Operand(op_str, OperandType.EXPRESSION)

        # Handle strings
        if op_str.startswith("'") and op_str.endswith("'"):
            return Operand(op_str, OperandType.STRING)

        # Default to address
        return Operand(op_str, OperandType.ADDRESS)

    def _update_location_counter(self, operands: List[Operand]):
        """Update the location counter based on the instruction."""
        if not operands:
            return

        # Handle data definition directives
        if operands[0].value in ['DC', 'DS']:
            self._update_location_counter_for_data(operands)
            return

        # Handle machine instructions
        if operands[0].value in ['L', 'ST', 'LA', 'A', 'S', 'M', 'D']:
            self.location_counter += 4
        elif operands[0].value in ['LR', 'AR', 'SR', 'MR', 'DR']:
            self.location_counter += 2
        else:
            # Default to 4 bytes for unknown instructions
            self.location_counter += 4

    def _update_location_counter_for_data(self, operands: List[Operand]):
        """Update location counter for data definition directives."""
        if not operands:
            return

        if operands[0].value == 'DC':
            # Handle different types of constants
            type_spec = operands[0].value[0].upper()
            if type_spec in ['C', 'X']:
                # Character or hexadecimal
                value = operands[0].value[2:-1]  # Remove type and quotes
                self.location_counter += len(value)
            elif type_spec in ['F', 'H']:
                # Fullword or halfword
                self.location_counter += 4 if type_spec == 'F' else 2
            elif type_spec == 'D':
                # Doubleword
                self.location_counter += 8
            elif type_spec == 'E':
                # Extended precision
                self.location_counter += 16
        elif operands[0].value == 'DS':
            # Handle different types of storage
            type_spec = operands[0].value[0].upper()
            length = int(operands[1].value) if len(operands) > 1 else 1
            if type_spec in ['F', 'H']:
                self.location_counter += (4 if type_spec == 'F' else 2) * length
            elif type_spec == 'D':
                self.location_counter += 8 * length
            elif type_spec == 'E':
                self.location_counter += 16 * length
            else:
                self.location_counter += length

    def _process_literal_pool(self):
        """Process literal pool and update location counter for each LTORG."""
        if not self.literal_pool:
            return
        for literal, (value, length) in list(self.literal_pool.items()):
            if self.current_section:
                # Only add if not already in section's literals
                if literal not in self.current_section.literals:
                    self.current_section.literals[literal] = (value, self.location_counter)
                    self.location_counter += length
                    self.current_section.location_counter = self.location_counter
            # Remove from pool after assignment
            del self.literal_pool[literal]

    def _add_instruction(self, instruction: Instruction):
        """Add an instruction to the current section."""
        if self.current_section:
            self.current_section.instructions.append(instruction)

    def _add_macro_instruction(self, label: str, operation: str, 
                              operands_str: str, line_number: int):
        """Add an instruction to the current macro definition."""
        if self.current_macro:
            instruction = self._parse_instruction(label, operation, operands_str, line_number)
            if instruction:
                instruction.is_macro = True
                instruction.macro_parameters = self.macro_parameters
                self.macro_definitions[self.current_macro][1].append(instruction)

    def get_symbol_value(self, symbol: str) -> Optional[int]:
        """Get the value of a symbol."""
        if self.current_section and symbol in self.current_section.symbols:
            return self.current_section.symbols[symbol]
        return None

    def get_literal_value(self, literal: str) -> Optional[int]:
        """Get the value of a literal."""
        if self.current_section and literal in self.current_section.literals:
            return self.current_section.literals[literal][1]
        return None

    def get_macro(self, name: str) -> Optional[Tuple[List[str], List[str]]]:
        """Get a macro definition by name."""
        return self.macro_definitions.get(name)

    def get_section(self, name: str) -> Optional[ControlSection]:
        """Get a control section by name."""
        return self.sections.get(name)

    def _parse_address(self, address_str: str) -> int:
        """Parse an address string into an integer."""
        try:
            return int(address_str)
        except ValueError:
            return 0

    def _handle_macro_expansion(self, label: Optional[str], operands: List[Operand], instruction_mapping: 'InstructionMapping') -> Instruction:
        """Handle macro expansion with parameter substitution."""
        if instruction_mapping.is_macro:
            macro_params, macro_body = self.macro_definitions[instruction_mapping.name]
            expanded_body = []

            # Create parameter mapping
            param_map = {}
            for param, operand in zip(macro_params, operands):
                param_map[param] = operand.value

            # Expand macro body
            for line in macro_body:
                expanded_line = line
                for param, value in param_map.items():
                    expanded_line = expanded_line.replace(f'&{param}', value)
                expanded_body.append(expanded_line)

            # Create macro instruction
            return Instruction(
                label=label,
                operation=instruction_mapping.name,
                operands=operands,
                instruction_mapping=instruction_mapping,
                is_macro=True,
                macro_parameters=macro_params,
                macro_body=expanded_body,
                location_counter=self.location_counter
            )
        return None

    def _handle_macro_call(self, label: str, operands_str: str):
        """Handle macro call with parameters."""
        parts = operands_str.split(',', 1)
        macro_name = parts[0].strip()
        params = parts[1].strip() if len(parts) > 1 else ""

        # Parse parameters
        param_dict = {}
        if params:
            for param in params.split(','):
                if '=' in param:
                    key, value = param.split('=', 1)
                    param_dict[key.strip()] = value.strip()

        # Get macro definition
        if macro_name in self.macro_definitions:
            macro_params, macro_body = self.macro_definitions[macro_name]
            
            # Create instruction for macro call
            instruction = Instruction(
                label=label,
                operation=macro_name,
                operands=[Operand(f"{k}={v}", OperandType.MACRO_PARAM) for k, v in param_dict.items()],
                instruction_mapping=self.instruction_mapper.get_instruction(macro_name),
                is_macro=True,
                macro_parameters=macro_params,
                macro_body=macro_body,
                location_counter=self.location_counter
            )
            self._add_instruction(instruction) 