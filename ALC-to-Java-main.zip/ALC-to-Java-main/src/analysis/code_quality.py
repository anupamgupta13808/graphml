from dataclasses import dataclass
from typing import List, Dict, Set
import re

@dataclass
class CodeQualityInfo:
    maintainability_score: float
    code_smells: List[str]
    best_practices: List[str]
    documentation: List[str]
    naming_conventions: List[str]
    complexity_issues: List[str]
    recommendations: List[str]

class CodeQualityAnalyzer:
    def __init__(self):
        self.code_smell_patterns = {
            'long_method': r'(\w+)\s+(\w+)\s*\([^)]*\)\s*\{[^}]{500,}\}',
            'large_class': r'class\s+(\w+)\s*\{[^}]{1000,}\}',
            'duplicate_code': r'(\w+)\s*\([^)]*\)\s*\{[^}]*\}\s*\1\s*\([^)]*\)\s*\{[^}]*\}',
            'primitive_obsession': r'int\s+\w+|long\s+\w+|double\s+\w+',
            'data_class': r'class\s+(\w+)\s*\{[^}]*private\s+\w+\s+\w+;[^}]*\}',
            'feature_envy': r'(\w+)\.\w+\s*\([^)]*\)',
            'inappropriate_intimacy': r'private\s+\w+\s+\w+;',
            'refused_bequest': r'extends\s+\w+\s*\{[^}]*\}',
            'comments': r'//[^\n]*|/\*[^*]*\*/'
        }
        
        self.best_practice_patterns = {
            'immutable': r'final\s+class',
            'interface_segregation': r'interface\s+\w+\s*\{[^}]*\}',
            'dependency_injection': r'@Autowired|@Inject',
            'single_responsibility': r'class\s+\w+\s*\{[^}]*\}',
            'open_closed': r'abstract\s+class',
            'liskov_substitution': r'extends\s+\w+',
            'interface_programming': r'implements\s+\w+',
            'encapsulation': r'private\s+\w+\s+\w+;',
            'exception_handling': r'try\s*\{[^}]*\}\s*catch'
        }
        
        self.documentation_patterns = {
            'javadoc': r'/\*\*[^*]*\*/',
            'method_doc': r'/\*\*[^*]*\*/\s*public\s+\w+\s+\w+\s*\(',
            'class_doc': r'/\*\*[^*]*\*/\s*public\s+class',
            'param_doc': r'@param\s+\w+',
            'return_doc': r'@return',
            'throws_doc': r'@throws',
            'deprecated': r'@deprecated'
        }
        
        self.naming_convention_patterns = {
            'class_name': r'class\s+([a-z]\w+)',
            'interface_name': r'interface\s+([a-z]\w+)',
            'method_name': r'(\w+)\s+([a-z]\w+)\s*\(',
            'variable_name': r'(\w+)\s+([a-z]\w+)\s*=',
            'constant_name': r'static\s+final\s+\w+\s+([a-z]\w+)',
            'package_name': r'package\s+([a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*)'
        }

    def analyze(self, java_code: str) -> CodeQualityInfo:
        """
        Analyzes Java code for code quality issues and best practices.
        """
        maintainability_score = self._calculate_maintainability_score(java_code)
        code_smells = self._find_code_smells(java_code)
        best_practices = self._find_best_practices(java_code)
        documentation = self._analyze_documentation(java_code)
        naming_conventions = self._check_naming_conventions(java_code)
        complexity_issues = self._find_complexity_issues(java_code)
        
        recommendations = self._generate_recommendations(
            maintainability_score, code_smells, best_practices,
            documentation, naming_conventions, complexity_issues
        )
        
        return CodeQualityInfo(
            maintainability_score=maintainability_score,
            code_smells=code_smells,
            best_practices=best_practices,
            documentation=documentation,
            naming_conventions=naming_conventions,
            complexity_issues=complexity_issues,
            recommendations=recommendations
        )

    def _calculate_maintainability_score(self, java_code: str) -> float:
        """Calculates a maintainability score for the code."""
        score = 100.0
        
        # Deduct points for code smells
        for pattern in self.code_smell_patterns.values():
            matches = len(re.findall(pattern, java_code))
            score -= matches * 5.0
            
        # Add points for best practices
        for pattern in self.best_practice_patterns.values():
            matches = len(re.findall(pattern, java_code))
            score += matches * 2.0
            
        # Add points for documentation
        for pattern in self.documentation_patterns.values():
            matches = len(re.findall(pattern, java_code))
            score += matches * 1.0
            
        return max(0.0, min(100.0, score))

    def _find_code_smells(self, java_code: str) -> List[str]:
        """Identifies code smells in the code."""
        smells = []
        
        for name, pattern in self.code_smell_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                smells.append(f"Code smell ({name}): {match.group(0)}")
                
        return smells

    def _find_best_practices(self, java_code: str) -> List[str]:
        """Identifies best practices in the code."""
        practices = []
        
        for name, pattern in self.best_practice_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                practices.append(f"Best practice ({name}): {match.group(0)}")
                
        return practices

    def _analyze_documentation(self, java_code: str) -> List[str]:
        """Analyzes code documentation."""
        documentation = []
        
        for name, pattern in self.documentation_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                documentation.append(f"Documentation ({name}): {match.group(0)}")
                
        return documentation

    def _check_naming_conventions(self, java_code: str) -> List[str]:
        """Checks naming conventions in the code."""
        naming_issues = []
        
        for name, pattern in self.naming_convention_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                identifier = match.group(1)
                if not self._follows_naming_convention(identifier, name):
                    naming_issues.append(f"Naming convention issue ({name}): {identifier}")
                    
        return naming_issues

    def _find_complexity_issues(self, java_code: str) -> List[str]:
        """Identifies complexity issues in the code."""
        complexity_issues = []
        
        # Check for long methods
        long_methods = re.finditer(r'(\w+)\s+(\w+)\s*\([^)]*\)\s*\{[^}]{500,}\}', java_code)
        for match in long_methods:
            complexity_issues.append(f"Long method: {match.group(2)}")
            
        # Check for deep nesting
        deep_nesting = re.finditer(r'\{[^}]*\{[^}]*\{[^}]*\{[^}]*\}', java_code)
        for match in deep_nesting:
            complexity_issues.append("Deep nesting detected")
            
        # Check for complex conditions
        complex_conditions = re.finditer(r'if\s*\([^)]{100,}\)', java_code)
        for match in complex_conditions:
            complexity_issues.append("Complex condition detected")
            
        return complexity_issues

    def _follows_naming_convention(self, identifier: str, convention_type: str) -> bool:
        """Checks if an identifier follows Java naming conventions."""
        if convention_type in ['class_name', 'interface_name']:
            return bool(re.match(r'^[A-Z][a-zA-Z0-9]*$', identifier))
        elif convention_type in ['method_name', 'variable_name']:
            return bool(re.match(r'^[a-z][a-zA-Z0-9]*$', identifier))
        elif convention_type == 'constant_name':
            return bool(re.match(r'^[A-Z][A-Z0-9_]*$', identifier))
        elif convention_type == 'package_name':
            return bool(re.match(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$', identifier))
        return True

    def _generate_recommendations(self, maintainability_score: float,
                                code_smells: List[str],
                                best_practices: List[str],
                                documentation: List[str],
                                naming_conventions: List[str],
                                complexity_issues: List[str]) -> List[str]:
        """Generates code quality recommendations based on the analysis."""
        recommendations = []
        
        # Maintainability score recommendations
        if maintainability_score < 50:
            recommendations.extend([
                "Consider refactoring code to improve maintainability",
                "Add more documentation to improve code understanding",
                "Review and fix code smells",
                "Implement more best practices"
            ])
            
        # Code smell recommendations
        if code_smells:
            recommendations.extend([
                "Break down large methods into smaller, more focused ones",
                "Consider using design patterns to reduce code duplication",
                "Review class responsibilities and consider splitting large classes",
                "Use proper object-oriented principles to reduce primitive obsession"
            ])
            
        # Best practice recommendations
        if not best_practices:
            recommendations.extend([
                "Consider making classes immutable where possible",
                "Use interfaces to define contracts",
                "Implement proper dependency injection",
                "Follow SOLID principles"
            ])
            
        # Documentation recommendations
        if not documentation:
            recommendations.extend([
                "Add Javadoc comments to public methods and classes",
                "Document parameters and return values",
                "Add examples in documentation where appropriate",
                "Document exceptions that methods might throw"
            ])
            
        # Naming convention recommendations
        if naming_conventions:
            recommendations.extend([
                "Follow Java naming conventions for classes, methods, and variables",
                "Use descriptive names that reflect purpose",
                "Avoid abbreviations unless widely understood",
                "Be consistent with naming across the codebase"
            ])
            
        # Complexity recommendations
        if complexity_issues:
            recommendations.extend([
                "Break down complex methods into smaller, more manageable pieces",
                "Reduce nesting levels in code",
                "Simplify complex conditions",
                "Consider using design patterns to manage complexity"
            ])
            
        return recommendations 