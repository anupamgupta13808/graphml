from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Set
import re

class ThreadSafetyLevel(Enum):
    HIGHLY_SAFE = "Highly Thread Safe"
    SAFE = "Thread Safe"
    PARTIALLY_SAFE = "Partially Thread Safe"
    UNSAFE = "Not Thread Safe"

@dataclass
class ThreadSafetyInfo:
    level: ThreadSafetyLevel
    mechanisms: List[str]
    warnings: List[str]
    recommendations: List[str]
    shared_resources: Set[str]
    synchronization_points: List[str]

class ThreadSafetyAnalyzer:
    def __init__(self):
        self.thread_safety_patterns = {
            'synchronized': r'synchronized\s*\([^)]+\)',
            'volatile': r'volatile\s+\w+',
            'atomic': r'Atomic\w+',
            'lock': r'Lock|ReentrantLock|ReadWriteLock',
            'semaphore': r'Semaphore',
            'countdown_latch': r'CountDownLatch',
            'cyclic_barrier': r'CyclicBarrier',
            'concurrent_collection': r'Concurrent\w+',
            'thread_local': r'ThreadLocal',
            'immutable': r'final\s+class',
            'thread_safe_annotation': r'@ThreadSafe'
        }
        
        self.thread_unsafe_patterns = {
            'static_mutable': r'static\s+(?!final)\w+\s+\w+',
            'shared_mutable': r'public\s+(?!final)\w+\s+\w+',
            'unsafe_operation': r'notify\(\)|notifyAll\(\)|wait\(\)',
            'unsafe_collection': r'ArrayList|HashMap|HashSet',
            'unsafe_io': r'FileInputStream|FileOutputStream',
            'unsafe_singleton': r'private\s+static\s+\w+\s+instance'
        }

    def analyze(self, java_code: str) -> ThreadSafetyInfo:
        """
        Analyzes Java code for thread safety characteristics.
        """
        mechanisms = self._find_thread_safety_mechanisms(java_code)
        warnings = self._find_thread_safety_warnings(java_code)
        shared_resources = self._find_shared_resources(java_code)
        sync_points = self._find_synchronization_points(java_code)
        
        level = self._determine_thread_safety_level(mechanisms, warnings)
        recommendations = self._generate_recommendations(level, mechanisms, warnings)
        
        return ThreadSafetyInfo(
            level=level,
            mechanisms=mechanisms,
            warnings=warnings,
            recommendations=recommendations,
            shared_resources=shared_resources,
            synchronization_points=sync_points
        )

    def _find_thread_safety_mechanisms(self, java_code: str) -> List[str]:
        """Finds thread safety mechanisms in the code."""
        mechanisms = []
        for name, pattern in self.thread_safety_patterns.items():
            if re.search(pattern, java_code):
                mechanisms.append(name)
        return mechanisms

    def _find_thread_safety_warnings(self, java_code: str) -> List[str]:
        """Finds potential thread safety issues in the code."""
        warnings = []
        for name, pattern in self.thread_unsafe_patterns.items():
            if re.search(pattern, java_code):
                warnings.append(f"Potential thread safety issue: {name}")
        return warnings

    def _find_shared_resources(self, java_code: str) -> Set[str]:
        """Identifies shared resources in the code."""
        shared_resources = set()
        
        # Find static fields
        static_fields = re.finditer(r'static\s+(\w+)\s+(\w+)', java_code)
        for match in static_fields:
            shared_resources.add(f"Static field: {match.group(2)}")
            
        # Find public fields
        public_fields = re.finditer(r'public\s+(\w+)\s+(\w+)', java_code)
        for match in public_fields:
            shared_resources.add(f"Public field: {match.group(2)}")
            
        # Find shared collections
        collections = re.finditer(r'(\w+)\s*=\s*new\s+(ArrayList|HashMap|HashSet)', java_code)
        for match in collections:
            shared_resources.add(f"Shared collection: {match.group(1)}")
            
        return shared_resources

    def _find_synchronization_points(self, java_code: str) -> List[str]:
        """Identifies synchronization points in the code."""
        sync_points = []
        
        # Find synchronized blocks
        sync_blocks = re.finditer(r'synchronized\s*\(([^)]+)\)', java_code)
        for match in sync_blocks:
            sync_points.append(f"Synchronized block on: {match.group(1)}")
            
        # Find synchronized methods
        sync_methods = re.finditer(r'synchronized\s+(\w+)\s+(\w+)\s*\(', java_code)
        for match in sync_methods:
            sync_points.append(f"Synchronized method: {match.group(2)}")
            
        # Find lock acquisitions
        locks = re.finditer(r'lock\.lock\(\)', java_code)
        for match in locks:
            sync_points.append("Lock acquisition")
            
        return sync_points

    def _determine_thread_safety_level(self, mechanisms: List[str], warnings: List[str]) -> ThreadSafetyLevel:
        """Determines the overall thread safety level of the code."""
        if not mechanisms and warnings:
            return ThreadSafetyLevel.UNSAFE
        elif len(mechanisms) >= 3 and not warnings:
            return ThreadSafetyLevel.HIGHLY_SAFE
        elif mechanisms and not warnings:
            return ThreadSafetyLevel.SAFE
        else:
            return ThreadSafetyLevel.PARTIALLY_SAFE

    def _generate_recommendations(self, level: ThreadSafetyLevel, 
                                mechanisms: List[str], 
                                warnings: List[str]) -> List[str]:
        """Generates recommendations based on the analysis."""
        recommendations = []
        
        if level == ThreadSafetyLevel.UNSAFE:
            recommendations.extend([
                "Consider using synchronized blocks or methods for critical sections",
                "Use thread-safe collections from java.util.concurrent",
                "Consider using volatile for shared variables",
                "Implement proper locking mechanisms"
            ])
        elif level == ThreadSafetyLevel.PARTIALLY_SAFE:
            recommendations.extend([
                "Review shared resource access patterns",
                "Consider using atomic variables for simple operations",
                "Implement proper exception handling in synchronized blocks",
                "Consider using read-write locks for better performance"
            ])
        elif level == ThreadSafetyLevel.SAFE:
            recommendations.extend([
                "Consider using more fine-grained locking",
                "Review synchronization points for potential deadlocks",
                "Consider using concurrent collections for better performance",
                "Implement proper monitoring and logging"
            ])
        elif level == ThreadSafetyLevel.HIGHLY_SAFE:
            recommendations.extend([
                "Consider performance optimizations",
                "Review synchronization overhead",
                "Consider using non-blocking algorithms",
                "Implement proper testing for edge cases"
            ])
            
        return recommendations 