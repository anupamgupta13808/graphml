from dataclasses import dataclass
from typing import List, Dict, Set
import re

@dataclass
class PerformanceInfo:
    complexity_score: float
    bottlenecks: List[str]
    recommendations: List[str]
    io_operations: List[str]
    loops: List[str]
    recursion: List[str]
    synchronization_points: List[str]
    resource_intensive_operations: List[str]

class PerformanceAnalyzer:
    def __init__(self):
        self.complexity_patterns = {
            'nested_loop': r'for\s*\([^)]+\)\s*\{[^}]*for\s*\([^)]+\)',
            'deep_recursion': r'(\w+)\s*\([^)]*\)\s*\{[^}]*\1\s*\(',
            'complex_condition': r'if\s*\([^)]{100,}\)',
            'long_method': r'(\w+)\s+(\w+)\s*\([^)]*\)\s*\{[^}]{500,}\}',
            'many_parameters': r'(\w+)\s+(\w+)\s*\([^)]{100,}\)'
        }
        
        self.bottleneck_patterns = {
            'io_operation': r'(FileInputStream|FileOutputStream|BufferedReader|BufferedWriter)',
            'network_operation': r'(Socket|URL|HttpURLConnection)',
            'database_operation': r'(Connection|Statement|PreparedStatement)',
            'synchronization': r'synchronized|Lock|ReentrantLock',
            'reflection': r'Class\.forName|getMethod|invoke',
            'regex': r'Pattern\.compile|matches',
            'serialization': r'ObjectInputStream|ObjectOutputStream'
        }
        
        self.loop_patterns = {
            'for_loop': r'for\s*\([^)]+\)',
            'while_loop': r'while\s*\([^)]+\)',
            'do_while': r'do\s*\{[^}]*\}\s*while',
            'enhanced_for': r'for\s*\([^:]+:[^)]+\)'
        }
        
        self.recursion_patterns = {
            'direct_recursion': r'(\w+)\s*\([^)]*\)\s*\{[^}]*\1\s*\(',
            'indirect_recursion': r'(\w+)\s*\([^)]*\)\s*\{[^}]*(\w+)\s*\([^)]*\)[^}]*\}',
            'tail_recursion': r'return\s+(\w+)\s*\([^)]*\)'
        }

    def analyze(self, java_code: str) -> PerformanceInfo:
        """
        Analyzes Java code for performance characteristics and potential bottlenecks.
        """
        complexity_score = self._calculate_complexity_score(java_code)
        bottlenecks = self._find_bottlenecks(java_code)
        io_operations = self._find_io_operations(java_code)
        loops = self._find_loops(java_code)
        recursion = self._find_recursion(java_code)
        sync_points = self._find_synchronization_points(java_code)
        resource_ops = self._find_resource_intensive_operations(java_code)
        
        recommendations = self._generate_recommendations(
            complexity_score, bottlenecks, io_operations, 
            loops, recursion, sync_points, resource_ops
        )
        
        return PerformanceInfo(
            complexity_score=complexity_score,
            bottlenecks=bottlenecks,
            recommendations=recommendations,
            io_operations=io_operations,
            loops=loops,
            recursion=recursion,
            synchronization_points=sync_points,
            resource_intensive_operations=resource_ops
        )

    def _calculate_complexity_score(self, java_code: str) -> float:
        """Calculates a complexity score for the code."""
        score = 0.0
        
        # Count nested loops
        nested_loops = len(re.findall(self.complexity_patterns['nested_loop'], java_code))
        score += nested_loops * 2.0
        
        # Count deep recursion
        deep_recursion = len(re.findall(self.complexity_patterns['deep_recursion'], java_code))
        score += deep_recursion * 3.0
        
        # Count complex conditions
        complex_conditions = len(re.findall(self.complexity_patterns['complex_condition'], java_code))
        score += complex_conditions * 1.5
        
        # Count long methods
        long_methods = len(re.findall(self.complexity_patterns['long_method'], java_code))
        score += long_methods * 2.0
        
        # Count methods with many parameters
        many_params = len(re.findall(self.complexity_patterns['many_parameters'], java_code))
        score += many_params * 1.0
        
        return score

    def _find_bottlenecks(self, java_code: str) -> List[str]:
        """Identifies potential performance bottlenecks in the code."""
        bottlenecks = []
        
        for name, pattern in self.bottleneck_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                bottlenecks.append(f"Potential {name} bottleneck: {match.group(0)}")
                
        return bottlenecks

    def _find_io_operations(self, java_code: str) -> List[str]:
        """Identifies I/O operations in the code."""
        io_operations = []
        
        # Find file operations
        file_ops = re.finditer(r'(FileInputStream|FileOutputStream|BufferedReader|BufferedWriter)', java_code)
        for match in file_ops:
            io_operations.append(f"File I/O operation: {match.group(1)}")
            
        # Find network operations
        network_ops = re.finditer(r'(Socket|URL|HttpURLConnection)', java_code)
        for match in network_ops:
            io_operations.append(f"Network operation: {match.group(1)}")
            
        # Find database operations
        db_ops = re.finditer(r'(Connection|Statement|PreparedStatement)', java_code)
        for match in db_ops:
            io_operations.append(f"Database operation: {match.group(1)}")
            
        return io_operations

    def _find_loops(self, java_code: str) -> List[str]:
        """Identifies loops in the code."""
        loops = []
        
        for loop_type, pattern in self.loop_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                loops.append(f"{loop_type}: {match.group(0)}")
                
        return loops

    def _find_recursion(self, java_code: str) -> List[str]:
        """Identifies recursion in the code."""
        recursion = []
        
        for rec_type, pattern in self.recursion_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                recursion.append(f"{rec_type}: {match.group(0)}")
                
        return recursion

    def _find_synchronization_points(self, java_code: str) -> List[str]:
        """Identifies synchronization points in the code."""
        sync_points = []
        
        # Find synchronized blocks
        sync_blocks = re.finditer(r'synchronized\s*\([^)]+\)', java_code)
        for match in sync_blocks:
            sync_points.append(f"Synchronized block: {match.group(0)}")
            
        # Find synchronized methods
        sync_methods = re.finditer(r'synchronized\s+(\w+)\s+(\w+)\s*\(', java_code)
        for match in sync_methods:
            sync_points.append(f"Synchronized method: {match.group(2)}")
            
        # Find lock acquisitions
        locks = re.finditer(r'lock\.lock\(\)', java_code)
        for match in locks:
            sync_points.append("Lock acquisition")
            
        return sync_points

    def _find_resource_intensive_operations(self, java_code: str) -> List[str]:
        """Identifies resource-intensive operations in the code."""
        resource_ops = []
        
        # Find large object allocations
        large_allocs = re.finditer(r'new\s+\w+\s*\[\s*(\d{4,})\s*\]', java_code)
        for match in large_allocs:
            size = match.group(1)
            resource_ops.append(f"Large array allocation: {size} elements")
            
        # Find expensive computations
        expensive_ops = re.finditer(r'(sort|parallel|stream|collect)', java_code)
        for match in expensive_ops:
            resource_ops.append(f"Expensive operation: {match.group(1)}")
            
        # Find reflection usage
        reflection = re.finditer(r'(Class\.forName|getMethod|invoke)', java_code)
        for match in reflection:
            resource_ops.append(f"Reflection usage: {match.group(1)}")
            
        return resource_ops

    def _generate_recommendations(self, complexity_score: float,
                                bottlenecks: List[str],
                                io_operations: List[str],
                                loops: List[str],
                                recursion: List[str],
                                sync_points: List[str],
                                resource_ops: List[str]) -> List[str]:
        """Generates performance recommendations based on the analysis."""
        recommendations = []
        
        # Complexity-based recommendations
        if complexity_score > 10:
            recommendations.extend([
                "Consider refactoring complex methods into smaller, more manageable pieces",
                "Review nested loops and consider alternative algorithms",
                "Look for opportunities to reduce method parameter count"
            ])
            
        # Bottleneck-based recommendations
        if bottlenecks:
            recommendations.extend([
                "Consider using buffered I/O operations",
                "Review synchronization points for potential deadlocks",
                "Consider using connection pooling for database operations",
                "Cache expensive computations where possible"
            ])
            
        # I/O operation recommendations
        if io_operations:
            recommendations.extend([
                "Use try-with-resources for proper resource management",
                "Consider using NIO for better I/O performance",
                "Implement proper error handling for I/O operations",
                "Consider using async I/O for better scalability"
            ])
            
        # Loop recommendations
        if len(loops) > 5:
            recommendations.extend([
                "Consider using streams for collection processing",
                "Look for opportunities to parallelize loops",
                "Review loop conditions for potential optimizations",
                "Consider using more efficient data structures"
            ])
            
        # Recursion recommendations
        if recursion:
            recommendations.extend([
                "Consider using iteration instead of recursion where possible",
                "Implement proper base cases for recursive methods",
                "Consider using tail recursion optimization",
                "Monitor stack usage in recursive methods"
            ])
            
        # Synchronization recommendations
        if sync_points:
            recommendations.extend([
                "Consider using more fine-grained locking",
                "Review synchronization points for potential deadlocks",
                "Consider using concurrent collections",
                "Implement proper monitoring for lock contention"
            ])
            
        # Resource operation recommendations
        if resource_ops:
            recommendations.extend([
                "Consider using object pooling for frequently created objects",
                "Review memory requirements for large allocations",
                "Consider using lazy initialization",
                "Implement proper resource cleanup"
            ])
            
        return recommendations 