from dataclasses import dataclass
from typing import List, Dict, Set
import re

@dataclass
class MemoryUsageInfo:
    total_allocations: int
    object_allocations: int
    array_allocations: int
    collection_allocations: int
    estimated_memory: int  # in bytes
    potential_leaks: List[str]
    recommendations: List[str]
    large_objects: List[str]
    resource_management: List[str]

class MemoryUsageAnalyzer:
    def __init__(self):
        self.allocation_patterns = {
            'object': r'new\s+(\w+)',
            'array': r'new\s+(\w+)\s*\[\s*(\d+)\s*\]',
            'collection': r'new\s+(ArrayList|HashMap|HashSet|LinkedList)',
            'string': r'new\s+String',
            'buffer': r'new\s+(StringBuffer|StringBuilder)',
            'stream': r'new\s+(FileInputStream|FileOutputStream|BufferedReader|BufferedWriter)'
        }
        
        self.resource_patterns = {
            'closeable': r'implements\s+Closeable|AutoCloseable',
            'try_with_resources': r'try\s*\([^)]+\)',
            'explicit_close': r'\.close\(\)',
            'finalize': r'protected\s+void\s+finalize'
        }
        
        self.large_object_patterns = {
            'large_array': r'new\s+\w+\s*\[\s*(\d{4,})\s*\]',
            'large_collection': r'new\s+(ArrayList|HashMap|HashSet)\s*\(\s*(\d{4,})\s*\)',
            'large_buffer': r'new\s+(StringBuffer|StringBuilder)\s*\(\s*(\d{4,})\s*\)',
            'large_string': r'new\s+String\s*\(\s*new\s+char\s*\[\s*(\d{4,})\s*\]'
        }

    def analyze(self, java_code: str) -> MemoryUsageInfo:
        """
        Analyzes Java code for memory usage patterns and potential issues.
        """
        allocations = self._count_allocations(java_code)
        potential_leaks = self._find_potential_leaks(java_code)
        large_objects = self._find_large_objects(java_code)
        resource_management = self._analyze_resource_management(java_code)
        
        estimated_memory = self._estimate_memory_usage(allocations)
        recommendations = self._generate_recommendations(allocations, potential_leaks, large_objects)
        
        return MemoryUsageInfo(
            total_allocations=sum(allocations.values()),
            object_allocations=allocations['object'],
            array_allocations=allocations['array'],
            collection_allocations=allocations['collection'],
            estimated_memory=estimated_memory,
            potential_leaks=potential_leaks,
            recommendations=recommendations,
            large_objects=large_objects,
            resource_management=resource_management
        )

    def _count_allocations(self, java_code: str) -> Dict[str, int]:
        """Counts different types of allocations in the code."""
        allocations = {k: 0 for k in self.allocation_patterns.keys()}
        
        for alloc_type, pattern in self.allocation_patterns.items():
            matches = re.finditer(pattern, java_code)
            allocations[alloc_type] = len(list(matches))
            
        return allocations

    def _find_potential_leaks(self, java_code: str) -> List[str]:
        """Identifies potential memory leaks in the code."""
        leaks = []
        
        # Check for unclosed resources
        closeable_classes = re.finditer(r'class\s+(\w+)\s+implements\s+(Closeable|AutoCloseable)', java_code)
        for match in closeable_classes:
            class_name = match.group(1)
            if not re.search(f'{class_name}\\.close\\(\\)', java_code):
                leaks.append(f"Potential resource leak: {class_name} not properly closed")
        
        # Check for large collections that might grow unbounded
        collections = re.finditer(r'(\w+)\s*=\s*new\s+(ArrayList|HashMap|HashSet)', java_code)
        for match in collections:
            var_name = match.group(1)
            if not re.search(f'{var_name}\\.clear\\(\\)', java_code):
                leaks.append(f"Potential unbounded growth: {var_name} collection")
        
        # Check for static collections that might accumulate objects
        static_collections = re.finditer(r'static\s+(\w+)\s+(\w+)\s*=\s*new\s+(ArrayList|HashMap|HashSet)', java_code)
        for match in static_collections:
            var_name = match.group(2)
            leaks.append(f"Static collection that might accumulate objects: {var_name}")
            
        return leaks

    def _find_large_objects(self, java_code: str) -> List[str]:
        """Identifies large object allocations in the code."""
        large_objects = []
        
        for obj_type, pattern in self.large_object_patterns.items():
            matches = re.finditer(pattern, java_code)
            for match in matches:
                size = int(match.group(1))
                large_objects.append(f"Large {obj_type} allocation: {size} elements")
                
        return large_objects

    def _analyze_resource_management(self, java_code: str) -> List[str]:
        """Analyzes resource management patterns in the code."""
        resource_management = []
        
        # Check for try-with-resources usage
        try_with_resources = re.finditer(r'try\s*\(([^)]+)\)', java_code)
        for match in try_with_resources:
            resources = match.group(1)
            resource_management.append(f"Proper resource management with try-with-resources: {resources}")
        
        # Check for explicit close calls
        explicit_closes = re.finditer(r'([^;]+)\.close\(\)', java_code)
        for match in explicit_closes:
            resource = match.group(1)
            resource_management.append(f"Explicit resource closing: {resource}")
        
        # Check for finalize methods
        finalize_methods = re.finditer(r'protected\s+void\s+finalize\s*\(\s*\)', java_code)
        for match in finalize_methods:
            resource_management.append("Resource cleanup in finalize method")
            
        return resource_management

    def _estimate_memory_usage(self, allocations: Dict[str, int]) -> int:
        """Estimates total memory usage based on allocations."""
        # Rough estimates for different types of allocations
        size_estimates = {
            'object': 16,  # Minimum object overhead
            'array': 24,   # Array overhead
            'collection': 32,  # Collection overhead
            'string': 40,  # String object
            'buffer': 48,  # Buffer object
            'stream': 64   # Stream object
        }
        
        total_memory = 0
        for alloc_type, count in allocations.items():
            total_memory += count * size_estimates.get(alloc_type, 0)
            
        return total_memory

    def _generate_recommendations(self, allocations: Dict[str, int], 
                                potential_leaks: List[str],
                                large_objects: List[str]) -> List[str]:
        """Generates recommendations based on the analysis."""
        recommendations = []
        
        # Check for high allocation counts
        if allocations['object'] > 100:
            recommendations.append("Consider object pooling for frequently created objects")
        if allocations['array'] > 50:
            recommendations.append("Consider using more efficient data structures")
        if allocations['collection'] > 30:
            recommendations.append("Review collection usage and consider consolidation")
            
        # Check for potential leaks
        if potential_leaks:
            recommendations.extend([
                "Implement proper resource cleanup",
                "Use try-with-resources for Closeable resources",
                "Consider using weak references for caches"
            ])
            
        # Check for large objects
        if large_objects:
            recommendations.extend([
                "Consider lazy initialization for large objects",
                "Review memory requirements for large allocations",
                "Consider using streaming for large data processing"
            ])
            
        # General recommendations
        recommendations.extend([
            "Use appropriate collection types for your use case",
            "Consider memory-efficient data structures",
            "Implement proper resource management",
            "Monitor memory usage in production"
        ])
        
        return recommendations 