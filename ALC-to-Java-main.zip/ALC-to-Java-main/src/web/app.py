@app.route('/convert', methods=['POST'])
def convert():
    try:
        data = request.get_json()
        if not data or 'code' not in data:
            return jsonify({'error': 'No code provided'}), 400

        code = data['code']
        strict_validation = data.get('strict_validation', False)

        # Parse HLASM code
        parser = HLASMParser()
        instructions = parser.parse(code)

        # Generate Java code
        generator = JavaGenerator()
        java_code = generator.generate(instructions, strict_validation=strict_validation)

        return jsonify({'java_code': java_code})
    except Exception as e:
        app.logger.error(f"Conversion error: {str(e)}")
        return jsonify({'error': str(e)}), 500 