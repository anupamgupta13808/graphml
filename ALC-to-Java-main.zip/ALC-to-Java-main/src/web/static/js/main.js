// Initialize Material Components
document.addEventListener('DOMContentLoaded', () => {
    // Initialize all MDC components
    mdc.autoInit();

    // Initialize tabs
    const tabBar = new mdc.tabBar.MDCTabBar(document.querySelector('.mdc-tab-bar'));
    
    // Initialize dialog
    const dialog = new mdc.dialog.MDCDialog(document.querySelector('#help-dialog'));

    // Initialize buttons
    const convertButton = new mdc.ripple.MDCRipple(document.querySelector('#convert-button'));
    const analyzeButton = new mdc.ripple.MDCRipple(document.querySelector('#analyze-button'));
    const downloadButton = new mdc.ripple.MDCRipple(document.querySelector('#download-button'));
    const helpButton = new mdc.ripple.MDCRipple(document.querySelector('#help-button'));

    // File Upload Handling
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const hlasmEditor = document.getElementById('hlasm-editor');

    // Drag and drop handlers
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        const files = e.dataTransfer.files;
        handleFiles(files);
    });

    dropZone.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });

    // File handling function
    function handleFiles(files) {
        const file = files[0];
        if (file && file.name.endsWith('.hlasm')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                hlasmEditor.value = e.target.result;
                showMessage('File loaded successfully!', 'success');
            };
            reader.readAsText(file);
        } else {
            showMessage('Please upload a valid HLASM file.', 'error');
        }
    }

    // Convert button handler
    document.getElementById('convert-button').addEventListener('click', async () => {
        const code = hlasmEditor.value;
        const strictValidation = document.getElementById('strict-validation').checked;

        if (!code) {
            showMessage('Please enter HLASM code or upload a file.', 'error');
            return;
        }

        try {
            showLoading(true);
            const response = await fetch('/convert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    code: code,
                    strict_validation: strictValidation
                })
            });

            const data = await response.json();
            if (response.ok) {
                document.getElementById('java-output').textContent = data.java_code;
                showMessage('Conversion successful!', 'success');
            } else {
                showMessage(data.error || 'Conversion failed.', 'error');
            }
        } catch (error) {
            console.error('Conversion error:', error);
            showMessage('An error occurred during conversion.', 'error');
        } finally {
            showLoading(false);
        }
    });

    // Analyze button handler
    document.getElementById('analyze-button').addEventListener('click', async () => {
        const code = hlasmEditor.value;
        if (!code) {
            showMessage('Please enter HLASM code or upload a file.', 'error');
            return;
        }

        try {
            showLoading(true);
            const response = await fetch('/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ code })
            });

            const data = await response.json();
            if (response.ok) {
                updateAnalysisContent(data);
                showMessage('Analysis completed!', 'success');
            } else {
                showMessage(data.error || 'Analysis failed.', 'error');
            }
        } catch (error) {
            showMessage('An error occurred during analysis.', 'error');
        } finally {
            showLoading(false);
        }
    });

    // Download button handler
    document.getElementById('download-button').addEventListener('click', () => {
        const javaCode = document.getElementById('java-output').textContent;
        if (!javaCode || javaCode === 'Java code will appear here...') {
            showMessage('No Java code to download.', 'error');
            return;
        }

        const blob = new Blob([javaCode], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'converted.java';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    });

    // Help button handler
    document.getElementById('help-button').addEventListener('click', () => {
        dialog.open();
    });

    // Tab change handler
    tabBar.listen('MDCTabBar:activated', (event) => {
        const tabIndex = event.detail.index;
        updateAnalysisTab(tabIndex);
    });

    // Utility functions
    function showMessage(message, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `${type}-message`;
        messageDiv.textContent = message;
        document.querySelector('.main-content').insertBefore(
            messageDiv,
            document.querySelector('.mdc-layout-grid')
        );
        setTimeout(() => messageDiv.remove(), 5000);
    }

    function showLoading(show) {
        const mainContent = document.querySelector('.main-content');
        if (show) {
            mainContent.classList.add('loading');
        } else {
            mainContent.classList.remove('loading');
        }
    }

    function updateAnalysisContent(data) {
        const content = document.getElementById('analysis-content');
        content.innerHTML = `
            <div class="analysis-section">
                <h3>Thread Safety Analysis</h3>
                <pre>${data.thread_safety || 'No thread safety issues found.'}</pre>
            </div>
            <div class="analysis-section">
                <h3>Memory Usage Analysis</h3>
                <pre>${data.memory_usage || 'No memory usage issues found.'}</pre>
            </div>
            <div class="analysis-section">
                <h3>Performance Analysis</h3>
                <pre>${data.performance || 'No performance issues found.'}</pre>
            </div>
            <div class="analysis-section">
                <h3>Code Quality Analysis</h3>
                <pre>${data.code_quality || 'No code quality issues found.'}</pre>
            </div>
        `;
    }

    function updateAnalysisTab(index) {
        const sections = document.querySelectorAll('.analysis-section');
        sections.forEach((section, i) => {
            section.style.display = i === index ? 'block' : 'none';
        });
    }
}); 