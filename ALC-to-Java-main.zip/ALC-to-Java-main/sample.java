package hlasm;

import java.io.*;
import java.lang.*;
import java.math.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class SAMPLE {
    private static final int SAMPLE = 0;
    private static final int SAVEAREA = 34;
    private static final int RESULT = 34;

    private static int[] registers = new int[16];

    private static int getRegister(int reg) {
        return registers[reg];
    }

    private static void setRegister(int reg, int value) {
        registers[reg] = value;
    }

    private static byte[] memory = new byte[1024 * 1024];

    private static int getMemory(int address) {
        return memory[address] & 0xFF;
    }

    private static void setMemory(int address, int value) {
        memory[address] = (byte) (value & 0xFF);
    }

    private static int conditionCode = 0;

    private static void setConditionCode(int value) {
        conditionCode = value;
    }

    private static int getConditionCode() {
        return conditionCode;
    }

    public static void main(String[] args) {
        setRegister(12, getMemory(15));
        setMemory(8 + getRegister(0) + getRegister(0), getRegister(14));
        setMemory(4 + getRegister(0) + getRegister(0), getRegister(13));
        setRegister(13, getMemory(14));
        setRegister(2, getMemory(F'100'));
        setRegister(3, getMemory(F'200'));
        setRegister(2, getRegister(2) + getMemory(3));
        setMemory(RESULT, getRegister(2));
        setRegister(13, getMemory(4 + getRegister(0) + getRegister(0)));
    }

    private static int add(int a, int b) {
        return a + b;
    }

    private static int subtract(int a, int b) {
        return a - b;
    }

    private static int multiply(int a, int b) {
        return a * b;
    }

    private static int divide(int a, int b) {
        return a / b;
    }

    private static int and(int a, int b) {
        return a & b;
    }

    private static int or(int a, int b) {
        return a | b;
    }

    private static int xor(int a, int b) {
        return a ^ b;
    }

    private static void branch(int address) {
        if (getConditionCode() == 0) {
            return;
        }
    }

    private static void branchAndLink(int reg, int address) {
        setRegister(reg, getRegister(15));
        if (getConditionCode() == 0) {
            return;
        }
    }

}