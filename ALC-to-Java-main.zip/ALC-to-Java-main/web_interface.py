from flask import Flask, render_template, request, jsonify
from src.converter.hlasm_parser import HLASMParser
from src.converter.java_generator import JavaGenerator

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    try:
        data = request.get_json()
        hlasm_code = data.get('code', '')
        strict_validation = data.get('strictValidation', False)

        if not hlasm_code:
            return jsonify({'error': 'No HLASM code provided'})

        # Parse HLASM code
        parser = HLASMParser()
        parser.strict_validation = strict_validation
        sections = parser.parse(hlasm_code)

        # Generate Java code
        generator = JavaGenerator()
        java_code = generator.generate(sections)

        # Get any warnings from the parser
        warnings = []
        if not strict_validation:
            warnings = parser.get_warnings()

        return jsonify({
            'javaCode': java_code,
            'warnings': warnings
        })

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True) 