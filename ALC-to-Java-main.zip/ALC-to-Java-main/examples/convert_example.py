import tkinter as tk
from alc_to_java_converter import ALCToJavaConverter

def convert_alc_file():
    # Read the ALC file
    with open('complex_example.alc', 'r') as file:
        alc_code = file.read()
    
    # Create a hidden root window
    root = tk.Tk()
    root.withdraw()  # Hide the window
    
    # Create converter instance
    converter = ALCToJavaConverter(root)
    
    # Set the input text
    converter.input_text.delete("1.0", tk.END)
    converter.input_text.insert("1.0", alc_code)
    
    # Convert to Java
    converter.convert_to_java()
    
    # Get the Java code
    java_code = converter.output_text.get("1.0", tk.END)
    
    # Write Java code to file
    with open('complex_example.java', 'w') as file:
        file.write(java_code)
    
    print("Conversion completed! Check complex_example.java for the result.")
    
    # Destroy the root window
    root.destroy()

if __name__ == "__main__":
    convert_alc_file() 