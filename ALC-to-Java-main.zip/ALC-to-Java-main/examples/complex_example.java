public class ALCProgram {
    public static void main(String[] args) {
        int NUM = 5        ; Calculate factorial of 5;
        int RESULT = 1     ; Initialize result to 1;
        int COUNTER = 1    ; Initialize counter to 1;
        // Label: LOOP_START
        int TEMP = COUNTER;
        TEMP -= NUM;
        // Unknown instruction: JZ LOOP_END    ; If counter == NUM, exit loop
        RESULT *= COUNTER;
        COUNTER += 1;
        // Jump to LOOP_START
        continue;
        // Label: LOOP_END
        int DISPLAY = RESULT;
        int A = 10;
        int B = 5;
        A += B          ; A = A + B (15);
        A -= 3          ; A = A - 3 (12);
        A *= 2          ; A = A * 2 (24);
        A /= 4          ; A = A / 4 (6);
        int X = 10;
        int Y = 5;
        X -= Y          ; X = X - Y (5);
        // Unknown instruction: JZ EQUAL          ; If X == 0, jump to EQUAL
        // Jump to NOT_EQUAL     ; Otherwise jump to NOT_EQUAL
        continue;
        // Label: EQUAL
        int Z = 1      ; Set Z to 1 if X == Y;
        // Jump to END
        continue;
        // Label: NOT_EQUAL
        int Z = 0      ; Set Z to 0 if X != Y;
        // Label: END
    }
}