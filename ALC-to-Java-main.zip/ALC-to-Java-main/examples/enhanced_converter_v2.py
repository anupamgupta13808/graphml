def translate_alc_to_java(alc_code):
    # Basic ALC to Java translation rules
    java_code = []
    java_code.append("public class ALCProgram {")
    java_code.append("    public static void main(String[] args) {")
    
    # Add necessary imports and helper methods
    java_code.append("        // Helper methods for matrix and string operations")
    java_code.append("        private static void printMatrix(int[][] matrix, int rows, int cols) {")
    java_code.append("            for (int i = 0; i < rows; i++) {")
    java_code.append("                for (int j = 0; j < cols; j++) {")
    java_code.append("                    System.out.print(matrix[i][j] + \" \");")
    java_code.append("                }")
    java_code.append("                System.out.println();")
    java_code.append("            }")
    java_code.append("        }")
    java_code.append("")
    java_code.append("        private static void printArray(int[] array, int size) {")
    java_code.append("            for (int i = 0; i < size; i++) {")
    java_code.append("                System.out.print(array[i] + \" \");")
    java_code.append("            }")
    java_code.append("            System.out.println();")
    java_code.append("        }")
    java_code.append("")
    
    # Track variables and their types
    variables = {}
    arrays = set()
    matrices = set()
    strings = set()
    
    # Split ALC code into lines
    lines = alc_code.split('\n')
    
    # First pass: identify variables and their types
    for line in lines:
        line = line.strip()
        if not line or line.startswith(';'):
            continue
            
        if line.startswith('MOV'):
            parts = line.split(',')
            if len(parts) == 2:
                dest = parts[0].replace('MOV', '').strip()
                src = parts[1].strip()
                
                # Check if it's a matrix operation
                if '[' in dest and dest.count('[') == 2:
                    matrices.add(dest.split('[')[0])
                # Check if it's an array operation
                elif '[' in dest:
                    arrays.add(dest.split('[')[0])
                # Check if it's a string
                elif src.startswith('"') and src.endswith('"'):
                    strings.add(dest)
                # Check if it's a binary number
                elif src.startswith('0b'):
                    variables[dest] = 'int'
                else:
                    variables[dest] = 'int'
    
    # Add variable declarations
    for var in variables:
        java_code.append(f"        int {var};")
    
    for arr in arrays:
        java_code.append(f"        int[] {arr} = new int[100];  // Assuming max size of 100")
    
    for matrix in matrices:
        java_code.append(f"        int[][] {matrix} = new int[10][10];  // Assuming max size of 10x10")
    
    for str_var in strings:
        java_code.append(f"        String {str_var};")
    
    java_code.append("")
    
    # Second pass: translate instructions
    for line in lines:
        line = line.strip()
        if not line or line.startswith(';'):
            java_code.append(f"        // {line}")
            continue
            
        # Basic instruction translation
        if line.startswith('MOV'):
            parts = line.split(',')
            if len(parts) == 2:
                dest = parts[0].replace('MOV', '').strip()
                src = parts[1].strip()
                
                # Handle matrix operations
                if '[' in dest and dest.count('[') == 2:
                    matrix_name = dest.split('[')[0]
                    indices = dest[dest.find('[')+1:dest.rfind(']')].split('][')
                    row, col = indices[0], indices[1]
                    java_code.append(f"        {matrix_name}[{row}][{col}] = {src};")
                # Handle array operations
                elif '[' in dest:
                    array_name = dest.split('[')[0]
                    index = dest.split('[')[1].rstrip(']')
                    java_code.append(f"        {array_name}[{index}] = {src};")
                # Handle string assignments
                elif src.startswith('"') and src.endswith('"'):
                    java_code.append(f"        {dest} = {src};")
                # Handle binary numbers
                elif src.startswith('0b'):
                    binary = src[2:]  # Remove '0b' prefix
                    java_code.append(f"        {dest} = 0b{binary};")
                else:
                    java_code.append(f"        {dest} = {src};")
        
        elif line.startswith('ADD'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('ADD', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} += {src};")
        
        elif line.startswith('SUB'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('SUB', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} -= {src};")
        
        elif line.startswith('MUL'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('MUL', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} *= {src};")
        
        elif line.startswith('DIV'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('DIV', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} /= {src};")
        
        elif line.startswith('AND'):
            parts = line.split(',')
            if len(parts) == 3:
                dest, src1, src2 = parts[0].replace('AND', '').strip(), parts[1].strip(), parts[2].strip()
                java_code.append(f"        {dest} = {src1} & {src2};")
        
        elif line.startswith('OR'):
            parts = line.split(',')
            if len(parts) == 3:
                dest, src1, src2 = parts[0].replace('OR', '').strip(), parts[1].strip(), parts[2].strip()
                java_code.append(f"        {dest} = {src1} | {src2};")
        
        elif line.startswith('XOR'):
            parts = line.split(',')
            if len(parts) == 3:
                dest, src1, src2 = parts[0].replace('XOR', '').strip(), parts[1].strip(), parts[2].strip()
                java_code.append(f"        {dest} = {src1} ^ {src2};")
        
        elif line.startswith('NOT'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('NOT', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} = ~{src};")
        
        elif line.startswith('SHL'):
            parts = line.split(',')
            if len(parts) == 3:
                dest, src, shift = parts[0].replace('SHL', '').strip(), parts[1].strip(), parts[2].strip()
                java_code.append(f"        {dest} = {src} << {shift};")
        
        elif line.startswith('SHR'):
            parts = line.split(',')
            if len(parts) == 3:
                dest, src, shift = parts[0].replace('SHR', '').strip(), parts[1].strip(), parts[2].strip()
                java_code.append(f"        {dest} = {src} >> {shift};")
        
        elif line.startswith('JMP'):
            label = line.replace('JMP', '').strip()
            java_code.append(f"        // Jump to {label}")
            java_code.append(f"        continue;")
        
        elif line.startswith('JZ'):
            label = line.replace('JZ', '').strip()
            java_code.append(f"        if (TEMP == 0) {{")
            java_code.append(f"            // Jump to {label}")
            java_code.append(f"            continue;")
            java_code.append(f"        }}")
        
        elif line.startswith('JG'):
            label = line.replace('JG', '').strip()
            java_code.append(f"        if (TEMP > 0) {{")
            java_code.append(f"            // Jump to {label}")
            java_code.append(f"            continue;")
            java_code.append(f"        }}")
        
        elif line.startswith('JL'):
            label = line.replace('JL', '').strip()
            java_code.append(f"        if (TEMP < 0) {{")
            java_code.append(f"            // Jump to {label}")
            java_code.append(f"            continue;")
            java_code.append(f"        }}")
        
        elif line.endswith(':'):
            label = line[:-1]
            java_code.append(f"        // Label: {label}")
            java_code.append(f"        {label}:")
        
        elif line.startswith('MOV') and 'DISPLAY' in line:
            # Handle display operations
            value = line.split(',')[1].strip()
            if value.startswith('"'):
                java_code.append(f"        System.out.println({value});")
            else:
                java_code.append(f"        System.out.println({value});")
        
        else:
            java_code.append(f"        // Unknown instruction: {line}")
    
    # Add main loop structure
    java_code.insert(2, "        boolean running = true;")
    java_code.insert(3, "        while (running) {")
    java_code.append("            running = false;  // Exit after one iteration")
    java_code.append("        }")
    java_code.append("    }")
    java_code.append("}")
    
    return '\n'.join(java_code)

def convert_alc_file():
    # Read the ALC file
    with open('matrix_sort_example.alc', 'r') as file:
        alc_code = file.read()
    
    # Convert to Java
    java_code = translate_alc_to_java(alc_code)
    
    # Write Java code to file
    with open('matrix_sort_example.java', 'w') as file:
        file.write(java_code)
    
    print("Conversion completed! Check matrix_sort_example.java for the result.")

if __name__ == "__main__":
    convert_alc_file() 