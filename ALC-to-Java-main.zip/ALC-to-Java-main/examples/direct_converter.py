def translate_alc_to_java(alc_code):
    # Basic ALC to Java translation rules
    java_code = []
    java_code.append("public class ALCProgram {")
    java_code.append("    public static void main(String[] args) {")
    
    # Split ALC code into lines
    lines = alc_code.split('\n')
    
    # Process each line
    for line in lines:
        line = line.strip()
        if not line or line.startswith(';'):  # Skip empty lines and comments
            continue
            
        # Basic instruction translation
        if line.startswith('MOV'):
            # Handle MOV instruction
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('MOV', '').strip(), parts[1].strip()
                java_code.append(f"        int {dest} = {src};")
        
        elif line.startswith('ADD'):
            # Handle ADD instruction
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('ADD', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} += {src};")
        
        elif line.startswith('SUB'):
            # Handle SUB instruction
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('SUB', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} -= {src};")
        
        elif line.startswith('MUL'):
            # Handle MUL instruction
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('MUL', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} *= {src};")
        
        elif line.startswith('DIV'):
            # Handle DIV instruction
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('DIV', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} /= {src};")
        
        elif line.startswith('JMP'):
            # Handle JMP instruction
            label = line.replace('JMP', '').strip()
            java_code.append(f"        // Jump to {label}")
            java_code.append(f"        continue;")
        
        elif line.endswith(':'):
            # Handle labels
            label = line[:-1]
            java_code.append(f"        // Label: {label}")
        
        else:
            # Unknown instruction
            java_code.append(f"        // Unknown instruction: {line}")
    
    java_code.append("    }")
    java_code.append("}")
    
    return '\n'.join(java_code)

def convert_alc_file():
    # Read the ALC file
    with open('complex_example.alc', 'r') as file:
        alc_code = file.read()
    
    # Convert to Java
    java_code = translate_alc_to_java(alc_code)
    
    # Write Java code to file
    with open('complex_example.java', 'w') as file:
        file.write(java_code)
    
    print("Conversion completed! Check complex_example.java for the result.")

if __name__ == "__main__":
    convert_alc_file() 