def translate_alc_to_java(alc_code):
    # Basic ALC to Java translation rules
    java_code = []
    java_code.append("public class ALCProgram {")
    java_code.append("    public static void main(String[] args) {")
    
    # Add necessary imports and helper methods
    java_code.append("        // Helper method for array operations")
    java_code.append("        static int[] array = new int[100];  // Assuming max array size of 100")
    java_code.append("        static String[] strings = new String[10];  // For string operations")
    java_code.append("")
    
    # Track variables and their types
    variables = {}
    arrays = set()
    strings = set()
    
    # Split ALC code into lines
    lines = alc_code.split('\n')
    
    # First pass: identify variables and their types
    for line in lines:
        line = line.strip()
        if not line or line.startswith(';'):
            continue
            
        if line.startswith('MOV'):
            parts = line.split(',')
            if len(parts) == 2:
                dest = parts[0].replace('MOV', '').strip()
                src = parts[1].strip()
                
                # Check if it's an array operation
                if '[' in dest:
                    arrays.add(dest.split('[')[0])
                # Check if it's a string
                elif src.startswith('"') and src.endswith('"'):
                    strings.add(dest)
                else:
                    variables[dest] = 'int'
    
    # Add variable declarations
    for var in variables:
        java_code.append(f"        int {var};")
    
    for arr in arrays:
        java_code.append(f"        int[] {arr} = new int[100];  // Assuming max size of 100")
    
    for str_var in strings:
        java_code.append(f"        String {str_var};")
    
    java_code.append("")
    
    # Second pass: translate instructions
    for line in lines:
        line = line.strip()
        if not line or line.startswith(';'):
            java_code.append(f"        // {line}")
            continue
            
        # Basic instruction translation
        if line.startswith('MOV'):
            parts = line.split(',')
            if len(parts) == 2:
                dest = parts[0].replace('MOV', '').strip()
                src = parts[1].strip()
                
                # Handle array operations
                if '[' in dest:
                    array_name = dest.split('[')[0]
                    index = dest.split('[')[1].rstrip(']')
                    java_code.append(f"        {array_name}[{index}] = {src};")
                # Handle string assignments
                elif src.startswith('"') and src.endswith('"'):
                    java_code.append(f"        {dest} = {src};")
                else:
                    java_code.append(f"        {dest} = {src};")
        
        elif line.startswith('ADD'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('ADD', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} += {src};")
        
        elif line.startswith('SUB'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('SUB', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} -= {src};")
        
        elif line.startswith('MUL'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('MUL', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} *= {src};")
        
        elif line.startswith('DIV'):
            parts = line.split(',')
            if len(parts) == 2:
                dest, src = parts[0].replace('DIV', '').strip(), parts[1].strip()
                java_code.append(f"        {dest} /= {src};")
        
        elif line.startswith('JMP'):
            label = line.replace('JMP', '').strip()
            java_code.append(f"        // Jump to {label}")
            java_code.append(f"        continue;")
        
        elif line.startswith('JZ'):
            label = line.replace('JZ', '').strip()
            java_code.append(f"        if (TEMP == 0) {{")
            java_code.append(f"            // Jump to {label}")
            java_code.append(f"            continue;")
            java_code.append(f"        }}")
        
        elif line.startswith('JG'):
            label = line.replace('JG', '').strip()
            java_code.append(f"        if (TEMP > 0) {{")
            java_code.append(f"            // Jump to {label}")
            java_code.append(f"            continue;")
            java_code.append(f"        }}")
        
        elif line.startswith('JL'):
            label = line.replace('JL', '').strip()
            java_code.append(f"        if (TEMP < 0) {{")
            java_code.append(f"            // Jump to {label}")
            java_code.append(f"            continue;")
            java_code.append(f"        }}")
        
        elif line.endswith(':'):
            label = line[:-1]
            java_code.append(f"        // Label: {label}")
            java_code.append(f"        {label}:")
        
        elif line.startswith('MOV') and 'DISPLAY' in line:
            # Handle display operations
            value = line.split(',')[1].strip()
            if value.startswith('"'):
                java_code.append(f"        System.out.println({value});")
            else:
                java_code.append(f"        System.out.println({value});")
        
        else:
            java_code.append(f"        // Unknown instruction: {line}")
    
    # Add main loop structure
    java_code.insert(2, "        boolean running = true;")
    java_code.insert(3, "        while (running) {")
    java_code.append("            running = false;  // Exit after one iteration")
    java_code.append("        }")
    java_code.append("    }")
    java_code.append("}")
    
    return '\n'.join(java_code)

def convert_alc_file():
    # Read the ALC file
    with open('advanced_example.alc', 'r') as file:
        alc_code = file.read()
    
    # Convert to Java
    java_code = translate_alc_to_java(alc_code)
    
    # Write Java code to file
    with open('advanced_example.java', 'w') as file:
        file.write(java_code)
    
    print("Conversion completed! Check advanced_example.java for the result.")

if __name__ == "__main__":
    convert_alc_file() 