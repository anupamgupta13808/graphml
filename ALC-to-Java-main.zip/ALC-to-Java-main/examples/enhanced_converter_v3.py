import os
import sys
from typing import Dict, Set, List

class ALCConverter:
    def __init__(self):
        self.variables: Dict[str, str] = {}  # name -> type
        self.arrays: Set[str] = set()
        self.matrices: Set[str] = set()
        self.strings: Set[str] = set()
        self.floats: Set[str] = set()
        self.stack_vars: Set[str] = set()
        self.file_handles: Set[str] = set()
        self.labels: Set[str] = set()
        self.error_handling = True

    def translate_alc_to_java(self, alc_code: str) -> str:
        java_code = []
        java_code.append("import java.io.*;")
        java_code.append("import java.util.*;")
        java_code.append("")
        java_code.append("public class ALCProgram {")
        
        # Add helper methods
        self._add_helper_methods(java_code)
        
        # First pass: identify variables and their types
        self._analyze_variables(alc_code)
        
        # Add variable declarations
        java_code.append("    // Global variables")
        self._add_variable_declarations(java_code)
        
        # Detect subroutines (labels used as CALL targets)
        subroutines = self._detect_subroutines(alc_code)
        
        # Add main method
        java_code.append("    public static void main(String[] args) {")
        java_code.append("        try {")
        java_code.append("            // Initialize stack")
        java_code.append("            Stack<Integer> stack = new Stack<>();")
        java_code.append("")
        # Add main body (excluding subroutines)
        self._translate_main_body(alc_code, java_code, subroutines)
        java_code.append("        } catch (FileNotFoundException e) {")
        java_code.append("            System.err.println(\"Error: File not found - \" + e.getMessage());")
        java_code.append("        } catch (IOException e) {")
        java_code.append("            System.err.println(\"Error: I/O operation failed - \" + e.getMessage());")
        java_code.append("        } catch (Exception e) {")
        java_code.append("            System.err.println(\"Error: \" + e.getMessage());")
        java_code.append("        }")
        java_code.append("    }")
        
        # Add subroutine methods
        self._translate_subroutines(alc_code, java_code, subroutines)
        java_code.append("}")
        return '\n'.join(java_code)

    def _add_helper_methods(self, java_code: List[str]):
        # Matrix operations
        java_code.append("    private static void printMatrix(int[][] matrix, int rows, int cols) {")
        java_code.append("        for (int i = 0; i < rows; i++) {")
        java_code.append("            for (int j = 0; j < cols; j++) {")
        java_code.append("                System.out.print(matrix[i][j] + \" \");")
        java_code.append("            }")
        java_code.append("            System.out.println();")
        java_code.append("        }")
        java_code.append("    }")
        java_code.append("")
        
        # Array operations
        java_code.append("    private static void printArray(int[] array, int size) {")
        java_code.append("        for (int i = 0; i < size; i++) {")
        java_code.append("            System.out.print(array[i] + \" \");")
        java_code.append("        }")
        java_code.append("        System.out.println();")
        java_code.append("    }")
        java_code.append("")
        
        # File operations
        java_code.append("    private static void writeToFile(String filename, String content) throws IOException {")
        java_code.append("        try (FileWriter writer = new FileWriter(filename)) {")
        java_code.append("            writer.write(content);")
        java_code.append("        }")
        java_code.append("    }")
        java_code.append("")
        
        java_code.append("    private static String readFromFile(String filename) throws IOException {")
        java_code.append("        StringBuilder content = new StringBuilder();")
        java_code.append("        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {")
        java_code.append("            String line;")
        java_code.append("            while ((line = reader.readLine()) != null) {")
        java_code.append("                content.append(line).append(\"\\n\");")
        java_code.append("            }")
        java_code.append("        }")
        java_code.append("        return content.toString();")
        java_code.append("    }")
        java_code.append("")

    def _analyze_variables(self, alc_code: str):
        lines = alc_code.split('\n')
        for line in lines:
            line = line.strip()
            if not line or line.startswith(';'):
                continue
                
            if line.startswith('MOV'):
                parts = line.split(',')
                if len(parts) == 2:
                    dest = parts[0].replace('MOV', '').strip()
                    src = parts[1].strip()
                    
                    # Check for matrix operations
                    if '[' in dest and dest.count('[') == 2:
                        self.matrices.add(dest.split('[')[0])
                    # Check for array operations
                    elif '[' in dest:
                        self.arrays.add(dest.split('[')[0])
                    # Check for string assignments
                    elif src.startswith('"') and src.endswith('"'):
                        self.strings.add(dest)
                    # Check for floating-point numbers
                    elif '.' in src:
                        self.floats.add(dest)
                    # Check for file handles
                    elif dest.startswith('FILE_'):
                        self.file_handles.add(dest)
                    else:
                        self.variables[dest] = 'int'
            
            elif line.endswith(':'):
                self.labels.add(line[:-1])

    def _add_variable_declarations(self, java_code: List[str]):
        # Add regular variables
        for var, type_ in self.variables.items():
            java_code.append(f"            {type_} {var};")
        
        # Add arrays
        for arr in self.arrays:
            java_code.append(f"            int[] {arr} = new int[100];  // Assuming max size of 100")
        
        # Add matrices
        for matrix in self.matrices:
            java_code.append(f"            int[][] {matrix} = new int[10][10];  // Assuming max size of 10x10")
        
        # Add strings
        for str_var in self.strings:
            java_code.append(f"            String {str_var};")
        
        # Add floating-point variables
        for float_var in self.floats:
            java_code.append(f"            double {float_var};")
        
        # Add file handles
        for handle in self.file_handles:
            java_code.append(f"            int {handle};")
        
        java_code.append("")

    def _detect_subroutines(self, alc_code: str):
        # Find all labels that are CALL targets
        lines = alc_code.split('\n')
        subroutines = set()
        for line in lines:
            if line.strip().startswith('CALL'):
                label = line.strip().split()[1]
                subroutines.add(label)
        return subroutines

    def _translate_main_body(self, alc_code: str, java_code: List[str], subroutines: set):
        lines = alc_code.split('\n')
        in_subroutine = False
        for line in lines:
            line_strip = line.strip()
            if line_strip.endswith(':') and line_strip[:-1] in subroutines:
                in_subroutine = True
            if in_subroutine:
                continue
            if line_strip.startswith('CALL'):
                label = line_strip.split()[1]
                java_code.append(f"            {label}();")
            elif line_strip == 'RET':
                java_code.append(f"            return;")
            else:
                self._translate_single_instruction(line_strip, java_code)

    def _translate_subroutines(self, alc_code: str, java_code: List[str], subroutines: set):
        lines = alc_code.split('\n')
        current_sub = None
        sub_body = []
        for line in lines:
            line_strip = line.strip()
            if line_strip.endswith(':') and line_strip[:-1] in subroutines:
                if current_sub:
                    self._emit_subroutine(java_code, current_sub, sub_body)
                current_sub = line_strip[:-1]
                sub_body = []
                continue
            if current_sub:
                if line_strip == 'RET':
                    sub_body.append('RET')
                    self._emit_subroutine(java_code, current_sub, sub_body)
                    current_sub = None
                    sub_body = []
                else:
                    sub_body.append(line_strip)
        if current_sub:
            self._emit_subroutine(java_code, current_sub, sub_body)

    def _emit_subroutine(self, java_code: List[str], name: str, body: list):
        java_code.append(f"    private static void {name}() {{")
        for line in body:
            if line == 'RET':
                java_code.append(f"        return;")
            elif line.startswith('CALL'):
                label = line.split()[1]
                java_code.append(f"        {label}();")
            else:
                self._translate_single_instruction(line, java_code, indent='        ')
        java_code.append(f"    }}")

    def _translate_single_instruction(self, line: str, java_code: List[str], indent: str = '            '):
        if not line or line.startswith(';'):
            java_code.append(f"{indent}// {line}")
            return
        if line.startswith('MOV'):
            self._translate_mov(line, java_code, indent)
        elif line.startswith('ADD'):
            self._translate_add(line, java_code, indent)
        elif line.startswith('SUB'):
            self._translate_sub(line, java_code, indent)
        elif line.startswith('MUL'):
            self._translate_mul(line, java_code, indent)
        elif line.startswith('DIV'):
            self._translate_div(line, java_code, indent)
        elif line.startswith('PUSH'):
            self._translate_push(line, java_code, indent)
        elif line.startswith('POP'):
            self._translate_pop(line, java_code, indent)
        elif line.startswith('FADD'):
            self._translate_fadd(line, java_code, indent)
        elif line.startswith('FSUB'):
            self._translate_fsub(line, java_code, indent)
        elif line.startswith('FMUL'):
            self._translate_fmul(line, java_code, indent)
        elif line.startswith('FDIV'):
            self._translate_fdiv(line, java_code, indent)
        elif line.startswith('JMP'):
            java_code.append(f"{indent}// Unhandled JMP: {line}")
        elif line.startswith('JZ'):
            java_code.append(f"{indent}// Unhandled JZ: {line}")
        elif line.startswith('JNZ'):
            java_code.append(f"{indent}// Unhandled JNZ: {line}")
        elif line.startswith('JG'):
            java_code.append(f"{indent}// Unhandled JG: {line}")
        elif line.startswith('JL'):
            java_code.append(f"{indent}// Unhandled JL: {line}")
        elif 'FILE_OP' in line:
            self._translate_file_op(line, java_code, indent)
        else:
            java_code.append(f"{indent}// Unknown or unhandled instruction: {line}")

    def _translate_mov(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest = parts[0].replace('MOV', '').strip()
            src = parts[1].strip()
            
            if '[' in dest and dest.count('[') == 2:
                matrix_name = dest.split('[')[0]
                indices = dest[dest.find('[')+1:dest.rfind(']')].split('][')
                row, col = indices[0], indices[1]
                java_code.append(f"{indent}{matrix_name}[{row}][{col}] = {src};")
            elif '[' in dest:
                array_name = dest.split('[')[0]
                index = dest.split('[')[1].rstrip(']')
                java_code.append(f"{indent}{array_name}[{index}] = {src};")
            elif src.startswith('"') and src.endswith('"'):
                java_code.append(f"{indent}{dest} = {src};")
            else:
                java_code.append(f"{indent}{dest} = {src};")

    def _translate_push(self, line: str, java_code: List[str], indent: str = '            '):
        value = line.replace('PUSH', '').strip()
        java_code.append(f"{indent}stack.push({value});")

    def _translate_pop(self, line: str, java_code: List[str], indent: str = '            '):
        dest = line.replace('POP', '').strip()
        java_code.append(f"{indent}{dest} = stack.pop();")

    def _translate_fadd(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('FADD', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} += {src};")

    def _translate_fsub(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('FSUB', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} -= {src};")

    def _translate_fmul(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('FMUL', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} *= {src};")

    def _translate_fdiv(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('FDIV', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} /= {src};")

    def _translate_file_op(self, line: str, java_code: List[str], indent: str = '            '):
        if 'FILE_OP' in line:
            op = line.split(',')[1].strip()
            if op == '"write"':
                java_code.append(f"{indent}writeToFile(FILE_NAME, FILE_CONTENT);")
            elif op == '"read"':
                java_code.append(f"{indent}FILE_CONTENT = readFromFile(FILE_NAME);")
            elif op == '"close"':
                java_code.append(f"{indent}// File closed automatically by try-with-resources")

    def _translate_add(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('ADD', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} += {src};")

    def _translate_sub(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('SUB', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} -= {src};")

    def _translate_mul(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('MUL', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} *= {src};")

    def _translate_div(self, line: str, java_code: List[str], indent: str = '            '):
        parts = line.split(',')
        if len(parts) == 2:
            dest, src = parts[0].replace('DIV', '').strip(), parts[1].strip()
            java_code.append(f"{indent}{dest} /= {src};")

def convert_alc_file():
    # Read the ALC file
    with open('recursion_example.alc', 'r') as file:
        alc_code = file.read()
    
    # Convert to Java
    converter = ALCConverter()
    java_code = converter.translate_alc_to_java(alc_code)
    
    # Write Java code to file
    with open('recursion_example.java', 'w') as file:
        file.write(java_code)
    
    print("Conversion completed! Check recursion_example.java for the result.")

if __name__ == "__main__":
    convert_alc_file() 