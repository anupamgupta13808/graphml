import os
import re
from flask import Flask, render_template, request, flash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "supersecretkey" # Needed for flashing messages
app.config['UPLOAD_FOLDER'] = 'uploads' # Optional: if you want to save files

# Ensure the upload folder exists if you decide to save files
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Common directive keywords (case-insensitive for matching, stored in uppercase)
KNOWN_DIRECTIVE_KEYWORDS = {
    'DB', 'DW', 'DD', 'DQ', 'RESB', 'RESW', 'RESD', 'RESQ',
    'BYTE', 'WORD', 'DWORD', 'QWORD', '.BYTE', '.WORD', # GAS-like, also some assemblers use . prefix
    'SEGMENT', 'ENDS', 'PROC', 'ENDP', 'GROUP', 'ASSUME',
    'ORG', 'EQU', 'SET', 'ALIGN', 'EXTERN', 'GLOBAL', 'PUBLIC',
    'SECTION', '.SECTION', '.TEXT', '.DATA', '.BSS', 'CODE', 'CONST',
    'INCLUDE', 'MACRO', 'ENDM', 'END', 'OFFSET', 'PTR'
}

def parse_asm_alc_content(file_content):
    """
    Parses the content of an ASM/ALC file to extract instructions,
    labels, directives, and comments.
    """
    lines = file_content.splitlines()
    
    detected_instructions = set()
    detected_labels = set()
    detected_directives = set()
    extracted_comments = []

    for line_num, original_line in enumerate(lines):
        line = original_line.strip()

        if not line: # Skip empty lines
            continue

        # 1. Handle Comments (extract and then remove for further processing)
        comment_content = ""
        code_part = line
        
        # Handle different comment styles (e.g., ';', '#', '//')
        # For this example, primarily focusing on ';' as common in ASM
        comment_delimiters = [';', '#'] 
        for delim in comment_delimiters:
            if delim in code_part:
                temp_code_part, temp_comment_content = code_part.split(delim, 1)
                # Ensure we take the earliest comment delimiter on the line
                if len(temp_code_part) < len(code_part.split(comment_content[0],1)[0] if comment_content else code_part):
                    code_part = temp_code_part
                    comment_content = delim + temp_comment_content
        
        code_part = code_part.strip()
        if comment_content:
            extracted_comments.append(f"L{line_num+1}: {comment_content.strip()}")

        if not code_part: # Line was only a comment or empty after stripping comment
            continue

        # 2. Handle Labels (ending with ':')
        # Regex: starts with a letter or underscore, followed by alphanumeric or underscore, ending with ':'
        label_match = re.match(r'^([a-zA-Z_][a-zA-Z0-9_]*):', code_part)
        if label_match:
            label_name = label_match.group(1)
            detected_labels.add(label_name)
            # Remove label from code_part for further processing
            code_part = code_part[len(label_match.group(0)):].strip() 
            if not code_part: # Line was only a label
                continue
        
        # 3. Tokenize the remaining code_part
        # Split into the first word (potential instruction/directive/label) and the rest
        parts = code_part.split(None, 1)
        if not parts:
            continue
            
        first_word = parts[0]
        # rest_of_line = parts[1] if len(parts) > 1 else "" # Not directly used in this simplified logic block

        # 4. Identify Directives or Labels associated with Directives
        is_directive_line = False
        
        # Check if first_word is a directive (e.g., .DATA, ORG)
        if first_word.startswith('.'): # Directives like .data, .text
            detected_directives.add(first_word)
            is_directive_line = True
        elif first_word.upper() in KNOWN_DIRECTIVE_KEYWORDS: # Directives like SEGMENT, DB, DW
            detected_directives.add(first_word.upper())
            is_directive_line = True
        
        # Check if first_word is a label for a directive that follows (e.g., MY_VAR DW 0)
        # This occurs if first_word is NOT a directive itself, but the NEXT word is.
        if not is_directive_line and len(parts) > 1:
            # parts[1] contains the rest of the line. The first word of parts[1] is the second word.
            second_word_candidate_parts = parts[1].split(None, 1)
            if second_word_candidate_parts:
                second_word = second_word_candidate_parts[0]
                if second_word.upper() in KNOWN_DIRECTIVE_KEYWORDS or second_word.startswith('.'):
                    # Then first_word is likely a label/symbol
                    detected_labels.add(first_word) 
                    # Add the directive itself
                    detected_directives.add(second_word.upper() if not second_word.startswith('.') else second_word)
                    is_directive_line = True # This line is now handled as a directive line

        # 5. Identify Instructions
        if not is_directive_line:
            # If it's not a directive line, and not empty, the first_word is likely an instruction.
            # This assumes labels without ":" are handled if followed by a directive.
            # Labels on their own line without ":" might be misclassified as instructions.
            # A simple check for instruction-like names (alphanumeric, starting with letter/underscore)
            if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', first_word):
                # Avoid adding already identified labels (those that had ':') as instructions
                # This check is a bit redundant if label_match already processed it, but good for safety.
                if first_word not in detected_labels: 
                    detected_instructions.add(first_word.upper())

    return {
        "instructions": sorted(list(detected_instructions)),
        "labels": sorted(list(detected_labels)),
        "directives": sorted(list(detected_directives)),
        "comments": extracted_comments[:30] # Show up to 30 comments
    }

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return render_template('index.html', error='No file part selected.')
        
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return render_template('index.html', error='No file selected.')

        if file:
            filename = secure_filename(file.filename)
            # It's generally safer to read the file content directly
            # without saving it to the server filesystem unless necessary.
            try:
                file_content = file.read().decode('utf-8', errors='ignore') # Decode with error handling
                results = parse_asm_alc_content(file_content)
                return render_template('index.html', results=results, filename=filename)
            except Exception as e:
                app.logger.error(f"Error processing file: {e}")
                return render_template('index.html', error=f"Could not process file: {e}")
        
    return render_template('index.html')

if __name__ == '__main__':
    # For development, you can run with debug=True
    # For production, use a proper WSGI server like Gunicorn or Waitress
    app.run(debug=True)
