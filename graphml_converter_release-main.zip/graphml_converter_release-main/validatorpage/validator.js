// GraphML validation and analysis functions
function validateFile() {
    const fileInput = document.getElementById('graphmlFile');
    const file = fileInput.files[0];
    
    if (!file) {
        showValidationResult('error', 'Please select a file first.');
        return;
    }

    // Store the filename for later use
    const fileName = file.name;

    const reader = new FileReader();
    reader.onload = function(e) {
        const content = e.target.result;
        analyzeGraphML(content, fileName);
    };
    reader.readAsText(file);
}

function analyzeGraphML(content, fileName) {
    try {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(content, "text/xml");
        
        // Clear previous results
        const resultsDiv = document.getElementById('validationResults');
        resultsDiv.innerHTML = '';

        // Check for parsing errors
        const parserError = xmlDoc.querySelector('parsererror');
        if (parserError) {
            showValidationResult('error', 'Invalid XML format');
            return;
        }

        // Validate basic structure
        const graph = xmlDoc.querySelector('graph');
        if (!graph) {
            showValidationResult('error', 'No graph element found');
            return;
        }

        // Create capabilities table
        const tableDiv = document.createElement('div');
        tableDiv.className = 'capabilities-table mt-4';
        tableDiv.innerHTML = `
            <h5>Graph Capabilities Analysis</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Feature</th>
                        <th>GraphML</th>
                        <th>Python NetworkX</th>
                        <th>Java JGraphT</th>
                    </tr>
                </thead>
                <tbody>
                    ${generateCapabilityRows(xmlDoc)}
                </tbody>
            </table>
        `;
        
        resultsDiv.appendChild(tableDiv);

        // Generate conversion commands
        generateConversionCommands(fileName);

    } catch (error) {
        showValidationResult('error', `Error analyzing file: ${error.message}`);
    }
}

function generateCapabilityRows(xmlDoc) {
    const capabilities = [
        // Basic Structure
        {
            name: 'Basic Graph Structure',
            check: (doc) => doc.querySelector('graph') !== null,
            allSupported: true
        },
        {
            name: 'Directed Graph',
            check: (doc) => doc.querySelector('graph[edgedefault="directed"]') !== null,
            allSupported: true
        },
        {
            name: 'Undirected Graph',
            check: (doc) => doc.querySelector('graph[edgedefault="undirected"]') !== null,
            allSupported: true
        },
        
        // Node Features
        {
            name: 'Node Attributes',
            check: (doc) => doc.querySelector('node data') !== null,
            allSupported: true
        },
        {
            name: 'Node Labels',
            check: (doc) => doc.querySelector('node[labels]') !== null,
            allSupported: true
        },
        {
            name: 'Node Types',
            check: (doc) => doc.querySelector('node[type]') !== null,
            allSupported: true
        },
        
        // Edge Features
        {
            name: 'Edge Attributes',
            check: (doc) => doc.querySelector('edge data') !== null,
            allSupported: true
        },
        {
            name: 'Edge Weights',
            check: (doc) => Array.from(doc.querySelectorAll('edge data')).some(data => 
                data.getAttribute('key') === 'weight'),
            allSupported: true
        },
        {
            name: 'Edge Labels',
            check: (doc) => doc.querySelector('edge[labels]') !== null,
            allSupported: true
        },
        {
            name: 'Edge Types',
            check: (doc) => doc.querySelector('edge[type]') !== null,
            allSupported: true
        },
        {
            name: 'Self-loops',
            check: (doc) => Array.from(doc.querySelectorAll('edge')).some(edge => 
                edge.getAttribute('source') === edge.getAttribute('target')),
            allSupported: true
        },
        
        // Graph Features
        {
            name: 'Nested Graphs',
            check: (doc) => doc.querySelector('graph > graph') !== null,
            graphml: true,
            python: 'limited',
            java: 'limited'
        },
        {
            name: 'Hypergraphs',
            check: (doc) => doc.querySelector('hyperedge') !== null,
            graphml: true,
            python: false,
            java: false
        },
        {
            name: 'Ports',
            check: (doc) => doc.querySelector('port') !== null,
            graphml: true,
            python: false,
            java: true
        },
        
        // Data Types
        {
            name: 'String Attributes',
            check: (doc) => Array.from(doc.querySelectorAll('key')).some(key => 
                key.getAttribute('attr.type') === 'string'),
            allSupported: true
        },
        {
            name: 'Numeric Attributes',
            check: (doc) => Array.from(doc.querySelectorAll('key')).some(key => 
                ['int', 'long', 'float', 'double'].includes(key.getAttribute('attr.type'))),
            allSupported: true
        },
        {
            name: 'Boolean Attributes',
            check: (doc) => Array.from(doc.querySelectorAll('key')).some(key => 
                key.getAttribute('attr.type') === 'boolean'),
            allSupported: true
        },
        {
            name: 'List Attributes',
            check: (doc) => Array.from(doc.querySelectorAll('key')).some(key => 
                key.getAttribute('attr.type') === 'list'),
            graphml: true,
            python: true,
            java: 'limited'
        },
        
        // Advanced Features
        {
            name: 'Graph Properties',
            check: (doc) => doc.querySelector('graph data') !== null,
            allSupported: true
        },
        {
            name: 'Custom Attributes',
            check: (doc) => Array.from(doc.querySelectorAll('key')).some(key => {
                const type = key.getAttribute('attr.type');
                return type && !['string', 'int', 'long', 'float', 'double', 'boolean', 'list'].includes(type);
            }),
            graphml: true,
            python: 'limited',
            java: 'limited'
        },
        {
            name: 'Graph Metadata',
            check: (doc) => doc.querySelector('graphml > data') !== null,
            allSupported: true
        }
    ];

    return capabilities.map(cap => {
        const isSupported = cap.check(xmlDoc);
        const graphmlStatus = isSupported ? '✅' : '❌';
        const pythonStatus = cap.python === undefined ? (cap.allSupported ? (isSupported ? '✅' : '❌') : '❌') :
                           cap.python === 'limited' ? '⚠️' : (isSupported ? '✅' : '❌');
        const javaStatus = cap.java === undefined ? (cap.allSupported ? (isSupported ? '✅' : '❌') : '❌') :
                         cap.java === 'limited' ? '⚠️' : (isSupported ? '✅' : '❌');

        return `
            <tr>
                <td>${cap.name}</td>
                <td>${graphmlStatus}</td>
                <td>${pythonStatus}</td>
                <td>${javaStatus}</td>
            </tr>
        `;
    }).join('');
}

function generateConversionCommands(fileName) {
    const commandsDiv = document.createElement('div');
    commandsDiv.className = 'conversion-commands mt-4';
    commandsDiv.innerHTML = `
        <h5>Conversion Commands</h5>
        <div class="card">
            <div class="card-body">
                <h6>Python Conversion</h6>
                <div class="command-box">
                    <code>python src/graphml_converter.py --input "${fileName}" --output "output.py" --format python</code>
                    <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyCommand(this)">Copy</button>
                </div>
                
                <h6 class="mt-3">Java Conversion</h6>
                <div class="command-box">
                    <code>python src/graphml_converter.py --input "${fileName}" --output "output.java" --format java</code>
                    <button class="btn btn-sm btn-outline-primary copy-btn" onclick="copyCommand(this)">Copy</button>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('validationResults').appendChild(commandsDiv);
}

function copyCommand(button) {
    const code = button.previousElementSibling.textContent;
    navigator.clipboard.writeText(code).then(() => {
        const originalText = button.textContent;
        button.textContent = 'Copied!';
        setTimeout(() => {
            button.textContent = originalText;
        }, 2000);
    });
}

function showValidationResult(type, message) {
    const resultsDiv = document.getElementById('validationResults');
    const resultItem = document.createElement('div');
    resultItem.className = `validation-item ${type}`;
    resultItem.innerHTML = `
        <i class="bi bi-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : 'x-circle'}-fill"></i>
        ${message}
    `;
    resultsDiv.appendChild(resultItem);
} 