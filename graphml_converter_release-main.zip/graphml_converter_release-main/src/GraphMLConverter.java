import org.jgrapht.*;
import org.jgrapht.graph.*;
import org.jgrapht.io.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class GraphMLConverter {
    private final String inputFile;
    private Graph<String, DefaultEdge> graph;
    private Map<String, Map<String, Object>> nodeAttributes;
    private Map<DefaultEdge, Map<String, Object>> edgeAttributes;
    private Map<String, Graph<String, DefaultEdge>> nestedGraphs;
    private Map<String, AttributeType> attributeTypes;

    public GraphMLConverter(String inputFile) {
        this.inputFile = inputFile;
        this.nodeAttributes = new HashMap<>();
        this.edgeAttributes = new HashMap<>();
        this.nestedGraphs = new HashMap<>();
        this.attributeTypes = new HashMap<>();
    }

    public void parseGraphML() throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new File(inputFile));

        // Get graph element
        NodeList graphList = document.getElementsByTagName("graph");
        if (graphList.getLength() == 0) {
            throw new IllegalArgumentException("No graph element found in the file");
        }

        Element graphElement = (Element) graphList.item(0);
        boolean isDirected = "directed".equals(graphElement.getAttribute("edgedefault"));
        
        // Create graph
        this.graph = isDirected ? 
            new DefaultDirectedGraph<>(DefaultEdge.class) :
            new DefaultUndirectedGraph<>(DefaultEdge.class);

        // Parse attributes
        parseAttributes(document);

        // Parse nodes
        parseNodes(graphElement);

        // Parse edges
        parseEdges(graphElement);

        // Parse nested graphs
        parseNestedGraphs(graphElement);
    }

    private void parseAttributes(Document document) {
        NodeList keyList = document.getElementsByTagName("key");
        for (int i = 0; i < keyList.getLength(); i++) {
            Element keyElement = (Element) keyList.item(i);
            String id = keyElement.getAttribute("id");
            String name = keyElement.getAttribute("attr.name");
            String type = keyElement.getAttribute("attr.type");
            
            if (id != null && name != null && type != null) {
                attributeTypes.put(id, new AttributeType(name, type));
            }
        }
    }

    private void parseNodes(Element graphElement) {
        NodeList nodeList = graphElement.getElementsByTagName("node");
        for (int i = 0; i < nodeList.getLength(); i++) {
            Element nodeElement = (Element) nodeList.item(i);
            String nodeId = nodeElement.getAttribute("id");
            
            if (nodeId != null) {
                graph.addVertex(nodeId);
                Map<String, Object> attrs = parseAttributes(nodeElement);
                if (!attrs.isEmpty()) {
                    nodeAttributes.put(nodeId, attrs);
                }
            }
        }
    }

    private void parseEdges(Element graphElement) {
        NodeList edgeList = graphElement.getElementsByTagName("edge");
        for (int i = 0; i < edgeList.getLength(); i++) {
            Element edgeElement = (Element) edgeList.item(i);
            String source = edgeElement.getAttribute("source");
            String target = edgeElement.getAttribute("target");
            
            if (source != null && target != null) {
                DefaultEdge edge = graph.addEdge(source, target);
                Map<String, Object> attrs = parseAttributes(edgeElement);
                if (!attrs.isEmpty()) {
                    edgeAttributes.put(edge, attrs);
                }
            }
        }
    }

    private void parseNestedGraphs(Element graphElement) {
        NodeList nestedList = graphElement.getElementsByTagName("graph");
        for (int i = 0; i < nestedList.getLength(); i++) {
            Element nestedElement = (Element) nestedList.item(i);
            String graphId = nestedElement.getAttribute("id");
            
            if (graphId != null) {
                Graph<String, DefaultEdge> nestedGraph = graph instanceof DirectedGraph ?
                    new DefaultDirectedGraph<>(DefaultEdge.class) :
                    new DefaultUndirectedGraph<>(DefaultEdge.class);
                
                nestedGraphs.put(graphId, nestedGraph);
                parseNodes(nestedElement);
                parseEdges(nestedElement);
            }
        }
    }

    private Map<String, Object> parseAttributes(Element element) {
        Map<String, Object> attrs = new HashMap<>();
        NodeList dataList = element.getElementsByTagName("data");
        
        for (int i = 0; i < dataList.getLength(); i++) {
            Element dataElement = (Element) dataList.item(i);
            String key = dataElement.getAttribute("key");
            
            if (key != null && attributeTypes.containsKey(key)) {
                AttributeType attrType = attributeTypes.get(key);
                String value = dataElement.getTextContent();
                attrs.put(attrType.getName(), convertValue(value, attrType.getType()));
            }
        }
        
        return attrs;
    }

    private Object convertValue(String value, String type) {
        if (value == null) return null;
        
        try {
            switch (type) {
                case "string": return value;
                case "int": return Integer.parseInt(value);
                case "long": return Long.parseLong(value);
                case "float": return Float.parseFloat(value);
                case "double": return Double.parseDouble(value);
                case "boolean": return Boolean.parseBoolean(value);
                default: return value;
            }
        } catch (NumberFormatException e) {
            return value;
        }
    }

    public void toPython(String outputFile) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {
            writer.println("import networkx as nx");
            writer.println();
            
            // Create graph
            String graphType = graph instanceof DirectedGraph ? "DiGraph" : "Graph";
            writer.println(f"# Create {graphType}");
            writer.println(f"G = nx.{graphType}()");
            writer.println();
            
            // Add nodes with attributes
            writer.println("# Add nodes with attributes");
            for (String node : graph.vertexSet()) {
                Map<String, Object> attrs = nodeAttributes.get(node);
                if (attrs != null && !attrs.isEmpty()) {
                    String attrsStr = attrs.entrySet().stream()
                        .map(e -> String.format("\"%s\": %s", e.getKey(), formatValue(e.getValue())))
                        .collect(Collectors.joining(", "));
                    writer.printf("G.add_node(\"%s\", %s)%n", node, attrsStr);
                } else {
                    writer.printf("G.add_node(\"%s\")%n", node);
                }
            }
            writer.println();
            
            // Add edges with attributes
            writer.println("# Add edges with attributes");
            for (DefaultEdge edge : graph.edgeSet()) {
                String source = graph.getEdgeSource(edge);
                String target = graph.getEdgeTarget(edge);
                Map<String, Object> attrs = edgeAttributes.get(edge);
                
                if (attrs != null && !attrs.isEmpty()) {
                    String attrsStr = attrs.entrySet().stream()
                        .map(e -> String.format("\"%s\": %s", e.getKey(), formatValue(e.getValue())))
                        .collect(Collectors.joining(", "));
                    writer.printf("G.add_edge(\"%s\", \"%s\", %s)%n", source, target, attrsStr);
                } else {
                    writer.printf("G.add_edge(\"%s\", \"%s\")%n", source, target);
                }
            }
            
            // Add nested graphs
            if (!nestedGraphs.isEmpty()) {
                writer.println("\n# Nested graphs");
                for (Map.Entry<String, Graph<String, DefaultEdge>> entry : nestedGraphs.entrySet()) {
                    String graphId = entry.getKey();
                    Graph<String, DefaultEdge> nestedGraph = entry.getValue();
                    
                    writer.printf("\n# Nested graph: %s%n", graphId);
                    writer.printf("nested_%s = nx.%s()%n", graphId, graphType);
                    
                    // Add nodes
                    for (String node : nestedGraph.vertexSet()) {
                        writer.printf("nested_%s.add_node(\"%s\")%n", graphId, node);
                    }
                    
                    // Add edges
                    for (DefaultEdge edge : nestedGraph.edgeSet()) {
                        String source = nestedGraph.getEdgeSource(edge);
                        String target = nestedGraph.getEdgeTarget(edge);
                        writer.printf("nested_%s.add_edge(\"%s\", \"%s\")%n", graphId, source, target);
                    }
                }
            }
        }
    }

    private String formatValue(Object value) {
        if (value == null) return "None";
        if (value instanceof String) return String.format("\"%s\"", value);
        if (value instanceof Boolean) return value.toString();
        if (value instanceof Number) return value.toString();
        return String.format("\"%s\"", value);
    }

    private static class AttributeType {
        private final String name;
        private final String type;

        public AttributeType(String name, String type) {
            this.name = name;
            this.type = type;
        }

        public String getName() { return name; }
        public String getType() { return type; }
    }

    public static void main(String[] args) {
        if (args.length != 3) {
            System.err.println("Usage: java GraphMLConverter <input_file> <output_file> <format>");
            System.exit(1);
        }

        String inputFile = args[0];
        String outputFile = args[1];
        String format = args[2];

        try {
            GraphMLConverter converter = new GraphMLConverter(inputFile);
            converter.parseGraphML();

            if ("python".equals(format)) {
                converter.toPython(outputFile);
            } else {
                System.err.println("Unsupported format: " + format);
                System.exit(1);
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
} 