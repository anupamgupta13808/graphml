#!/usr/bin/env python3
import networkx as nx
import xml.etree.ElementTree as ET
import argparse
from typing import Dict, Any, List, Optional
import json

class GraphMLConverter:
    def __init__(self, input_file: str):
        self.input_file = input_file
        self.graph = None
        self.attributes = {}
        self.nested_graphs = {}

    def parse_graphml(self) -> None:
        """Parse the GraphML file and create a NetworkX graph"""
        tree = ET.parse(self.input_file)
        root = tree.getroot()
        
        # Get graph element
        graph_elem = root.find('.//graph')
        if graph_elem is None:
            raise ValueError("No graph element found in the file")
        
        # Create directed or undirected graph
        is_directed = graph_elem.get('edgedefault') == 'directed'
        self.graph = nx.DiGraph() if is_directed else nx.Graph()
        
        # Parse attributes
        self._parse_attributes(root)
        
        # Parse nodes
        self._parse_nodes(graph_elem)
        
        # Parse edges
        self._parse_edges(graph_elem)
        
        # Parse nested graphs
        self._parse_nested_graphs(graph_elem)

    def _parse_attributes(self, root: ET.Element) -> None:
        """Parse attribute definitions"""
        for key in root.findall('.//key'):
            attr_id = key.get('id')
            attr_name = key.get('attr.name')
            attr_type = key.get('attr.type')
            if attr_id and attr_name and attr_type:
                self.attributes[attr_id] = {
                    'name': attr_name,
                    'type': attr_type
                }

    def _parse_nodes(self, graph_elem: ET.Element) -> None:
        """Parse nodes and their attributes"""
        for node in graph_elem.findall('.//node'):
            node_id = node.get('id')
            if node_id:
                # Get node attributes
                attrs = {}
                for data in node.findall('data'):
                    key = data.get('key')
                    if key in self.attributes:
                        attr_name = self.attributes[key]['name']
                        attr_type = self.attributes[key]['type']
                        value = self._convert_value(data.text, attr_type)
                        attrs[attr_name] = value
                
                self.graph.add_node(node_id, **attrs)

    def _parse_edges(self, graph_elem: ET.Element) -> None:
        """Parse edges and their attributes"""
        for edge in graph_elem.findall('.//edge'):
            source = edge.get('source')
            target = edge.get('target')
            if source and target:
                # Get edge attributes
                attrs = {}
                for data in edge.findall('data'):
                    key = data.get('key')
                    if key in self.attributes:
                        attr_name = self.attributes[key]['name']
                        attr_type = self.attributes[key]['type']
                        value = self._convert_value(data.text, attr_type)
                        attrs[attr_name] = value
                
                self.graph.add_edge(source, target, **attrs)

    def _parse_nested_graphs(self, graph_elem: ET.Element) -> None:
        """Parse nested graphs"""
        for nested in graph_elem.findall('.//graph'):
            parent_id = nested.get('id')
            if parent_id:
                nested_graph = nx.DiGraph() if self.graph.is_directed() else nx.Graph()
                self.nested_graphs[parent_id] = nested_graph
                
                # Parse nodes and edges in nested graph
                self._parse_nodes(nested)
                self._parse_edges(nested)

    def _convert_value(self, value: str, attr_type: str) -> Any:
        """Convert attribute value to appropriate type"""
        if value is None:
            return None
        
        try:
            if attr_type == 'string':
                return str(value)
            elif attr_type == 'int':
                return int(value)
            elif attr_type == 'long':
                return int(value)
            elif attr_type == 'float':
                return float(value)
            elif attr_type == 'double':
                return float(value)
            elif attr_type == 'boolean':
                return value.lower() == 'true'
            else:
                return str(value)
        except (ValueError, TypeError):
            return str(value)

    def to_python(self, output_file: str) -> None:
        """Convert to Python NetworkX code"""
        with open(output_file, 'w') as f:
            f.write('import networkx as nx\n\n')
            
            # Create graph
            graph_type = 'DiGraph' if self.graph.is_directed() else 'Graph'
            f.write(f'# Create {graph_type}\n')
            f.write(f'G = nx.{graph_type}()\n\n')
            
            # Add nodes with attributes
            f.write('# Add nodes with attributes\n')
            for node, attrs in self.graph.nodes(data=True):
                if attrs:
                    attrs_str = json.dumps(attrs, indent=2)
                    f.write(f'G.add_node("{node}", {attrs_str})\n')
                else:
                    f.write(f'G.add_node("{node}")\n')
            f.write('\n')
            
            # Add edges with attributes
            f.write('# Add edges with attributes\n')
            for u, v, attrs in self.graph.edges(data=True):
                if attrs:
                    attrs_str = json.dumps(attrs, indent=2)
                    f.write(f'G.add_edge("{u}", "{v}", {attrs_str})\n')
                else:
                    f.write(f'G.add_edge("{u}", "{v}")\n')
            
            # Add nested graphs if any
            if self.nested_graphs:
                f.write('\n# Nested graphs\n')
                for graph_id, nested_graph in self.nested_graphs.items():
                    f.write(f'\n# Nested graph: {graph_id}\n')
                    f.write(f'nested_{graph_id} = nx.{graph_type}()\n')
                    
                    for node, attrs in nested_graph.nodes(data=True):
                        if attrs:
                            attrs_str = json.dumps(attrs, indent=2)
                            f.write(f'nested_{graph_id}.add_node("{node}", {attrs_str})\n')
                        else:
                            f.write(f'nested_{graph_id}.add_node("{node}")\n')
                    
                    for u, v, attrs in nested_graph.edges(data=True):
                        if attrs:
                            attrs_str = json.dumps(attrs, indent=2)
                            f.write(f'nested_{graph_id}.add_edge("{u}", "{v}", {attrs_str})\n')
                        else:
                            f.write(f'nested_{graph_id}.add_edge("{u}", "{v}")\n')

    def to_java(self, output_file: str) -> None:
        """Convert to Java JGraphT code"""
        with open(output_file, 'w') as f:
            f.write('import org.jgrapht.*;\n')
            f.write('import org.jgrapht.graph.*;\n')
            f.write('import java.util.*;\n\n')
            
            # Create graph class
            f.write('public class GraphMLGraph {\n')
            f.write('    private final Graph<String, DefaultEdge> graph;\n')
            f.write('    private final Map<String, Map<String, Object>> nodeAttributes;\n')
            f.write('    private final Map<DefaultEdge, Map<String, Object>> edgeAttributes;\n\n')
            
            # Constructor
            f.write('    public GraphMLGraph() {\n')
            graph_type = 'DirectedGraph' if self.graph.is_directed() else 'Graph'
            f.write(f'        this.graph = new Default{graph_type}<>(DefaultEdge.class);\n')
            f.write('        this.nodeAttributes = new HashMap<>();\n')
            f.write('        this.edgeAttributes = new HashMap<>();\n')
            f.write('    }\n\n')
            
            # Add nodes
            f.write('    public void addNodes() {\n')
            for node in self.graph.nodes():
                f.write(f'        graph.addVertex("{node}");\n')
            f.write('    }\n\n')
            
            # Add edges
            f.write('    public void addEdges() {\n')
            for u, v in self.graph.edges():
                f.write(f'        DefaultEdge edge = graph.addEdge("{u}", "{v}");\n')
            f.write('    }\n\n')
            
            # Add node attributes
            f.write('    public void addNodeAttributes() {\n')
            for node, attrs in self.graph.nodes(data=True):
                if attrs:
                    f.write(f'        Map<String, Object> attrs = new HashMap<>();\n')
                    for key, value in attrs.items():
                        if isinstance(value, str):
                            f.write(f'        attrs.put("{key}", "{value}");\n')
                        else:
                            f.write(f'        attrs.put("{key}", {value});\n')
                    f.write(f'        nodeAttributes.put("{node}", attrs);\n')
            f.write('    }\n\n')
            
            # Add edge attributes
            f.write('    public void addEdgeAttributes() {\n')
            for u, v, attrs in self.graph.edges(data=True):
                if attrs:
                    f.write(f'        Map<String, Object> attrs = new HashMap<>();\n')
                    for key, value in attrs.items():
                        if isinstance(value, str):
                            f.write(f'        attrs.put("{key}", "{value}");\n')
                        else:
                            f.write(f'        attrs.put("{key}", {value});\n')
                    f.write(f'        edgeAttributes.put(graph.getEdge("{u}", "{v}"), attrs);\n')
            f.write('    }\n\n')
            
            # Main method
            f.write('    public static void main(String[] args) {\n')
            f.write('        GraphMLGraph g = new GraphMLGraph();\n')
            f.write('        g.addNodes();\n')
            f.write('        g.addEdges();\n')
            f.write('        g.addNodeAttributes();\n')
            f.write('        g.addEdgeAttributes();\n')
            f.write('    }\n')
            f.write('}\n')

def main():
    parser = argparse.ArgumentParser(description='Convert GraphML to Python or Java code')
    parser.add_argument('--input', required=True, help='Input GraphML file')
    parser.add_argument('--output', required=True, help='Output file')
    parser.add_argument('--format', choices=['python', 'java'], required=True, help='Output format')
    
    args = parser.parse_args()
    
    converter = GraphMLConverter(args.input)
    converter.parse_graphml()
    
    if args.format == 'python':
        converter.to_python(args.output)
    else:
        converter.to_java(args.output)

import shutil
import tempfile
from java_templates import (
    FLOW_ANALYSIS_TEMPLATE,
    FILE_PROCESSOR_TEMPLATE,
    INSTRUCTION_CLASS_TEMPLATES,
    PROCESS_METHOD_TEMPLATES
)

class GraphMLConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("GraphML to Java Converter")
        self.root.geometry("800x600")
        
        # Create main frame
        self.main_frame = ttk.Frame(root, padding="10")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # File selection
        self.create_file_selection_widgets()
        
        # Process button
        self.process_btn = ttk.Button(self.main_frame, text="Process File", command=self.process_file)
        self.process_btn.grid(row=2, column=0, columnspan=2, pady=10)
        
        # Status
        self.status_var = tk.StringVar()
        self.status_label = ttk.Label(self.main_frame, textvariable=self.status_var)
        self.status_label.grid(row=3, column=0, columnspan=2, pady=5)
        
        # Output text
        self.output_text = tk.Text(self.main_frame, height=20, width=80)
        self.output_text.grid(row=4, column=0, columnspan=2, pady=5)
        
        # Initialize variables
        self.input_file = None
        self.temp_dir = None
        self.java_files = []

    def create_file_selection_widgets(self):
        # Input file selection
        ttk.Label(self.main_frame, text="Select Input File:").grid(row=0, column=0, sticky=tk.W)
        self.file_btn = ttk.Button(self.main_frame, text="Browse", command=self.select_input_file)
        self.file_btn.grid(row=0, column=1, sticky=tk.W)
        
        # Input file path display
        self.file_path_var = tk.StringVar()
        self.file_path_label = ttk.Label(self.main_frame, textvariable=self.file_path_var)
        self.file_path_label.grid(row=1, column=0, columnspan=2, sticky=tk.W)

    def select_input_file(self):
        filetypes = [
            ("Graph Files", "*.graphml *.gml *.xml *.json"),
            ("All Files", "*.*")
        ]
        filename = filedialog.askopenfilename(filetypes=filetypes)
        if filename:
            self.input_file = filename
            self.file_path_var.set(f"Selected: {os.path.basename(filename)}")
            self.status_var.set("File selected. Ready to process.")

    def convert_to_xml(self, input_file):
        """Convert input file to XML format if needed"""
        ext = os.path.splitext(input_file)[1].lower()
        
        if ext == '.xml':
            return input_file
            
        # Create temporary directory for conversion
        self.temp_dir = tempfile.mkdtemp()
        xml_file = os.path.join(self.temp_dir, 'converted.xml')
        
        try:
            if ext == '.graphml':
                G = nx.read_graphml(input_file)
                nx.write_graphml(G, xml_file)
            elif ext == '.gml':
                G = nx.read_gml(input_file)
                nx.write_graphml(G, xml_file)
            elif ext == '.json':
                with open(input_file, 'r') as f:
                    data = json.load(f)
                G = nx.node_link_graph(data)
                nx.write_graphml(G, xml_file)
            else:
                raise ValueError(f"Unsupported file format: {ext}")
                
            return xml_file
        except Exception as e:
            messagebox.showerror("Error", f"Error converting file: {str(e)}")
            return None

    def generate_java_code(self, xml_file):
        """Generate Java code based on XML structure"""
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
            
            # Create Java source directory
            java_src_dir = os.path.join(self.temp_dir, 'src', 'main', 'java')
            os.makedirs(java_src_dir, exist_ok=True)
            
            # Generate FlowAnalysis.java
            flow_analysis_path = os.path.join(java_src_dir, 'FlowAnalysis.java')
            self.generate_flow_analysis(root, flow_analysis_path)
            
            # Generate FileProcessor.java
            file_processor_path = os.path.join(java_src_dir, 'FileProcessor.java')
            self.generate_file_processor(root, file_processor_path)
            
            self.java_files = [flow_analysis_path, file_processor_path]
            return True
        except Exception as e:
            messagebox.showerror("Error", f"Error generating Java code: {str(e)}")
            return False

    def generate_flow_analysis(self, root, output_path):
        """Generate FlowAnalysis.java based on XML structure"""
        # Extract nodes and their types
        nodes = {}
        for node in root.findall('.//{http://graphml.graphdrawing.org/xmlns}node'):
            node_id = node.get('id')
            label = node.find('.//{http://graphml.graphdrawing.org/xmlns}data[@key="label"]')
            if label is not None:
                nodes[node_id] = label.text

        # Generate instruction classes
        instruction_classes = '\n'.join(INSTRUCTION_CLASS_TEMPLATES.values())

        # Generate add methods
        add_methods = []
        for node_type in ['ReadOperation', 'LoadOperation', 'CallOperation', 'Condition', 'DataControlBlock']:
            add_methods.append(f'''
    public void add{node_type}({node_type} operation) {{
        {node_type.lower()}s.add(operation);
        nodeHierarchy.add(operation);
    }}''')
        add_methods.append('''
    public void setVersionInfo(VersionInfo versionInfo) {
        this.versionInfo = versionInfo;
        nodeHierarchy.add(versionInfo);
    }''')

        # Generate getter methods
        getter_methods = []
        for node_type in ['ReadOperation', 'LoadOperation', 'CallOperation', 'Condition', 'DataControlBlock']:
            getter_methods.append(f'''
    public List<{node_type}> get{node_type}s() {{
        return {node_type.lower()}s;
    }}''')
        getter_methods.append('''
    public VersionInfo getVersionInfo() {
        return versionInfo;
    }''')
        getter_methods.append('''
    public List<Instruction> getNodeHierarchy() {
        return nodeHierarchy;
    }''')

        # Generate main method content
        main_method_content = []
        for node_id, label in nodes.items():
            if 'Version' in label:
                main_method_content.append(f'analysis.setVersionInfo(new VersionInfo("{node_id}", "{label}"));')
            elif 'Read' in label:
                main_method_content.append(f'analysis.addReadOperation(new ReadOperation("{node_id}", "{label}"));')
            elif 'Load' in label:
                main_method_content.append(f'analysis.addLoadOperation(new LoadOperation("{node_id}", "{label}"));')
            elif 'Call' in label:
                main_method_content.append(f'analysis.addCallOperation(new CallOperation("{node_id}", "{label}"));')
            elif 'If' in label:
                main_method_content.append(f'analysis.addCondition(new Condition("{node_id}", "{label}"));')
            elif 'Data Control Block' in label:
                main_method_content.append(f'analysis.addDataControlBlock(new DataControlBlock("{node_id}", "{label}"));')

        # Write the file
        with open(output_path, 'w') as f:
            f.write(FLOW_ANALYSIS_TEMPLATE.format(
                instruction_classes=instruction_classes,
                add_methods='\n'.join(add_methods),
                getter_methods='\n'.join(getter_methods),
                main_method_content='\n        '.join(main_method_content)
            ))

    def generate_file_processor(self, root, output_path):
        """Generate FileProcessor.java based on XML structure"""
        # Generate process methods
        process_methods = []
        process_methods.append('''
    private void processInstruction(FlowAnalysis.Instruction instruction) throws IOException {
        if (instruction instanceof FlowAnalysis.ReadOperation) {
            processReadOperation((FlowAnalysis.ReadOperation) instruction);
        } else if (instruction instanceof FlowAnalysis.LoadOperation) {
            processLoadOperation((FlowAnalysis.LoadOperation) instruction);
        } else if (instruction instanceof FlowAnalysis.CallOperation) {
            processCallOperation((FlowAnalysis.CallOperation) instruction);
        } else if (instruction instanceof FlowAnalysis.Condition) {
            processCondition((FlowAnalysis.Condition) instruction);
        }
    }''')
        process_methods.extend(PROCESS_METHOD_TEMPLATES.values())

        # Generate main method content
        main_method_content = []
        for node in root.findall('.//{http://graphml.graphdrawing.org/xmlns}node'):
            node_id = node.get('id')
            label = node.find('.//{http://graphml.graphdrawing.org/xmlns}data[@key="label"]')
            if label is not None:
                if 'Version' in label.text:
                    main_method_content.append(f'analysis.setVersionInfo(new FlowAnalysis.VersionInfo("{node_id}", "{label.text}"));')
                elif 'Read' in label.text:
                    main_method_content.append(f'analysis.addReadOperation(new FlowAnalysis.ReadOperation("{node_id}", "{label.text}"));')
                elif 'Load' in label.text:
                    main_method_content.append(f'analysis.addLoadOperation(new FlowAnalysis.LoadOperation("{node_id}", "{label.text}"));')
                elif 'Call' in label.text:
                    main_method_content.append(f'analysis.addCallOperation(new FlowAnalysis.CallOperation("{node_id}", "{label.text}"));')
                elif 'If' in label.text:
                    main_method_content.append(f'analysis.addCondition(new FlowAnalysis.Condition("{node_id}", "{label.text}"));')
                elif 'Data Control Block' in label.text:
                    main_method_content.append(f'analysis.addDataControlBlock(new FlowAnalysis.DataControlBlock("{node_id}", "{label.text}"));')

        # Write the file
        with open(output_path, 'w') as f:
            f.write(FILE_PROCESSOR_TEMPLATE.format(
                process_methods='\n'.join(process_methods),
                main_method_content='\n            '.join(main_method_content)
            ))

    def compile_java_code(self):
        """Compile the generated Java code"""
        try:
            # Create target directory
            target_dir = os.path.join(self.temp_dir, 'target', 'classes')
            os.makedirs(target_dir, exist_ok=True)
            
            # Compile Java files
            for java_file in self.java_files:
                subprocess.run(['javac', '-d', target_dir, java_file], check=True)
            
            return True
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Error compiling Java code: {str(e)}")
            return False

    def process_file(self):
        if not self.input_file:
            messagebox.showwarning("Warning", "Please select an input file first.")
            return
            
        try:
            # Convert to XML
            self.status_var.set("Converting to XML...")
            xml_file = self.convert_to_xml(self.input_file)
            if not xml_file:
                return
                
            # Generate Java code
            self.status_var.set("Generating Java code...")
            if not self.generate_java_code(xml_file):
                return
                
            # Compile Java code
            self.status_var.set("Compiling Java code...")
            if not self.compile_java_code():
                return
                
            # Run Java program
            self.status_var.set("Running Java program...")
            self.run_java_program()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error processing file: {str(e)}")
        finally:
            # Cleanup
            if self.temp_dir and os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)

    def run_java_program(self):
        """Run the compiled Java program"""
        try:
            # Ask for input file
            input_file = filedialog.askopenfilename(
                title="Select Input File for Processing",
                filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
            )
            
            if not input_file:
                return
                
            # Create output file path
            output_file = os.path.join(os.path.dirname(input_file), 'output.txt')
            
            # Run Java program
            target_dir = os.path.join(self.temp_dir, 'target', 'classes')
            result = subprocess.run(
                ['java', '-cp', target_dir, 'FileProcessor', input_file, output_file],
                capture_output=True,
                text=True
            )
            
            # Display output
            self.output_text.delete(1.0, tk.END)
            self.output_text.insert(tk.END, result.stdout)
            if result.stderr:
                self.output_text.insert(tk.END, f"\nErrors:\n{result.stderr}")
                
            # Open output file
            if os.path.exists(output_file):
                os.system(f'open "{output_file}"')
                
            self.status_var.set("Processing completed successfully!")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error running Java program: {str(e)}")

def main():
    root = tk.Tk()
    app = GraphMLConverter(root)
    root.mainloop()

if __name__ == "__main__":
    main() 