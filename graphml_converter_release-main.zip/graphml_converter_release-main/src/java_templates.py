FLOW_ANALYSIS_TEMPLATE = '''import java.util.ArrayList;
import java.util.List;

public class FlowAnalysis {{
    // Instruction classes
    public static class Instruction {{
        protected String id;
        protected String label;

        public Instruction(String id, String label) {{
            this.id = id;
            this.label = label;
        }}

        public String getId() {{ return id; }}
        public String getLabel() {{ return label; }}
    }}

    {instruction_classes}

    // Main FlowAnalysis class
    private List<ReadOperation> readOperations;
    private List<LoadOperation> loadOperations;
    private List<CallOperation> callOperations;
    private List<Condition> conditions;
    private VersionInfo versionInfo;
    private List<DataControlBlock> dataControlBlocks;
    private List<Instruction> nodeHierarchy;

    public FlowAnalysis() {{
        this.readOperations = new ArrayList<>();
        this.loadOperations = new ArrayList<>();
        this.callOperations = new ArrayList<>();
        this.conditions = new ArrayList<>();
        this.dataControlBlocks = new ArrayList<>();
        this.nodeHierarchy = new ArrayList<>();
    }}

    // Add methods
    {add_methods}

    // Getter methods
    {getter_methods}

    // Main method to demonstrate usage
    public static void main(String[] args) {{
        FlowAnalysis analysis = new FlowAnalysis();
        {main_method_content}
    }}
}}'''

FILE_PROCESSOR_TEMPLATE = '''import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class FileProcessor {{
    private FlowAnalysis flowAnalysis;
    private Map<String, String> registers;
    private Map<String, String> variables;
    private String currentInputFile;
    private String currentOutputFile;
    private int currentInstructionIndex;
    private List<FlowAnalysis.Instruction> instructions;
    private Stack<Integer> callStack;

    public FileProcessor(FlowAnalysis flowAnalysis) {{
        this.flowAnalysis = flowAnalysis;
        this.registers = new HashMap<>();
        this.variables = new HashMap<>();
        this.callStack = new Stack<>();
        this.instructions = flowAnalysis.getNodeHierarchy();
        this.currentInstructionIndex = 0;
    }}

    public void processFiles(String inputFile, String outputFile) throws IOException {{
        this.currentInputFile = inputFile;
        this.currentOutputFile = outputFile;
        
        // Initialize registers
        for (int i = 0; i <= 15; i++) {{
            registers.put("R" + i, "0");
        }}

        // Process instructions until we reach the end
        while (currentInstructionIndex < instructions.size()) {{
            processInstruction(instructions.get(currentInstructionIndex));
            currentInstructionIndex++;
        }}
    }}

    {process_methods}

    public static void main(String[] args) {{
        try {{
            if (args.length != 2) {{
                System.err.println("Usage: java FileProcessor <input_file> <output_file>");
                System.exit(1);
            }}

            // Create flow analysis
            FlowAnalysis analysis = new FlowAnalysis();
            {main_method_content}

            // Create and run file processor
            FileProcessor processor = new FileProcessor(analysis);
            processor.processFiles(args[0], args[1]);
            
        }} catch (IOException e) {{
            System.err.println("Error processing files: " + e.getMessage());
            e.printStackTrace();
        }}
    }}
}}'''

INSTRUCTION_CLASS_TEMPLATES = {
    'ReadOperation': '''
    public static class ReadOperation extends Instruction {{
        private String variable;
        private String source;

        public ReadOperation(String id, String label) {{
            super(id, label);
            parseLabel();
        }}

        private void parseLabel() {{
            String[] parts = label.split("Read ")[1].split(" from ");
            this.variable = parts[0];
            this.source = parts[1];
        }}

        public String getVariable() {{ return variable; }}
        public String getSource() {{ return source; }}
    }}''',

    'LoadOperation': '''
    public static class LoadOperation extends Instruction {{
        private String source;
        private String destination;

        public LoadOperation(String id, String label) {{
            super(id, label);
            parseLabel();
        }}

        private void parseLabel() {{
            String[] parts = label.split("Load ")[1].split(" into ");
            this.source = parts[0];
            this.destination = parts[1];
        }}

        public String getSource() {{ return source; }}
        public String getDestination() {{ return destination; }}
    }}''',

    'CallOperation': '''
    public static class CallOperation extends Instruction {{
        private String function;
        private String returnRegister;

        public CallOperation(String id, String label) {{
            super(id, label);
            parseLabel();
        }}

        private void parseLabel() {{
            String[] parts = label.split("Call ")[1].split(" and save return address in ");
            this.function = parts[0];
            this.returnRegister = parts[1];
        }}

        public String getFunction() {{ return function; }}
        public String getReturnRegister() {{ return returnRegister; }}
    }}''',

    'Condition': '''
    public static class Condition extends Instruction {{
        private String condition;

        public Condition(String id, String label) {{
            super(id, label);
            parseLabel();
        }}

        private void parseLabel() {{
            this.condition = label.split("If \\(")[1].replace(")", "");
        }}

        public String getCondition() {{ return condition; }}
    }}''',

    'VersionInfo': '''
    public static class VersionInfo extends Instruction {{
        private String version;
        private String generationDate;

        public VersionInfo(String id, String label) {{
            super(id, label);
            parseLabel();
        }}

        private void parseLabel() {{
            String[] parts = label.split(" -- Generated On ");
            this.version = parts[0];
            this.generationDate = parts[1];
        }}

        public String getVersion() {{ return version; }}
        public String getGenerationDate() {{ return generationDate; }}
    }}''',

    'DataControlBlock': '''
    public static class DataControlBlock extends Instruction {{
        public DataControlBlock(String id, String label) {{
            super(id, label);
        }}
    }}'''
}

PROCESS_METHOD_TEMPLATES = {
    'processReadOperation': '''
    private void processReadOperation(FlowAnalysis.ReadOperation operation) throws IOException {{
        List<String> lines = Files.readAllLines(Paths.get(currentInputFile));
        for (String line : lines) {{
            String value = line.trim();
            variables.put(operation.getVariable(), value);
            if (operation.getVariable().equals("RECIN")) {{
                variables.put("WAFFILCD", value);
            }}
            System.out.println("Read " + operation.getVariable() + " = " + value + " from " + operation.getSource());
            Files.write(Paths.get(currentOutputFile), 
                       (value + System.lineSeparator()).getBytes(),
                       StandardOpenOption.CREATE,
                       StandardOpenOption.APPEND);
        }}
    }}''',

    'processLoadOperation': '''
    private void processLoadOperation(FlowAnalysis.LoadOperation operation) {{
        String sourceValue = operation.getSource();
        if (sourceValue.startsWith("R")) {{
            sourceValue = registers.get(sourceValue);
        }}
        registers.put(operation.getDestination(), sourceValue);
        System.out.println("Loaded " + sourceValue + " into " + operation.getDestination());
    }}''',

    'processCallOperation': '''
    private void processCallOperation(FlowAnalysis.CallOperation operation) throws IOException {{
        callStack.push(currentInstructionIndex);
        registers.put(operation.getReturnRegister(), String.valueOf(currentInstructionIndex));
        
        String result = "";
        switch (operation.getFunction()) {{
            case "P0025":
                result = processP0025();
                break;
            default:
                result = "Unknown function: " + operation.getFunction();
        }}
        
        Files.write(Paths.get(currentOutputFile), 
                   (result + System.lineSeparator()).getBytes(),
                   StandardOpenOption.CREATE,
                   StandardOpenOption.APPEND);
    }}''',

    'processCondition': '''
    private void processCondition(FlowAnalysis.Condition condition) throws IOException {{
        String cond = condition.getCondition();
        
        cond = cond.replace("LITERAL_C_9", "9")
                  .replace("LITERAL_C_6", "6");
        
        for (Map.Entry<String, String> reg : registers.entrySet()) {{
            cond = cond.replace(reg.getKey(), reg.getValue());
        }}
        
        for (Map.Entry<String, String> var : variables.entrySet()) {{
            cond = cond.replace(var.getKey(), var.getValue());
        }}
        
        System.out.println("Evaluating condition: " + cond);
        
        boolean result = evaluateCondition(cond);
        
        if (!result) {{
            skipToNextBlock();
        }}
    }}''',

    'evaluateCondition': '''
    private boolean evaluateCondition(String condition) {{
        Pattern pattern = Pattern.compile("(.+?)\\s*([=<>!]+)\\s*(.+)");
        Matcher matcher = pattern.matcher(condition);
        
        if (matcher.matches()) {{
            String leftOperand = matcher.group(1).trim();
            String operator = matcher.group(2).trim();
            String rightOperand = matcher.group(3).trim();
            
            long left = parseOperand(leftOperand);
            long right = parseOperand(rightOperand);
            
            switch (operator) {{
                case "==": return left == right;
                case "!=": return left != right;
                case ">": return left > right;
                case "<": return left < right;
                case ">=": return left >= right;
                case "<=": return left <= right;
                default:
                    throw new IllegalArgumentException("Unknown operator: " + operator);
            }}
        }}
        
        throw new IllegalArgumentException("Invalid condition format: " + condition);
    }}''',

    'parseOperand': '''
    private long parseOperand(String operand) {{
        operand = operand.trim();
        try {{
            return Long.parseLong(operand);
        }} catch (NumberFormatException e) {{
            if (registers.containsKey(operand)) {{
                return Long.parseLong(registers.get(operand));
            }} else if (variables.containsKey(operand)) {{
                return Long.parseLong(variables.get(operand));
            }}
            return 0;
        }}
    }}''',

    'skipToNextBlock': '''
    private void skipToNextBlock() {{
        while (currentInstructionIndex < instructions.size() - 1) {{
            currentInstructionIndex++;
            FlowAnalysis.Instruction next = instructions.get(currentInstructionIndex);
            if (next instanceof FlowAnalysis.Condition) {{
                break;
            }}
        }}
    }}''',

    'processP0025': '''
    private String processP0025() {{
        String r15Value = registers.get("R15");
        String recinValue = variables.get("RECIN");
        String result = "P0025 processed: R15=" + r15Value + ", RECIN=" + recinValue;
        System.out.println(result);
        return result;
    }}'''
} 