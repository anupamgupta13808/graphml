# GraphML Converter v4

A comprehensive tool for converting GraphML files to Python (NetworkX) and Java (JGraphT) code, with enhanced validation and visualization capabilities.

## Features

- **Enhanced Validation**: Detailed analysis of GraphML file structure and capabilities
- **Visual Capability Analysis**: Clear display of supported features in each format
- **Python Support**: Full NetworkX code generation with attribute support
- **Java Support**: Complete JGraphT integration with type conversion
- **Modern UI**: Clean, responsive interface with real-time validation

## Installation

### Python Requirements
```bash
pip install -r requirements.txt
```

### Java Requirements
- Java 11 or higher
- Maven 3.6 or higher

## Usage

1. Open `validatorpage/index.html` in a web browser
2. Upload your GraphML file
3. View the validation results and capability analysis
4. Use the generated conversion commands to convert your file

### Python Conversion
```bash
python src/graphml_converter.py --input "your_file.graphml" --output "output.py" --format python
```

### Java Conversion
```bash
mvn clean package
java -jar target/graphml-converter-1.0-SNAPSHOT-jar-with-dependencies.jar your_file.graphml output.java python
```

## Supported Features

### Graph Structure
- Directed/Undirected graphs
- Node and edge attributes
- Edge weights
- Self-loops
- Nested graphs

### Data Types
- String attributes
- Numeric attributes (int, long, float, double)
- Boolean attributes
- List attributes
- Custom attributes

### Advanced Features
- Graph properties
- Graph metadata
- Node/Edge types
- Node/Edge labels

## Version History

### v4.0
- Enhanced validation display with table structure
- Comprehensive capability analysis
- Improved type conversion
- Better error handling
- Modern UI with Bootstrap 5

## License

MIT License 